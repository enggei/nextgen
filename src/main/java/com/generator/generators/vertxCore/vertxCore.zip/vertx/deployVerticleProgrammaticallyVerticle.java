

 package com.generator.generators.vertxCore.vertx;

import com.generator.util.VertxUtil;
import com.generator.generators.vertxCore.VertxCoreGroup;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

import static com.generator.util.VertxUtil.*;

/**
 * goe on 5/20/16.
 */
public class deployVerticleProgrammaticallyVerticle extends AbstractVerticle {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(deployVerticleProgrammaticallyVerticle.class);

	public static void sendInstanceMessage(Vertx vertx, java.util.UUID instanceId, Handler<String> instanceHandler) {
		sendMessage(vertx, "new.VertxCoreGroup.deployVerticleProgrammatically", instanceId.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("senddeployVerticleProgrammaticallyMessage failed");
			}
		});
	}

	public static void sendToStringMessage(Vertx vertx, java.util.UUID id, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".toString", id.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendToStringMessage " + id + ".toString failed", t);
			}
	});
}      


	 public static void sendOnFailMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".onFail", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendOnFailMessage " + id + ".onFail failed", t);
			}
		});
	}  

	 public static void sendOnSuccessMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".onSuccess", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendOnSuccessMessage " + id + ".onSuccess failed", t);
			}
		});
	}  

	 public static void sendOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".options", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendOptionsMessage " + id + ".options failed", t);
			}
		});
	}  

	 public static void sendReferenceMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".reference", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendReferenceMessage " + id + ".reference failed", t);
			}
		});
	}  

	 public static void sendTypeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".type", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTypeMessage " + id + ".type failed", t);
			}
		});
	}  

	@Override
	public void start(Future<Void> startFuture) throws Exception {

		final VertxCoreGroup templateGroup = new VertxCoreGroup();

		consume(vertx, deploymentID(), "new.VertxCoreGroup.deployVerticleProgrammatically", log, new Handler<Message<String> >() {
			@Override
			public void handle(Message<String> idMessage) {

				// new instance of template
				final VertxCoreGroup.deployVerticleProgrammaticallyST template = templateGroup.newdeployVerticleProgrammatically();





				 // string property onFail
				consume(vertx, deploymentID(), idMessage.body() + ".onFail", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setOnFail(message.body());
						message.reply(message.body());
					}
				});     




				 // string property onSuccess
				consume(vertx, deploymentID(), idMessage.body() + ".onSuccess", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setOnSuccess(message.body());
						message.reply(message.body());
					}
				});     




				 // string property options
				consume(vertx, deploymentID(), idMessage.body() + ".options", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property reference
				consume(vertx, deploymentID(), idMessage.body() + ".reference", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setReference(message.body());
						message.reply(message.body());
					}
				});     




				 // string property type
				consume(vertx, deploymentID(), idMessage.body() + ".type", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setType(message.body());
						message.reply(message.body());
					}
				});     

				// toString
				consume(vertx, deploymentID(), idMessage.body() + ".toString", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						message.reply(template.toString());
					}
				});

				// other convenience methods here

				idMessage.reply(idMessage.body());
			}
		});

		startFuture.complete();
	}

	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		super.stop(stopFuture);
	}
}   