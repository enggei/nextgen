

 package com.generator.generators.vertxCore.vertx;

import com.generator.util.VertxUtil;
import com.generator.generators.vertxCore.VertxCoreGroup;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

import static com.generator.util.VertxUtil.*;

/**
 * goe on 5/20/16.
 */
public class httpClientOptionsVerticle extends AbstractVerticle {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(httpClientOptionsVerticle.class);

	public static void sendInstanceMessage(Vertx vertx, java.util.UUID instanceId, Handler<String> instanceHandler) {
		sendMessage(vertx, "new.VertxCoreGroup.httpClientOptions", instanceId.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendhttpClientOptionsMessage failed");
			}
		});
	}

	public static void sendToStringMessage(Vertx vertx, java.util.UUID id, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".toString", id.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendToStringMessage " + id + ".toString failed", t);
			}
	});
}      


	 public static void sendConnectTimeoutMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".connectTimeout", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendConnectTimeoutMessage " + id + ".connectTimeout failed", t);
			}
		});
	}  

	 public static void sendDefaultHostMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".defaultHost", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendDefaultHostMessage " + id + ".defaultHost failed", t);
			}
		});
	}  

	 public static void sendDefaultPortMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".defaultPort", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendDefaultPortMessage " + id + ".defaultPort failed", t);
			}
		});
	}  

	 public static void sendIdleTimeoutMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".idleTimeout", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendIdleTimeoutMessage " + id + ".idleTimeout failed", t);
			}
		});
	}  

	 public static void sendKeepAliveMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".keepAlive", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendKeepAliveMessage " + id + ".keepAlive failed", t);
			}
		});
	}  

	 public static void sendKeyStoreOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".keyStoreOptions", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendKeyStoreOptionsMessage " + id + ".keyStoreOptions failed", t);
			}
		});
	}  

	 public static void sendMaxPoolSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".maxPoolSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendMaxPoolSizeMessage " + id + ".maxPoolSize failed", t);
			}
		});
	}  

	 public static void sendMaxWebsocketFrameSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".maxWebsocketFrameSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendMaxWebsocketFrameSizeMessage " + id + ".maxWebsocketFrameSize failed", t);
			}
		});
	}  

	 public static void sendPemKeyCertOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".pemKeyCertOptions", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPemKeyCertOptionsMessage " + id + ".pemKeyCertOptions failed", t);
			}
		});
	}  

	 public static void sendPemTrustOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".pemTrustOptions", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPemTrustOptionsMessage " + id + ".pemTrustOptions failed", t);
			}
		});
	}  

	 public static void sendPfxKeycertOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".pfxKeycertOptions", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPfxKeycertOptionsMessage " + id + ".pfxKeycertOptions failed", t);
			}
		});
	}  

	 public static void sendPfxTrustOptionsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".pfxTrustOptions", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPfxTrustOptionsMessage " + id + ".pfxTrustOptions failed", t);
			}
		});
	}  

	 public static void sendPipeliningMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".pipelining", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPipeliningMessage " + id + ".pipelining failed", t);
			}
		});
	}  

	 public static void sendProtocolVersionMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".protocolVersion", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendProtocolVersionMessage " + id + ".protocolVersion failed", t);
			}
		});
	}  

	 public static void sendReceiveBufferSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".receiveBufferSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendReceiveBufferSizeMessage " + id + ".receiveBufferSize failed", t);
			}
		});
	}  

	 public static void sendReferenceMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".reference", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendReferenceMessage " + id + ".reference failed", t);
			}
		});
	}  

	 public static void sendReuseAddressMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".reuseAddress", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendReuseAddressMessage " + id + ".reuseAddress failed", t);
			}
		});
	}  

	 public static void sendSendBufferSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".sendBufferSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendSendBufferSizeMessage " + id + ".sendBufferSize failed", t);
			}
		});
	}  

	 public static void sendSoLingerMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".soLinger", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendSoLingerMessage " + id + ".soLinger failed", t);
			}
		});
	}  

	 public static void sendSslMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".ssl", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendSslMessage " + id + ".ssl failed", t);
			}
		});
	}  

	 public static void sendTcpKeepAliveMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".tcpKeepAlive", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTcpKeepAliveMessage " + id + ".tcpKeepAlive failed", t);
			}
		});
	}  

	 public static void sendTcpNoDelayMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".tcpNoDelay", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTcpNoDelayMessage " + id + ".tcpNoDelay failed", t);
			}
		});
	}  

	 public static void sendTrafficClassMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".trafficClass", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTrafficClassMessage " + id + ".trafficClass failed", t);
			}
		});
	}  

	 public static void sendTrustAllMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".trustAll", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTrustAllMessage " + id + ".trustAll failed", t);
			}
		});
	}  

	 public static void sendTrustStoreMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".trustStore", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTrustStoreMessage " + id + ".trustStore failed", t);
			}
		});
	}  

	 public static void sendTryUseCompressionMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".tryUseCompression", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendTryUseCompressionMessage " + id + ".tryUseCompression failed", t);
			}
		});
	}  

	 public static void sendUsePooledBuffersMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".usePooledBuffers", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendUsePooledBuffersMessage " + id + ".usePooledBuffers failed", t);
			}
		});
	}  

	 public static void sendVerifyHostMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".verifyHost", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendVerifyHostMessage " + id + ".verifyHost failed", t);
			}
		});
	}  

	@Override
	public void start(Future<Void> startFuture) throws Exception {

		final VertxCoreGroup templateGroup = new VertxCoreGroup();

		consume(vertx, deploymentID(), "new.VertxCoreGroup.httpClientOptions", log, new Handler<Message<String> >() {
			@Override
			public void handle(Message<String> idMessage) {

				// new instance of template
				final VertxCoreGroup.httpClientOptionsST template = templateGroup.newhttpClientOptions();





				 // string property connectTimeout
				consume(vertx, deploymentID(), idMessage.body() + ".connectTimeout", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setConnectTimeout(message.body());
						message.reply(message.body());
					}
				});     




				 // string property defaultHost
				consume(vertx, deploymentID(), idMessage.body() + ".defaultHost", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setDefaultHost(message.body());
						message.reply(message.body());
					}
				});     




				 // string property defaultPort
				consume(vertx, deploymentID(), idMessage.body() + ".defaultPort", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setDefaultPort(message.body());
						message.reply(message.body());
					}
				});     




				 // string property idleTimeout
				consume(vertx, deploymentID(), idMessage.body() + ".idleTimeout", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setIdleTimeout(message.body());
						message.reply(message.body());
					}
				});     




				 // string property keepAlive
				consume(vertx, deploymentID(), idMessage.body() + ".keepAlive", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setKeepAlive(message.body());
						message.reply(message.body());
					}
				});     




				 // string property keyStoreOptions
				consume(vertx, deploymentID(), idMessage.body() + ".keyStoreOptions", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setKeyStoreOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property maxPoolSize
				consume(vertx, deploymentID(), idMessage.body() + ".maxPoolSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setMaxPoolSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property maxWebsocketFrameSize
				consume(vertx, deploymentID(), idMessage.body() + ".maxWebsocketFrameSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setMaxWebsocketFrameSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property pemKeyCertOptions
				consume(vertx, deploymentID(), idMessage.body() + ".pemKeyCertOptions", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPemKeyCertOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property pemTrustOptions
				consume(vertx, deploymentID(), idMessage.body() + ".pemTrustOptions", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPemTrustOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property pfxKeycertOptions
				consume(vertx, deploymentID(), idMessage.body() + ".pfxKeycertOptions", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPfxKeycertOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property pfxTrustOptions
				consume(vertx, deploymentID(), idMessage.body() + ".pfxTrustOptions", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPfxTrustOptions(message.body());
						message.reply(message.body());
					}
				});     




				 // string property pipelining
				consume(vertx, deploymentID(), idMessage.body() + ".pipelining", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPipelining(message.body());
						message.reply(message.body());
					}
				});     




				 // string property protocolVersion
				consume(vertx, deploymentID(), idMessage.body() + ".protocolVersion", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setProtocolVersion(message.body());
						message.reply(message.body());
					}
				});     




				 // string property receiveBufferSize
				consume(vertx, deploymentID(), idMessage.body() + ".receiveBufferSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setReceiveBufferSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property reference
				consume(vertx, deploymentID(), idMessage.body() + ".reference", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setReference(message.body());
						message.reply(message.body());
					}
				});     




				 // string property reuseAddress
				consume(vertx, deploymentID(), idMessage.body() + ".reuseAddress", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setReuseAddress(message.body());
						message.reply(message.body());
					}
				});     




				 // string property sendBufferSize
				consume(vertx, deploymentID(), idMessage.body() + ".sendBufferSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setSendBufferSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property soLinger
				consume(vertx, deploymentID(), idMessage.body() + ".soLinger", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setSoLinger(message.body());
						message.reply(message.body());
					}
				});     




				 // string property ssl
				consume(vertx, deploymentID(), idMessage.body() + ".ssl", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setSsl(message.body());
						message.reply(message.body());
					}
				});     




				 // string property tcpKeepAlive
				consume(vertx, deploymentID(), idMessage.body() + ".tcpKeepAlive", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTcpKeepAlive(message.body());
						message.reply(message.body());
					}
				});     




				 // string property tcpNoDelay
				consume(vertx, deploymentID(), idMessage.body() + ".tcpNoDelay", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTcpNoDelay(message.body());
						message.reply(message.body());
					}
				});     




				 // string property trafficClass
				consume(vertx, deploymentID(), idMessage.body() + ".trafficClass", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTrafficClass(message.body());
						message.reply(message.body());
					}
				});     




				 // string property trustAll
				consume(vertx, deploymentID(), idMessage.body() + ".trustAll", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTrustAll(message.body());
						message.reply(message.body());
					}
				});     




				 // string property trustStore
				consume(vertx, deploymentID(), idMessage.body() + ".trustStore", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTrustStore(message.body());
						message.reply(message.body());
					}
				});     




				 // string property tryUseCompression
				consume(vertx, deploymentID(), idMessage.body() + ".tryUseCompression", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setTryUseCompression(message.body());
						message.reply(message.body());
					}
				});     




				 // string property usePooledBuffers
				consume(vertx, deploymentID(), idMessage.body() + ".usePooledBuffers", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setUsePooledBuffers(message.body());
						message.reply(message.body());
					}
				});     




				 // string property verifyHost
				consume(vertx, deploymentID(), idMessage.body() + ".verifyHost", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setVerifyHost(message.body());
						message.reply(message.body());
					}
				});     

				// toString
				consume(vertx, deploymentID(), idMessage.body() + ".toString", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						message.reply(template.toString());
					}
				});

				// other convenience methods here

				idMessage.reply(idMessage.body());
			}
		});

		startFuture.complete();
	}

	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		super.stop(stopFuture);
	}
}   