 package com.generator.generators.vertxCore;

 import com.generator.editors.domain.NeoModel;
 import org.neo4j.graphdb.Node;
 import org.neo4j.graphdb.Relationship;

 import java.util.UUID;

 import static com.generator.editors.domain.BaseDomainVisitor.*;

/**
 * Wraps Neo4j methods based on 'VertxCore.stg' file <br/>	VertxCore
 */
public final class VertxCoreNeo {

	private static final VertxCoreGroup group = new VertxCoreGroup();

	private final NeoModel model;

   public VertxCoreNeo(final NeoModel model) {
 		this.model = model;
	}

    public appendBufferNode newappendBuffer() {
   	return new appendBufferNode(model, NeoModel.uuidOf(model.newNode("appendBuffer", UUID.randomUUID())));
   }

   public appendBufferNode getappendBuffer(UUID uuid) {
   	return new appendBufferNode(model, uuid);
   } 

    public asynchFileNode newasynchFile() {
   	return new asynchFileNode(model, NeoModel.uuidOf(model.newNode("asynchFile", UUID.randomUUID())));
   }

   public asynchFileNode getasynchFile(UUID uuid) {
   	return new asynchFileNode(model, uuid);
   } 

    public asynchVerticleStopNode newasynchVerticleStop() {
   	return new asynchVerticleStopNode(model, NeoModel.uuidOf(model.newNode("asynchVerticleStop", UUID.randomUUID())));
   }

   public asynchVerticleStopNode getasynchVerticleStop(UUID uuid) {
   	return new asynchVerticleStopNode(model, uuid);
   } 

    public blockMulticastNode newblockMulticast() {
   	return new blockMulticastNode(model, NeoModel.uuidOf(model.newNode("blockMulticast", UUID.randomUUID())));
   }

   public blockMulticastNode getblockMulticast(UUID uuid) {
   	return new blockMulticastNode(model, uuid);
   } 

    public blockingCodeNode newblockingCode() {
   	return new blockingCodeNode(model, NeoModel.uuidOf(model.newNode("blockingCode", UUID.randomUUID())));
   }

   public blockingCodeNode getblockingCode(UUID uuid) {
   	return new blockingCodeNode(model, uuid);
   } 

    public bodyHandlerNode newbodyHandler() {
   	return new bodyHandlerNode(model, NeoModel.uuidOf(model.newNode("bodyHandler", UUID.randomUUID())));
   }

   public bodyHandlerNode getbodyHandler(UUID uuid) {
   	return new bodyHandlerNode(model, uuid);
   } 

    public bufCopyNode newbufCopy() {
   	return new bufCopyNode(model, NeoModel.uuidOf(model.newNode("bufCopy", UUID.randomUUID())));
   }

   public bufCopyNode getbufCopy(UUID uuid) {
   	return new bufCopyNode(model, uuid);
   } 

    public bufLengthNode newbufLength() {
   	return new bufLengthNode(model, NeoModel.uuidOf(model.newNode("bufLength", UUID.randomUUID())));
   }

   public bufLengthNode getbufLength(UUID uuid) {
   	return new bufLengthNode(model, uuid);
   } 

    public bufSliceNode newbufSlice() {
   	return new bufSliceNode(model, NeoModel.uuidOf(model.newNode("bufSlice", UUID.randomUUID())));
   }

   public bufSliceNode getbufSlice(UUID uuid) {
   	return new bufSliceNode(model, uuid);
   } 

    public bugfixNode newbugfix() {
   	return new bugfixNode(model, NeoModel.uuidOf(model.newNode("bugfix", UUID.randomUUID())));
   }

   public bugfixNode getbugfix(UUID uuid) {
   	return new bugfixNode(model, uuid);
   } 

    public cancelTimerNode newcancelTimer() {
   	return new cancelTimerNode(model, NeoModel.uuidOf(model.newNode("cancelTimer", UUID.randomUUID())));
   }

   public cancelTimerNode getcancelTimer(UUID uuid) {
   	return new cancelTimerNode(model, uuid);
   } 

    public checkExistenceAndDeleteNode newcheckExistenceAndDelete() {
   	return new checkExistenceAndDeleteNode(model, NeoModel.uuidOf(model.newNode("checkExistenceAndDelete", UUID.randomUUID())));
   }

   public checkExistenceAndDeleteNode getcheckExistenceAndDelete(UUID uuid) {
   	return new checkExistenceAndDeleteNode(model, uuid);
   } 

    public chunkFileUploadHandlerNode newchunkFileUploadHandler() {
   	return new chunkFileUploadHandlerNode(model, NeoModel.uuidOf(model.newNode("chunkFileUploadHandler", UUID.randomUUID())));
   }

   public chunkFileUploadHandlerNode getchunkFileUploadHandler(UUID uuid) {
   	return new chunkFileUploadHandlerNode(model, uuid);
   } 

    public clientConnectNode newclientConnect() {
   	return new clientConnectNode(model, NeoModel.uuidOf(model.newNode("clientConnect", UUID.randomUUID())));
   }

   public clientConnectNode getclientConnect(UUID uuid) {
   	return new clientConnectNode(model, uuid);
   } 

    public clientRequestNode newclientRequest() {
   	return new clientRequestNode(model, NeoModel.uuidOf(model.newNode("clientRequest", UUID.randomUUID())));
   }

   public clientRequestNode getclientRequest(UUID uuid) {
   	return new clientRequestNode(model, uuid);
   } 

    public clientSSLNode newclientSSL() {
   	return new clientSSLNode(model, NeoModel.uuidOf(model.newNode("clientSSL", UUID.randomUUID())));
   }

   public clientSSLNode getclientSSL(UUID uuid) {
   	return new clientSSLNode(model, uuid);
   } 

    public clientSSLKeystoreAuthNode newclientSSLKeystoreAuth() {
   	return new clientSSLKeystoreAuthNode(model, NeoModel.uuidOf(model.newNode("clientSSLKeystoreAuth", UUID.randomUUID())));
   }

   public clientSSLKeystoreAuthNode getclientSSLKeystoreAuth(UUID uuid) {
   	return new clientSSLKeystoreAuthNode(model, uuid);
   } 

    public clientSSLKeystoreAuthBufferNode newclientSSLKeystoreAuthBuffer() {
   	return new clientSSLKeystoreAuthBufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLKeystoreAuthBuffer", UUID.randomUUID())));
   }

   public clientSSLKeystoreAuthBufferNode getclientSSLKeystoreAuthBuffer(UUID uuid) {
   	return new clientSSLKeystoreAuthBufferNode(model, uuid);
   } 

    public clientSSLPEMNode newclientSSLPEM() {
   	return new clientSSLPEMNode(model, NeoModel.uuidOf(model.newNode("clientSSLPEM", UUID.randomUUID())));
   }

   public clientSSLPEMNode getclientSSLPEM(UUID uuid) {
   	return new clientSSLPEMNode(model, uuid);
   } 

    public clientSSLPEMAuthNode newclientSSLPEMAuth() {
   	return new clientSSLPEMAuthNode(model, NeoModel.uuidOf(model.newNode("clientSSLPEMAuth", UUID.randomUUID())));
   }

   public clientSSLPEMAuthNode getclientSSLPEMAuth(UUID uuid) {
   	return new clientSSLPEMAuthNode(model, uuid);
   } 

    public clientSSLPEMAuthBufferNode newclientSSLPEMAuthBuffer() {
   	return new clientSSLPEMAuthBufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLPEMAuthBuffer", UUID.randomUUID())));
   }

   public clientSSLPEMAuthBufferNode getclientSSLPEMAuthBuffer(UUID uuid) {
   	return new clientSSLPEMAuthBufferNode(model, uuid);
   } 

    public clientSSLPEMBufferNode newclientSSLPEMBuffer() {
   	return new clientSSLPEMBufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLPEMBuffer", UUID.randomUUID())));
   }

   public clientSSLPEMBufferNode getclientSSLPEMBuffer(UUID uuid) {
   	return new clientSSLPEMBufferNode(model, uuid);
   } 

    public clientSSLPKCSAuthNode newclientSSLPKCSAuth() {
   	return new clientSSLPKCSAuthNode(model, NeoModel.uuidOf(model.newNode("clientSSLPKCSAuth", UUID.randomUUID())));
   }

   public clientSSLPKCSAuthNode getclientSSLPKCSAuth(UUID uuid) {
   	return new clientSSLPKCSAuthNode(model, uuid);
   } 

    public clientSSLPKCSAuthBufferNode newclientSSLPKCSAuthBuffer() {
   	return new clientSSLPKCSAuthBufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLPKCSAuthBuffer", UUID.randomUUID())));
   }

   public clientSSLPKCSAuthBufferNode getclientSSLPKCSAuthBuffer(UUID uuid) {
   	return new clientSSLPKCSAuthBufferNode(model, uuid);
   } 

    public clientSSLPKCS_12Node newclientSSLPKCS_12() {
   	return new clientSSLPKCS_12Node(model, NeoModel.uuidOf(model.newNode("clientSSLPKCS_12", UUID.randomUUID())));
   }

   public clientSSLPKCS_12Node getclientSSLPKCS_12(UUID uuid) {
   	return new clientSSLPKCS_12Node(model, uuid);
   } 

    public clientSSLPKCS_12BufferNode newclientSSLPKCS_12Buffer() {
   	return new clientSSLPKCS_12BufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLPKCS_12Buffer", UUID.randomUUID())));
   }

   public clientSSLPKCS_12BufferNode getclientSSLPKCS_12Buffer(UUID uuid) {
   	return new clientSSLPKCS_12BufferNode(model, uuid);
   } 

    public clientSSLTruststoreNode newclientSSLTruststore() {
   	return new clientSSLTruststoreNode(model, NeoModel.uuidOf(model.newNode("clientSSLTruststore", UUID.randomUUID())));
   }

   public clientSSLTruststoreNode getclientSSLTruststore(UUID uuid) {
   	return new clientSSLTruststoreNode(model, uuid);
   } 

    public clientSSLTruststoreBufferNode newclientSSLTruststoreBuffer() {
   	return new clientSSLTruststoreBufferNode(model, NeoModel.uuidOf(model.newNode("clientSSLTruststoreBuffer", UUID.randomUUID())));
   }

   public clientSSLTruststoreBufferNode getclientSSLTruststoreBuffer(UUID uuid) {
   	return new clientSSLTruststoreBufferNode(model, uuid);
   } 

    public clientWebsocketNode newclientWebsocket() {
   	return new clientWebsocketNode(model, NeoModel.uuidOf(model.newNode("clientWebsocket", UUID.randomUUID())));
   }

   public clientWebsocketNode getclientWebsocket(UUID uuid) {
   	return new clientWebsocketNode(model, uuid);
   } 

    public closeServerNode newcloseServer() {
   	return new closeServerNode(model, NeoModel.uuidOf(model.newNode("closeServer", UUID.randomUUID())));
   }

   public closeServerNode getcloseServer(UUID uuid) {
   	return new closeServerNode(model, uuid);
   } 

    public clusterCommandLineNode newclusterCommandLine() {
   	return new clusterCommandLineNode(model, NeoModel.uuidOf(model.newNode("clusterCommandLine", UUID.randomUUID())));
   }

   public clusterCommandLineNode getclusterCommandLine(UUID uuid) {
   	return new clusterCommandLineNode(model, uuid);
   } 

    public clusterCounterNode newclusterCounter() {
   	return new clusterCounterNode(model, NeoModel.uuidOf(model.newNode("clusterCounter", UUID.randomUUID())));
   }

   public clusterCounterNode getclusterCounter(UUID uuid) {
   	return new clusterCounterNode(model, uuid);
   } 

    public clusterProgrammaticallyNode newclusterProgrammatically() {
   	return new clusterProgrammaticallyNode(model, NeoModel.uuidOf(model.newNode("clusterProgrammatically", UUID.randomUUID())));
   }

   public clusterProgrammaticallyNode getclusterProgrammatically(UUID uuid) {
   	return new clusterProgrammaticallyNode(model, uuid);
   } 

    public clusterSharedMapNode newclusterSharedMap() {
   	return new clusterSharedMapNode(model, NeoModel.uuidOf(model.newNode("clusterSharedMap", UUID.randomUUID())));
   }

   public clusterSharedMapNode getclusterSharedMap(UUID uuid) {
   	return new clusterSharedMapNode(model, uuid);
   } 

    public clusterWideLockNode newclusterWideLock() {
   	return new clusterWideLockNode(model, NeoModel.uuidOf(model.newNode("clusterWideLock", UUID.randomUUID())));
   }

   public clusterWideLockNode getclusterWideLock(UUID uuid) {
   	return new clusterWideLockNode(model, uuid);
   } 

    public clusterWideLockTimeoutNode newclusterWideLockTimeout() {
   	return new clusterWideLockTimeoutNode(model, NeoModel.uuidOf(model.newNode("clusterWideLockTimeout", UUID.randomUUID())));
   }

   public clusterWideLockTimeoutNode getclusterWideLockTimeout(UUID uuid) {
   	return new clusterWideLockTimeoutNode(model, uuid);
   } 

    public cmdHighAvailabilityNode newcmdHighAvailability() {
   	return new cmdHighAvailabilityNode(model, NeoModel.uuidOf(model.newNode("cmdHighAvailability", UUID.randomUUID())));
   }

   public cmdHighAvailabilityNode getcmdHighAvailability(UUID uuid) {
   	return new cmdHighAvailabilityNode(model, uuid);
   } 

    public cmdRunVerticlesNode newcmdRunVerticles() {
   	return new cmdRunVerticlesNode(model, NeoModel.uuidOf(model.newNode("cmdRunVerticles", UUID.randomUUID())));
   }

   public cmdRunVerticlesNode getcmdRunVerticles(UUID uuid) {
   	return new cmdRunVerticlesNode(model, uuid);
   } 

    public configGetIntegerNode newconfigGetInteger() {
   	return new configGetIntegerNode(model, NeoModel.uuidOf(model.newNode("configGetInteger", UUID.randomUUID())));
   }

   public configGetIntegerNode getconfigGetInteger(UUID uuid) {
   	return new configGetIntegerNode(model, uuid);
   } 

    public configGetStringNode newconfigGetString() {
   	return new configGetStringNode(model, NeoModel.uuidOf(model.newNode("configGetString", UUID.randomUUID())));
   }

   public configGetStringNode getconfigGetString(UUID uuid) {
   	return new configGetStringNode(model, uuid);
   } 

    public configureCipherSuiteNode newconfigureCipherSuite() {
   	return new configureCipherSuiteNode(model, NeoModel.uuidOf(model.newNode("configureCipherSuite", UUID.randomUUID())));
   }

   public configureCipherSuiteNode getconfigureCipherSuite(UUID uuid) {
   	return new configureCipherSuiteNode(model, uuid);
   } 

    public consumerCompletionHandlerNode newconsumerCompletionHandler() {
   	return new consumerCompletionHandlerNode(model, NeoModel.uuidOf(model.newNode("consumerCompletionHandler", UUID.randomUUID())));
   }

   public consumerCompletionHandlerNode getconsumerCompletionHandler(UUID uuid) {
   	return new consumerCompletionHandlerNode(model, uuid);
   } 

    public contextSharedDataNode newcontextSharedData() {
   	return new contextSharedDataNode(model, NeoModel.uuidOf(model.newNode("contextSharedData", UUID.randomUUID())));
   }

   public contextSharedDataNode getcontextSharedData(UUID uuid) {
   	return new contextSharedDataNode(model, uuid);
   } 

    public contextTypeNode newcontextType() {
   	return new contextTypeNode(model, NeoModel.uuidOf(model.newNode("contextType", UUID.randomUUID())));
   }

   public contextTypeNode getcontextType(UUID uuid) {
   	return new contextTypeNode(model, uuid);
   } 

    public copyFileAsynchNode newcopyFileAsynch() {
   	return new copyFileAsynchNode(model, NeoModel.uuidOf(model.newNode("copyFileAsynch", UUID.randomUUID())));
   }

   public copyFileAsynchNode getcopyFileAsynch(UUID uuid) {
   	return new copyFileAsynchNode(model, uuid);
   } 

    public copyFileSynchNode newcopyFileSynch() {
   	return new copyFileSynchNode(model, NeoModel.uuidOf(model.newNode("copyFileSynch", UUID.randomUUID())));
   }

   public copyFileSynchNode getcopyFileSynch(UUID uuid) {
   	return new copyFileSynchNode(model, uuid);
   } 

    public deployPolyVerticlesNode newdeployPolyVerticles() {
   	return new deployPolyVerticlesNode(model, NeoModel.uuidOf(model.newNode("deployPolyVerticles", UUID.randomUUID())));
   }

   public deployPolyVerticlesNode getdeployPolyVerticles(UUID uuid) {
   	return new deployPolyVerticlesNode(model, uuid);
   } 

    public deployVerticleProgrammaticallyNode newdeployVerticleProgrammatically() {
   	return new deployVerticleProgrammaticallyNode(model, NeoModel.uuidOf(model.newNode("deployVerticleProgrammatically", UUID.randomUUID())));
   }

   public deployVerticleProgrammaticallyNode getdeployVerticleProgrammatically(UUID uuid) {
   	return new deployVerticleProgrammaticallyNode(model, uuid);
   } 

    public deployVerticleStartNode newdeployVerticleStart() {
   	return new deployVerticleStartNode(model, NeoModel.uuidOf(model.newNode("deployVerticleStart", UUID.randomUUID())));
   }

   public deployVerticleStartNode getdeployVerticleStart(UUID uuid) {
   	return new deployVerticleStartNode(model, uuid);
   } 

    public dnsClientNode newdnsClient() {
   	return new dnsClientNode(model, NeoModel.uuidOf(model.newNode("dnsClient", UUID.randomUUID())));
   }

   public dnsClientNode getdnsClient(UUID uuid) {
   	return new dnsClientNode(model, uuid);
   } 

    public dnsLookupNode newdnsLookup() {
   	return new dnsLookupNode(model, NeoModel.uuidOf(model.newNode("dnsLookup", UUID.randomUUID())));
   }

   public dnsLookupNode getdnsLookup(UUID uuid) {
   	return new dnsLookupNode(model, uuid);
   } 

    public dnsLookup4Node newdnsLookup4() {
   	return new dnsLookup4Node(model, NeoModel.uuidOf(model.newNode("dnsLookup4", UUID.randomUUID())));
   }

   public dnsLookup4Node getdnsLookup4(UUID uuid) {
   	return new dnsLookup4Node(model, uuid);
   } 

    public dnsLookup6Node newdnsLookup6() {
   	return new dnsLookup6Node(model, NeoModel.uuidOf(model.newNode("dnsLookup6", UUID.randomUUID())));
   }

   public dnsLookup6Node getdnsLookup6(UUID uuid) {
   	return new dnsLookup6Node(model, uuid);
   } 

    public dnsResolveANode newdnsResolveA() {
   	return new dnsResolveANode(model, NeoModel.uuidOf(model.newNode("dnsResolveA", UUID.randomUUID())));
   }

   public dnsResolveANode getdnsResolveA(UUID uuid) {
   	return new dnsResolveANode(model, uuid);
   } 

    public dnsResolveAAAANode newdnsResolveAAAA() {
   	return new dnsResolveAAAANode(model, NeoModel.uuidOf(model.newNode("dnsResolveAAAA", UUID.randomUUID())));
   }

   public dnsResolveAAAANode getdnsResolveAAAA(UUID uuid) {
   	return new dnsResolveAAAANode(model, uuid);
   } 

    public dnsResolveCNAMENode newdnsResolveCNAME() {
   	return new dnsResolveCNAMENode(model, NeoModel.uuidOf(model.newNode("dnsResolveCNAME", UUID.randomUUID())));
   }

   public dnsResolveCNAMENode getdnsResolveCNAME(UUID uuid) {
   	return new dnsResolveCNAMENode(model, uuid);
   } 

    public dnsResolveMXNode newdnsResolveMX() {
   	return new dnsResolveMXNode(model, NeoModel.uuidOf(model.newNode("dnsResolveMX", UUID.randomUUID())));
   }

   public dnsResolveMXNode getdnsResolveMX(UUID uuid) {
   	return new dnsResolveMXNode(model, uuid);
   } 

    public dnsResolveNSNode newdnsResolveNS() {
   	return new dnsResolveNSNode(model, NeoModel.uuidOf(model.newNode("dnsResolveNS", UUID.randomUUID())));
   }

   public dnsResolveNSNode getdnsResolveNS(UUID uuid) {
   	return new dnsResolveNSNode(model, uuid);
   } 

    public dnsResolvePTRNode newdnsResolvePTR() {
   	return new dnsResolvePTRNode(model, NeoModel.uuidOf(model.newNode("dnsResolvePTR", UUID.randomUUID())));
   }

   public dnsResolvePTRNode getdnsResolvePTR(UUID uuid) {
   	return new dnsResolvePTRNode(model, uuid);
   } 

    public dnsResolveSRVNode newdnsResolveSRV() {
   	return new dnsResolveSRVNode(model, NeoModel.uuidOf(model.newNode("dnsResolveSRV", UUID.randomUUID())));
   }

   public dnsResolveSRVNode getdnsResolveSRV(UUID uuid) {
   	return new dnsResolveSRVNode(model, uuid);
   } 

    public dnsResolveTXTNode newdnsResolveTXT() {
   	return new dnsResolveTXTNode(model, NeoModel.uuidOf(model.newNode("dnsResolveTXT", UUID.randomUUID())));
   }

   public dnsResolveTXTNode getdnsResolveTXT(UUID uuid) {
   	return new dnsResolveTXTNode(model, uuid);
   } 

    public dnsResponseCodeNode newdnsResponseCode() {
   	return new dnsResponseCodeNode(model, NeoModel.uuidOf(model.newNode("dnsResponseCode", UUID.randomUUID())));
   }

   public dnsResponseCodeNode getdnsResponseCode(UUID uuid) {
   	return new dnsResponseCodeNode(model, uuid);
   } 

    public dnsReverseLookupNode newdnsReverseLookup() {
   	return new dnsReverseLookupNode(model, NeoModel.uuidOf(model.newNode("dnsReverseLookup", UUID.randomUUID())));
   }

   public dnsReverseLookupNode getdnsReverseLookup(UUID uuid) {
   	return new dnsReverseLookupNode(model, uuid);
   } 

    public ebConsumeNode newebConsume() {
   	return new ebConsumeNode(model, NeoModel.uuidOf(model.newNode("ebConsume", UUID.randomUUID())));
   }

   public ebConsumeNode getebConsume(UUID uuid) {
   	return new ebConsumeNode(model, uuid);
   } 

    public ebPublishNode newebPublish() {
   	return new ebPublishNode(model, NeoModel.uuidOf(model.newNode("ebPublish", UUID.randomUUID())));
   }

   public ebPublishNode getebPublish(UUID uuid) {
   	return new ebPublishNode(model, uuid);
   } 

    public encodeArrayNode newencodeArray() {
   	return new encodeArrayNode(model, NeoModel.uuidOf(model.newNode("encodeArray", UUID.randomUUID())));
   }

   public encodeArrayNode getencodeArray(UUID uuid) {
   	return new encodeArrayNode(model, uuid);
   } 

    public fileStreamNode newfileStream() {
   	return new fileStreamNode(model, NeoModel.uuidOf(model.newNode("fileStream", UUID.randomUUID())));
   }

   public fileStreamNode getfileStream(UUID uuid) {
   	return new fileStreamNode(model, uuid);
   } 

    public formFileStreamUploadNode newformFileStreamUpload() {
   	return new formFileStreamUploadNode(model, NeoModel.uuidOf(model.newNode("formFileStreamUpload", UUID.randomUUID())));
   }

   public formFileStreamUploadNode getformFileStreamUpload(UUID uuid) {
   	return new formFileStreamUploadNode(model, uuid);
   } 

    public formFileUploadHandlerNode newformFileUploadHandler() {
   	return new formFileUploadHandlerNode(model, NeoModel.uuidOf(model.newNode("formFileUploadHandler", UUID.randomUUID())));
   }

   public formFileUploadHandlerNode getformFileUploadHandler(UUID uuid) {
   	return new formFileUploadHandlerNode(model, uuid);
   } 

    public formHandlerNode newformHandler() {
   	return new formHandlerNode(model, NeoModel.uuidOf(model.newNode("formHandler", UUID.randomUUID())));
   }

   public formHandlerNode getformHandler(UUID uuid) {
   	return new formHandlerNode(model, uuid);
   } 

    public getDataFromMapNode newgetDataFromMap() {
   	return new getDataFromMapNode(model, NeoModel.uuidOf(model.newNode("getDataFromMap", UUID.randomUUID())));
   }

   public getDataFromMapNode getgetDataFromMap(UUID uuid) {
   	return new getDataFromMapNode(model, uuid);
   } 

    public getJsonNode newgetJson() {
   	return new getJsonNode(model, NeoModel.uuidOf(model.newNode("getJson", UUID.randomUUID())));
   }

   public getJsonNode getgetJson(UUID uuid) {
   	return new getJsonNode(model, uuid);
   } 

    public getJsonArrayNode newgetJsonArray() {
   	return new getJsonArrayNode(model, NeoModel.uuidOf(model.newNode("getJsonArray", UUID.randomUUID())));
   }

   public getJsonArrayNode getgetJsonArray(UUID uuid) {
   	return new getJsonArrayNode(model, uuid);
   } 

    public getRequestHeadersNode newgetRequestHeaders() {
   	return new getRequestHeadersNode(model, NeoModel.uuidOf(model.newNode("getRequestHeaders", UUID.randomUUID())));
   }

   public getRequestHeadersNode getgetRequestHeaders(UUID uuid) {
   	return new getRequestHeadersNode(model, uuid);
   } 

    public httpClientNode newhttpClient() {
   	return new httpClientNode(model, NeoModel.uuidOf(model.newNode("httpClient", UUID.randomUUID())));
   }

   public httpClientNode gethttpClient(UUID uuid) {
   	return new httpClientNode(model, uuid);
   } 

    public httpClientChunkedRequestNode newhttpClientChunkedRequest() {
   	return new httpClientChunkedRequestNode(model, NeoModel.uuidOf(model.newNode("httpClientChunkedRequest", UUID.randomUUID())));
   }

   public httpClientChunkedRequestNode gethttpClientChunkedRequest(UUID uuid) {
   	return new httpClientChunkedRequestNode(model, uuid);
   } 

    public httpClientContinueHandlingNode newhttpClientContinueHandling() {
   	return new httpClientContinueHandlingNode(model, NeoModel.uuidOf(model.newNode("httpClientContinueHandling", UUID.randomUUID())));
   }

   public httpClientContinueHandlingNode gethttpClientContinueHandling(UUID uuid) {
   	return new httpClientContinueHandlingNode(model, uuid);
   } 

    public httpClientEndRequestNode newhttpClientEndRequest() {
   	return new httpClientEndRequestNode(model, NeoModel.uuidOf(model.newNode("httpClientEndRequest", UUID.randomUUID())));
   }

   public httpClientEndRequestNode gethttpClientEndRequest(UUID uuid) {
   	return new httpClientEndRequestNode(model, uuid);
   } 

    public httpClientEndRequestBufferNode newhttpClientEndRequestBuffer() {
   	return new httpClientEndRequestBufferNode(model, NeoModel.uuidOf(model.newNode("httpClientEndRequestBuffer", UUID.randomUUID())));
   }

   public httpClientEndRequestBufferNode gethttpClientEndRequestBuffer(UUID uuid) {
   	return new httpClientEndRequestBufferNode(model, uuid);
   } 

    public httpClientHandleExceptionNode newhttpClientHandleException() {
   	return new httpClientHandleExceptionNode(model, NeoModel.uuidOf(model.newNode("httpClientHandleException", UUID.randomUUID())));
   }

   public httpClientHandleExceptionNode gethttpClientHandleException(UUID uuid) {
   	return new httpClientHandleExceptionNode(model, uuid);
   } 

    public httpClientHandleExceptionResponseNode newhttpClientHandleExceptionResponse() {
   	return new httpClientHandleExceptionResponseNode(model, NeoModel.uuidOf(model.newNode("httpClientHandleExceptionResponse", UUID.randomUUID())));
   }

   public httpClientHandleExceptionResponseNode gethttpClientHandleExceptionResponse(UUID uuid) {
   	return new httpClientHandleExceptionResponseNode(model, uuid);
   } 

    public httpClientOptionsNode newhttpClientOptions() {
   	return new httpClientOptionsNode(model, NeoModel.uuidOf(model.newNode("httpClientOptions", UUID.randomUUID())));
   }

   public httpClientOptionsNode gethttpClientOptions(UUID uuid) {
   	return new httpClientOptionsNode(model, uuid);
   } 

    public httpClientPumpFileNode newhttpClientPumpFile() {
   	return new httpClientPumpFileNode(model, NeoModel.uuidOf(model.newNode("httpClientPumpFile", UUID.randomUUID())));
   }

   public httpClientPumpFileNode gethttpClientPumpFile(UUID uuid) {
   	return new httpClientPumpFileNode(model, uuid);
   } 

    public httpClientPutRequestHeadersNode newhttpClientPutRequestHeaders() {
   	return new httpClientPutRequestHeadersNode(model, NeoModel.uuidOf(model.newNode("httpClientPutRequestHeaders", UUID.randomUUID())));
   }

   public httpClientPutRequestHeadersNode gethttpClientPutRequestHeaders(UUID uuid) {
   	return new httpClientPutRequestHeadersNode(model, uuid);
   } 

    public httpClientRequestTimeoutNode newhttpClientRequestTimeout() {
   	return new httpClientRequestTimeoutNode(model, NeoModel.uuidOf(model.newNode("httpClientRequestTimeout", UUID.randomUUID())));
   }

   public httpClientRequestTimeoutNode gethttpClientRequestTimeout(UUID uuid) {
   	return new httpClientRequestTimeoutNode(model, uuid);
   } 

    public httpClientResponseBodyChunkNode newhttpClientResponseBodyChunk() {
   	return new httpClientResponseBodyChunkNode(model, NeoModel.uuidOf(model.newNode("httpClientResponseBodyChunk", UUID.randomUUID())));
   }

   public httpClientResponseBodyChunkNode gethttpClientResponseBodyChunk(UUID uuid) {
   	return new httpClientResponseBodyChunkNode(model, uuid);
   } 

    public httpClientResponseBodyHandlerNode newhttpClientResponseBodyHandler() {
   	return new httpClientResponseBodyHandlerNode(model, NeoModel.uuidOf(model.newNode("httpClientResponseBodyHandler", UUID.randomUUID())));
   }

   public httpClientResponseBodyHandlerNode gethttpClientResponseBodyHandler(UUID uuid) {
   	return new httpClientResponseBodyHandlerNode(model, uuid);
   } 

    public httpClientResponseHandlerNode newhttpClientResponseHandler() {
   	return new httpClientResponseHandlerNode(model, NeoModel.uuidOf(model.newNode("httpClientResponseHandler", UUID.randomUUID())));
   }

   public httpClientResponseHandlerNode gethttpClientResponseHandler(UUID uuid) {
   	return new httpClientResponseHandlerNode(model, uuid);
   } 

    public httpClientResponseHeadersNode newhttpClientResponseHeaders() {
   	return new httpClientResponseHeadersNode(model, NeoModel.uuidOf(model.newNode("httpClientResponseHeaders", UUID.randomUUID())));
   }

   public httpClientResponseHeadersNode gethttpClientResponseHeaders(UUID uuid) {
   	return new httpClientResponseHeadersNode(model, uuid);
   } 

    public httpClientResponseInMemoryNode newhttpClientResponseInMemory() {
   	return new httpClientResponseInMemoryNode(model, NeoModel.uuidOf(model.newNode("httpClientResponseInMemory", UUID.randomUUID())));
   }

   public httpClientResponseInMemoryNode gethttpClientResponseInMemory(UUID uuid) {
   	return new httpClientResponseInMemoryNode(model, uuid);
   } 

    public httpClientSetRequestHeadersNode newhttpClientSetRequestHeaders() {
   	return new httpClientSetRequestHeadersNode(model, NeoModel.uuidOf(model.newNode("httpClientSetRequestHeaders", UUID.randomUUID())));
   }

   public httpClientSetRequestHeadersNode gethttpClientSetRequestHeaders(UUID uuid) {
   	return new httpClientSetRequestHeadersNode(model, uuid);
   } 

    public httpClientWriteToRequestNode newhttpClientWriteToRequest() {
   	return new httpClientWriteToRequestNode(model, NeoModel.uuidOf(model.newNode("httpClientWriteToRequest", UUID.randomUUID())));
   }

   public httpClientWriteToRequestNode gethttpClientWriteToRequest(UUID uuid) {
   	return new httpClientWriteToRequestNode(model, uuid);
   } 

    public httpResponseEndNode newhttpResponseEnd() {
   	return new httpResponseEndNode(model, NeoModel.uuidOf(model.newNode("httpResponseEnd", UUID.randomUUID())));
   }

   public httpResponseEndNode gethttpResponseEnd(UUID uuid) {
   	return new httpResponseEndNode(model, uuid);
   } 

    public httpResponsePutHeaderNode newhttpResponsePutHeader() {
   	return new httpResponsePutHeaderNode(model, NeoModel.uuidOf(model.newNode("httpResponsePutHeader", UUID.randomUUID())));
   }

   public httpResponsePutHeaderNode gethttpResponsePutHeader(UUID uuid) {
   	return new httpResponsePutHeaderNode(model, uuid);
   } 

    public httpResponsePutTrailersNode newhttpResponsePutTrailers() {
   	return new httpResponsePutTrailersNode(model, NeoModel.uuidOf(model.newNode("httpResponsePutTrailers", UUID.randomUUID())));
   }

   public httpResponsePutTrailersNode gethttpResponsePutTrailers(UUID uuid) {
   	return new httpResponsePutTrailersNode(model, uuid);
   } 

    public httpResponseSTartNode newhttpResponseSTart() {
   	return new httpResponseSTartNode(model, NeoModel.uuidOf(model.newNode("httpResponseSTart", UUID.randomUUID())));
   }

   public httpResponseSTartNode gethttpResponseSTart(UUID uuid) {
   	return new httpResponseSTartNode(model, uuid);
   } 

    public httpResponseSetHeaderNode newhttpResponseSetHeader() {
   	return new httpResponseSetHeaderNode(model, NeoModel.uuidOf(model.newNode("httpResponseSetHeader", UUID.randomUUID())));
   }

   public httpResponseSetHeaderNode gethttpResponseSetHeader(UUID uuid) {
   	return new httpResponseSetHeaderNode(model, uuid);
   } 

    public httpResponseSetTrailersNode newhttpResponseSetTrailers() {
   	return new httpResponseSetTrailersNode(model, NeoModel.uuidOf(model.newNode("httpResponseSetTrailers", UUID.randomUUID())));
   }

   public httpResponseSetTrailersNode gethttpResponseSetTrailers(UUID uuid) {
   	return new httpResponseSetTrailersNode(model, uuid);
   } 

    public httpResponseWriteNode newhttpResponseWrite() {
   	return new httpResponseWriteNode(model, NeoModel.uuidOf(model.newNode("httpResponseWrite", UUID.randomUUID())));
   }

   public httpResponseWriteNode gethttpResponseWrite(UUID uuid) {
   	return new httpResponseWriteNode(model, uuid);
   } 

    public httpServeFileNode newhttpServeFile() {
   	return new httpServeFileNode(model, NeoModel.uuidOf(model.newNode("httpServeFile", UUID.randomUUID())));
   }

   public httpServeFileNode gethttpServeFile(UUID uuid) {
   	return new httpServeFileNode(model, uuid);
   } 

    public httpServerNode newhttpServer() {
   	return new httpServerNode(model, NeoModel.uuidOf(model.newNode("httpServer", UUID.randomUUID())));
   }

   public httpServerNode gethttpServer(UUID uuid) {
   	return new httpServerNode(model, uuid);
   } 

    public httpServerIncomingNode newhttpServerIncoming() {
   	return new httpServerIncomingNode(model, NeoModel.uuidOf(model.newNode("httpServerIncoming", UUID.randomUUID())));
   }

   public httpServerIncomingNode gethttpServerIncoming(UUID uuid) {
   	return new httpServerIncomingNode(model, uuid);
   } 

    public httpServerListenHandlerNode newhttpServerListenHandler() {
   	return new httpServerListenHandlerNode(model, NeoModel.uuidOf(model.newNode("httpServerListenHandler", UUID.randomUUID())));
   }

   public httpServerListenHandlerNode gethttpServerListenHandler(UUID uuid) {
   	return new httpServerListenHandlerNode(model, uuid);
   } 

    public httpServerPartialFileNode newhttpServerPartialFile() {
   	return new httpServerPartialFileNode(model, NeoModel.uuidOf(model.newNode("httpServerPartialFile", UUID.randomUUID())));
   }

   public httpServerPartialFileNode gethttpServerPartialFile(UUID uuid) {
   	return new httpServerPartialFileNode(model, uuid);
   } 

    public inMemoryBodyAggrNode newinMemoryBodyAggr() {
   	return new inMemoryBodyAggrNode(model, NeoModel.uuidOf(model.newNode("inMemoryBodyAggr", UUID.randomUUID())));
   }

   public inMemoryBodyAggrNode getinMemoryBodyAggr(UUID uuid) {
   	return new inMemoryBodyAggrNode(model, uuid);
   } 

    public inMemoryBodyAggrShortNode newinMemoryBodyAggrShort() {
   	return new inMemoryBodyAggrShortNode(model, NeoModel.uuidOf(model.newNode("inMemoryBodyAggrShort", UUID.randomUUID())));
   }

   public inMemoryBodyAggrShortNode getinMemoryBodyAggrShort(UUID uuid) {
   	return new inMemoryBodyAggrShortNode(model, uuid);
   } 

    public isolateVerticleDeploymentNode newisolateVerticleDeployment() {
   	return new isolateVerticleDeploymentNode(model, NeoModel.uuidOf(model.newNode("isolateVerticleDeployment", UUID.randomUUID())));
   }

   public isolateVerticleDeploymentNode getisolateVerticleDeployment(UUID uuid) {
   	return new isolateVerticleDeploymentNode(model, uuid);
   } 

    public jsonNode newjson() {
   	return new jsonNode(model, NeoModel.uuidOf(model.newNode("json", UUID.randomUUID())));
   }

   public jsonNode getjson(UUID uuid) {
   	return new jsonNode(model, uuid);
   } 

    public jsonFromStringNode newjsonFromString() {
   	return new jsonFromStringNode(model, NeoModel.uuidOf(model.newNode("jsonFromString", UUID.randomUUID())));
   }

   public jsonFromStringNode getjsonFromString(UUID uuid) {
   	return new jsonFromStringNode(model, uuid);
   } 

    public jsonGetIntegerNode newjsonGetInteger() {
   	return new jsonGetIntegerNode(model, NeoModel.uuidOf(model.newNode("jsonGetInteger", UUID.randomUUID())));
   }

   public jsonGetIntegerNode getjsonGetInteger(UUID uuid) {
   	return new jsonGetIntegerNode(model, uuid);
   } 

    public jsonGetStringNode newjsonGetString() {
   	return new jsonGetStringNode(model, NeoModel.uuidOf(model.newNode("jsonGetString", UUID.randomUUID())));
   }

   public jsonGetStringNode getjsonGetString(UUID uuid) {
   	return new jsonGetStringNode(model, uuid);
   } 

    public leaveMulticastGroupNode newleaveMulticastGroup() {
   	return new leaveMulticastGroupNode(model, NeoModel.uuidOf(model.newNode("leaveMulticastGroup", UUID.randomUUID())));
   }

   public leaveMulticastGroupNode getleaveMulticastGroup(UUID uuid) {
   	return new leaveMulticastGroupNode(model, uuid);
   } 

    public localSharedMapNode newlocalSharedMap() {
   	return new localSharedMapNode(model, NeoModel.uuidOf(model.newNode("localSharedMap", UUID.randomUUID())));
   }

   public localSharedMapNode getlocalSharedMap(UUID uuid) {
   	return new localSharedMapNode(model, uuid);
   } 

    public messageCodecNode newmessageCodec() {
   	return new messageCodecNode(model, NeoModel.uuidOf(model.newNode("messageCodec", UUID.randomUUID())));
   }

   public messageCodecNode getmessageCodec(UUID uuid) {
   	return new messageCodecNode(model, uuid);
   } 

    public messageHandlerNode newmessageHandler() {
   	return new messageHandlerNode(model, NeoModel.uuidOf(model.newNode("messageHandler", UUID.randomUUID())));
   }

   public messageHandlerNode getmessageHandler(UUID uuid) {
   	return new messageHandlerNode(model, uuid);
   } 

    public messageHeadersNode newmessageHeaders() {
   	return new messageHeadersNode(model, NeoModel.uuidOf(model.newNode("messageHeaders", UUID.randomUUID())));
   }

   public messageHeadersNode getmessageHeaders(UUID uuid) {
   	return new messageHeadersNode(model, uuid);
   } 

    public multipleServersCommandLineNode newmultipleServersCommandLine() {
   	return new multipleServersCommandLineNode(model, NeoModel.uuidOf(model.newNode("multipleServersCommandLine", UUID.randomUUID())));
   }

   public multipleServersCommandLineNode getmultipleServersCommandLine(UUID uuid) {
   	return new multipleServersCommandLineNode(model, uuid);
   } 

    public multipleServersProgrammaticallyNode newmultipleServersProgrammatically() {
   	return new multipleServersProgrammaticallyNode(model, NeoModel.uuidOf(model.newNode("multipleServersProgrammatically", UUID.randomUUID())));
   }

   public multipleServersProgrammaticallyNode getmultipleServersProgrammatically(UUID uuid) {
   	return new multipleServersProgrammaticallyNode(model, uuid);
   } 

    public multpileServersVerticleNode newmultpileServersVerticle() {
   	return new multpileServersVerticleNode(model, NeoModel.uuidOf(model.newNode("multpileServersVerticle", UUID.randomUUID())));
   }

   public multpileServersVerticleNode getmultpileServersVerticle(UUID uuid) {
   	return new multpileServersVerticleNode(model, uuid);
   } 

    public mvnNode newmvn() {
   	return new mvnNode(model, NeoModel.uuidOf(model.newNode("mvn", UUID.randomUUID())));
   }

   public mvnNode getmvn(UUID uuid) {
   	return new mvnNode(model, uuid);
   } 

    public mvnAuthShiroNode newmvnAuthShiro() {
   	return new mvnAuthShiroNode(model, NeoModel.uuidOf(model.newNode("mvnAuthShiro", UUID.randomUUID())));
   }

   public mvnAuthShiroNode getmvnAuthShiro(UUID uuid) {
   	return new mvnAuthShiroNode(model, uuid);
   } 

    public mvnDropwizardMetricsNode newmvnDropwizardMetrics() {
   	return new mvnDropwizardMetricsNode(model, NeoModel.uuidOf(model.newNode("mvnDropwizardMetrics", UUID.randomUUID())));
   }

   public mvnDropwizardMetricsNode getmvnDropwizardMetrics(UUID uuid) {
   	return new mvnDropwizardMetricsNode(model, uuid);
   } 

    public mvnJunitNode newmvnJunit() {
   	return new mvnJunitNode(model, NeoModel.uuidOf(model.newNode("mvnJunit", UUID.randomUUID())));
   }

   public mvnJunitNode getmvnJunit(UUID uuid) {
   	return new mvnJunitNode(model, uuid);
   } 

    public newAsynchVerticleNode newnewAsynchVerticle() {
   	return new newAsynchVerticleNode(model, NeoModel.uuidOf(model.newNode("newAsynchVerticle", UUID.randomUUID())));
   }

   public newAsynchVerticleNode getnewAsynchVerticle(UUID uuid) {
   	return new newAsynchVerticleNode(model, uuid);
   } 

    public newBufferNode newnewBuffer() {
   	return new newBufferNode(model, NeoModel.uuidOf(model.newNode("newBuffer", UUID.randomUUID())));
   }

   public newBufferNode getnewBuffer(UUID uuid) {
   	return new newBufferNode(model, uuid);
   } 

    public newBufferByteNode newnewBufferByte() {
   	return new newBufferByteNode(model, NeoModel.uuidOf(model.newNode("newBufferByte", UUID.randomUUID())));
   }

   public newBufferByteNode getnewBufferByte(UUID uuid) {
   	return new newBufferByteNode(model, uuid);
   } 

    public newBufferSizeNode newnewBufferSize() {
   	return new newBufferSizeNode(model, NeoModel.uuidOf(model.newNode("newBufferSize", UUID.randomUUID())));
   }

   public newBufferSizeNode getnewBufferSize(UUID uuid) {
   	return new newBufferSizeNode(model, uuid);
   } 

    public newBufferStringNode newnewBufferString() {
   	return new newBufferStringNode(model, NeoModel.uuidOf(model.newNode("newBufferString", UUID.randomUUID())));
   }

   public newBufferStringNode getnewBufferString(UUID uuid) {
   	return new newBufferStringNode(model, uuid);
   } 

    public newBufferStringEncodedNode newnewBufferStringEncoded() {
   	return new newBufferStringEncodedNode(model, NeoModel.uuidOf(model.newNode("newBufferStringEncoded", UUID.randomUUID())));
   }

   public newBufferStringEncodedNode getnewBufferStringEncoded(UUID uuid) {
   	return new newBufferStringEncodedNode(model, uuid);
   } 

    public newDatagramSocketNode newnewDatagramSocket() {
   	return new newDatagramSocketNode(model, NeoModel.uuidOf(model.newNode("newDatagramSocket", UUID.randomUUID())));
   }

   public newDatagramSocketNode getnewDatagramSocket(UUID uuid) {
   	return new newDatagramSocketNode(model, uuid);
   } 

    public newEventBusNode newnewEventBus() {
   	return new newEventBusNode(model, NeoModel.uuidOf(model.newNode("newEventBus", UUID.randomUUID())));
   }

   public newEventBusNode getnewEventBus(UUID uuid) {
   	return new newEventBusNode(model, uuid);
   } 

    public newJsonArrayNode newnewJsonArray() {
   	return new newJsonArrayNode(model, NeoModel.uuidOf(model.newNode("newJsonArray", UUID.randomUUID())));
   }

   public newJsonArrayNode getnewJsonArray(UUID uuid) {
   	return new newJsonArrayNode(model, uuid);
   } 

    public newTCPClientNode newnewTCPClient() {
   	return new newTCPClientNode(model, NeoModel.uuidOf(model.newNode("newTCPClient", UUID.randomUUID())));
   }

   public newTCPClientNode getnewTCPClient(UUID uuid) {
   	return new newTCPClientNode(model, uuid);
   } 

    public newTcpServerNode newnewTcpServer() {
   	return new newTcpServerNode(model, NeoModel.uuidOf(model.newNode("newTcpServer", UUID.randomUUID())));
   }

   public newTcpServerNode getnewTcpServer(UUID uuid) {
   	return new newTcpServerNode(model, uuid);
   } 

    public oneShotTimerNode newoneShotTimer() {
   	return new oneShotTimerNode(model, NeoModel.uuidOf(model.newNode("oneShotTimer", UUID.randomUUID())));
   }

   public oneShotTimerNode getoneShotTimer(UUID uuid) {
   	return new oneShotTimerNode(model, uuid);
   } 

    public periodicTimerNode newperiodicTimer() {
   	return new periodicTimerNode(model, NeoModel.uuidOf(model.newNode("periodicTimer", UUID.randomUUID())));
   }

   public periodicTimerNode getperiodicTimer(UUID uuid) {
   	return new periodicTimerNode(model, uuid);
   } 

    public postWriteNode newpostWrite() {
   	return new postWriteNode(model, NeoModel.uuidOf(model.newNode("postWrite", UUID.randomUUID())));
   }

   public postWriteNode getpostWrite(UUID uuid) {
   	return new postWriteNode(model, uuid);
   } 

    public publishMessageNode newpublishMessage() {
   	return new publishMessageNode(model, NeoModel.uuidOf(model.newNode("publishMessage", UUID.randomUUID())));
   }

   public publishMessageNode getpublishMessage(UUID uuid) {
   	return new publishMessageNode(model, uuid);
   } 

    public pumpResponseNode newpumpResponse() {
   	return new pumpResponseNode(model, NeoModel.uuidOf(model.newNode("pumpResponse", UUID.randomUUID())));
   }

   public pumpResponseNode getpumpResponse(UUID uuid) {
   	return new pumpResponseNode(model, uuid);
   } 

    public pumpStreamsNode newpumpStreams() {
   	return new pumpStreamsNode(model, NeoModel.uuidOf(model.newNode("pumpStreams", UUID.randomUUID())));
   }

   public pumpStreamsNode getpumpStreams(UUID uuid) {
   	return new pumpStreamsNode(model, uuid);
   } 

    public putDataInMapNode newputDataInMap() {
   	return new putDataInMapNode(model, NeoModel.uuidOf(model.newNode("putDataInMap", UUID.randomUUID())));
   }

   public putDataInMapNode getputDataInMap(UUID uuid) {
   	return new putDataInMapNode(model, uuid);
   } 

    public putJsonNode newputJson() {
   	return new putJsonNode(model, NeoModel.uuidOf(model.newNode("putJson", UUID.randomUUID())));
   }

   public putJsonNode getputJson(UUID uuid) {
   	return new putJsonNode(model, uuid);
   } 

    public randomAccessBufferWriteNode newrandomAccessBufferWrite() {
   	return new randomAccessBufferWriteNode(model, NeoModel.uuidOf(model.newNode("randomAccessBufferWrite", UUID.randomUUID())));
   }

   public randomAccessBufferWriteNode getrandomAccessBufferWrite(UUID uuid) {
   	return new randomAccessBufferWriteNode(model, uuid);
   } 

    public randomAccessReadNode newrandomAccessRead() {
   	return new randomAccessReadNode(model, NeoModel.uuidOf(model.newNode("randomAccessRead", UUID.randomUUID())));
   }

   public randomAccessReadNode getrandomAccessRead(UUID uuid) {
   	return new randomAccessReadNode(model, uuid);
   } 

    public randomAccessWriteNode newrandomAccessWrite() {
   	return new randomAccessWriteNode(model, NeoModel.uuidOf(model.newNode("randomAccessWrite", UUID.randomUUID())));
   }

   public randomAccessWriteNode getrandomAccessWrite(UUID uuid) {
   	return new randomAccessWriteNode(model, uuid);
   } 

    public readBufferNode newreadBuffer() {
   	return new readBufferNode(model, NeoModel.uuidOf(model.newNode("readBuffer", UUID.randomUUID())));
   }

   public readBufferNode getreadBuffer(UUID uuid) {
   	return new readBufferNode(model, uuid);
   } 

    public readFileAsynchNode newreadFileAsynch() {
   	return new readFileAsynchNode(model, NeoModel.uuidOf(model.newNode("readFileAsynch", UUID.randomUUID())));
   }

   public readFileAsynchNode getreadFileAsynch(UUID uuid) {
   	return new readFileAsynchNode(model, uuid);
   } 

    public readSocketDataNode newreadSocketData() {
   	return new readSocketDataNode(model, NeoModel.uuidOf(model.newNode("readSocketData", UUID.randomUUID())));
   }

   public readSocketDataNode getreadSocketData(UUID uuid) {
   	return new readSocketDataNode(model, uuid);
   } 

    public readUnsignedNumberNode newreadUnsignedNumber() {
   	return new readUnsignedNumberNode(model, NeoModel.uuidOf(model.newNode("readUnsignedNumber", UUID.randomUUID())));
   }

   public readUnsignedNumberNode getreadUnsignedNumber(UUID uuid) {
   	return new readUnsignedNumberNode(model, uuid);
   } 

    public receiveDatagramPacketNode newreceiveDatagramPacket() {
   	return new receiveDatagramPacketNode(model, NeoModel.uuidOf(model.newNode("receiveDatagramPacket", UUID.randomUUID())));
   }

   public receiveDatagramPacketNode getreceiveDatagramPacket(UUID uuid) {
   	return new receiveDatagramPacketNode(model, uuid);
   } 

    public receiveMulticastNode newreceiveMulticast() {
   	return new receiveMulticastNode(model, NeoModel.uuidOf(model.newNode("receiveMulticast", UUID.randomUUID())));
   }

   public receiveMulticastNode getreceiveMulticast(UUID uuid) {
   	return new receiveMulticastNode(model, uuid);
   } 

    public recordParserNode newrecordParser() {
   	return new recordParserNode(model, NeoModel.uuidOf(model.newNode("recordParser", UUID.randomUUID())));
   }

   public recordParserNode getrecordParser(UUID uuid) {
   	return new recordParserNode(model, uuid);
   } 

    public recordParserFixedNode newrecordParserFixed() {
   	return new recordParserFixedNode(model, NeoModel.uuidOf(model.newNode("recordParserFixed", UUID.randomUUID())));
   }

   public recordParserFixedNode getrecordParserFixed(UUID uuid) {
   	return new recordParserFixedNode(model, uuid);
   } 

    public registerHandlerNode newregisterHandler() {
   	return new registerHandlerNode(model, NeoModel.uuidOf(model.newNode("registerHandler", UUID.randomUUID())));
   }

   public registerHandlerNode getregisterHandler(UUID uuid) {
   	return new registerHandlerNode(model, uuid);
   } 

    public replyMessageNode newreplyMessage() {
   	return new replyMessageNode(model, NeoModel.uuidOf(model.newNode("replyMessage", UUID.randomUUID())));
   }

   public replyMessageNode getreplyMessage(UUID uuid) {
   	return new replyMessageNode(model, uuid);
   } 

    public replyReceivedMessageNode newreplyReceivedMessage() {
   	return new replyReceivedMessageNode(model, NeoModel.uuidOf(model.newNode("replyReceivedMessage", UUID.randomUUID())));
   }

   public replyReceivedMessageNode getreplyReceivedMessage(UUID uuid) {
   	return new replyReceivedMessageNode(model, uuid);
   } 

    public requestHandlerNode newrequestHandler() {
   	return new requestHandlerNode(model, NeoModel.uuidOf(model.newNode("requestHandler", UUID.randomUUID())));
   }

   public requestHandlerNode getrequestHandler(UUID uuid) {
   	return new requestHandlerNode(model, uuid);
   } 

    public retriveContextNode newretriveContext() {
   	return new retriveContextNode(model, NeoModel.uuidOf(model.newNode("retriveContext", UUID.randomUUID())));
   }

   public retriveContextNode getretriveContext(UUID uuid) {
   	return new retriveContextNode(model, uuid);
   } 

    public revokateAuthNode newrevokateAuth() {
   	return new revokateAuthNode(model, NeoModel.uuidOf(model.newNode("revokateAuth", UUID.randomUUID())));
   }

   public revokateAuthNode getrevokateAuth(UUID uuid) {
   	return new revokateAuthNode(model, uuid);
   } 

    public revokateAuthBufferNode newrevokateAuthBuffer() {
   	return new revokateAuthBufferNode(model, NeoModel.uuidOf(model.newNode("revokateAuthBuffer", UUID.randomUUID())));
   }

   public revokateAuthBufferNode getrevokateAuthBuffer(UUID uuid) {
   	return new revokateAuthBufferNode(model, uuid);
   } 

    public runInContextNode newrunInContext() {
   	return new runInContextNode(model, NeoModel.uuidOf(model.newNode("runInContext", UUID.randomUUID())));
   }

   public runInContextNode getrunInContext(UUID uuid) {
   	return new runInContextNode(model, uuid);
   } 

    public sendFileNode newsendFile() {
   	return new sendFileNode(model, NeoModel.uuidOf(model.newNode("sendFile", UUID.randomUUID())));
   }

   public sendFileNode getsendFile(UUID uuid) {
   	return new sendFileNode(model, uuid);
   } 

    public sendMessageNode newsendMessage() {
   	return new sendMessageNode(model, NeoModel.uuidOf(model.newNode("sendMessage", UUID.randomUUID())));
   }

   public sendMessageNode getsendMessage(UUID uuid) {
   	return new sendMessageNode(model, uuid);
   } 

    public sendMulticastNode newsendMulticast() {
   	return new sendMulticastNode(model, NeoModel.uuidOf(model.newNode("sendMulticast", UUID.randomUUID())));
   }

   public sendMulticastNode getsendMulticast(UUID uuid) {
   	return new sendMulticastNode(model, uuid);
   } 

    public serverConnectionHandlerNode newserverConnectionHandler() {
   	return new serverConnectionHandlerNode(model, NeoModel.uuidOf(model.newNode("serverConnectionHandler", UUID.randomUUID())));
   }

   public serverConnectionHandlerNode getserverConnectionHandler(UUID uuid) {
   	return new serverConnectionHandlerNode(model, uuid);
   } 

    public serverListenHandlerNode newserverListenHandler() {
   	return new serverListenHandlerNode(model, NeoModel.uuidOf(model.newNode("serverListenHandler", UUID.randomUUID())));
   }

   public serverListenHandlerNode getserverListenHandler(UUID uuid) {
   	return new serverListenHandlerNode(model, uuid);
   } 

    public serverSSLBufferConfigurationNode newserverSSLBufferConfiguration() {
   	return new serverSSLBufferConfigurationNode(model, NeoModel.uuidOf(model.newNode("serverSSLBufferConfiguration", UUID.randomUUID())));
   }

   public serverSSLBufferConfigurationNode getserverSSLBufferConfiguration(UUID uuid) {
   	return new serverSSLBufferConfigurationNode(model, uuid);
   } 

    public serverSSLKeystoreNode newserverSSLKeystore() {
   	return new serverSSLKeystoreNode(model, NeoModel.uuidOf(model.newNode("serverSSLKeystore", UUID.randomUUID())));
   }

   public serverSSLKeystoreNode getserverSSLKeystore(UUID uuid) {
   	return new serverSSLKeystoreNode(model, uuid);
   } 

    public serverSSLKeystoreBuffNode newserverSSLKeystoreBuff() {
   	return new serverSSLKeystoreBuffNode(model, NeoModel.uuidOf(model.newNode("serverSSLKeystoreBuff", UUID.randomUUID())));
   }

   public serverSSLKeystoreBuffNode getserverSSLKeystoreBuff(UUID uuid) {
   	return new serverSSLKeystoreBuffNode(model, uuid);
   } 

    public serverSSLPEMNode newserverSSLPEM() {
   	return new serverSSLPEMNode(model, NeoModel.uuidOf(model.newNode("serverSSLPEM", UUID.randomUUID())));
   }

   public serverSSLPEMNode getserverSSLPEM(UUID uuid) {
   	return new serverSSLPEMNode(model, uuid);
   } 

    public serverSSLPEMAuthorityNode newserverSSLPEMAuthority() {
   	return new serverSSLPEMAuthorityNode(model, NeoModel.uuidOf(model.newNode("serverSSLPEMAuthority", UUID.randomUUID())));
   }

   public serverSSLPEMAuthorityNode getserverSSLPEMAuthority(UUID uuid) {
   	return new serverSSLPEMAuthorityNode(model, uuid);
   } 

    public serverSSLPEMAuthorityBufferNode newserverSSLPEMAuthorityBuffer() {
   	return new serverSSLPEMAuthorityBufferNode(model, NeoModel.uuidOf(model.newNode("serverSSLPEMAuthorityBuffer", UUID.randomUUID())));
   }

   public serverSSLPEMAuthorityBufferNode getserverSSLPEMAuthorityBuffer(UUID uuid) {
   	return new serverSSLPEMAuthorityBufferNode(model, uuid);
   } 

    public serverSSLPEMBufferNode newserverSSLPEMBuffer() {
   	return new serverSSLPEMBufferNode(model, NeoModel.uuidOf(model.newNode("serverSSLPEMBuffer", UUID.randomUUID())));
   }

   public serverSSLPEMBufferNode getserverSSLPEMBuffer(UUID uuid) {
   	return new serverSSLPEMBufferNode(model, uuid);
   } 

    public serverSSLPKCS_12Node newserverSSLPKCS_12() {
   	return new serverSSLPKCS_12Node(model, NeoModel.uuidOf(model.newNode("serverSSLPKCS_12", UUID.randomUUID())));
   }

   public serverSSLPKCS_12Node getserverSSLPKCS_12(UUID uuid) {
   	return new serverSSLPKCS_12Node(model, uuid);
   } 

    public serverSSLPKCS_12AuthorityNode newserverSSLPKCS_12Authority() {
   	return new serverSSLPKCS_12AuthorityNode(model, NeoModel.uuidOf(model.newNode("serverSSLPKCS_12Authority", UUID.randomUUID())));
   }

   public serverSSLPKCS_12AuthorityNode getserverSSLPKCS_12Authority(UUID uuid) {
   	return new serverSSLPKCS_12AuthorityNode(model, uuid);
   } 

    public serverSSLPKCS_12AuthorityBufferNode newserverSSLPKCS_12AuthorityBuffer() {
   	return new serverSSLPKCS_12AuthorityBufferNode(model, NeoModel.uuidOf(model.newNode("serverSSLPKCS_12AuthorityBuffer", UUID.randomUUID())));
   }

   public serverSSLPKCS_12AuthorityBufferNode getserverSSLPKCS_12AuthorityBuffer(UUID uuid) {
   	return new serverSSLPKCS_12AuthorityBufferNode(model, uuid);
   } 

    public serverSSLTrustAuthorityNode newserverSSLTrustAuthority() {
   	return new serverSSLTrustAuthorityNode(model, NeoModel.uuidOf(model.newNode("serverSSLTrustAuthority", UUID.randomUUID())));
   }

   public serverSSLTrustAuthorityNode getserverSSLTrustAuthority(UUID uuid) {
   	return new serverSSLTrustAuthorityNode(model, uuid);
   } 

    public serverSSLTrustAuthorityBufferNode newserverSSLTrustAuthorityBuffer() {
   	return new serverSSLTrustAuthorityBufferNode(model, NeoModel.uuidOf(model.newNode("serverSSLTrustAuthorityBuffer", UUID.randomUUID())));
   }

   public serverSSLTrustAuthorityBufferNode getserverSSLTrustAuthorityBuffer(UUID uuid) {
   	return new serverSSLTrustAuthorityBufferNode(model, uuid);
   } 

    public simpleWriteRequestNode newsimpleWriteRequest() {
   	return new simpleWriteRequestNode(model, NeoModel.uuidOf(model.newNode("simpleWriteRequest", UUID.randomUUID())));
   }

   public simpleWriteRequestNode getsimpleWriteRequest(UUID uuid) {
   	return new simpleWriteRequestNode(model, uuid);
   } 

    public socketClosedHandlerNode newsocketClosedHandler() {
   	return new socketClosedHandlerNode(model, NeoModel.uuidOf(model.newNode("socketClosedHandler", UUID.randomUUID())));
   }

   public socketClosedHandlerNode getsocketClosedHandler(UUID uuid) {
   	return new socketClosedHandlerNode(model, uuid);
   } 

    public undeployVerticlesNode newundeployVerticles() {
   	return new undeployVerticlesNode(model, NeoModel.uuidOf(model.newNode("undeployVerticles", UUID.randomUUID())));
   }

   public undeployVerticlesNode getundeployVerticles(UUID uuid) {
   	return new undeployVerticlesNode(model, uuid);
   } 

    public verticleNode newverticle() {
   	return new verticleNode(model, NeoModel.uuidOf(model.newNode("verticle", UUID.randomUUID())));
   }

   public verticleNode getverticle(UUID uuid) {
   	return new verticleNode(model, uuid);
   } 

    public verticleConfigurationNode newverticleConfiguration() {
   	return new verticleConfigurationNode(model, NeoModel.uuidOf(model.newNode("verticleConfiguration", UUID.randomUUID())));
   }

   public verticleConfigurationNode getverticleConfiguration(UUID uuid) {
   	return new verticleConfigurationNode(model, uuid);
   } 

    public verticleInstancesNode newverticleInstances() {
   	return new verticleInstancesNode(model, NeoModel.uuidOf(model.newNode("verticleInstances", UUID.randomUUID())));
   }

   public verticleInstancesNode getverticleInstances(UUID uuid) {
   	return new verticleInstancesNode(model, uuid);
   } 

    public vertxNode newvertx() {
   	return new vertxNode(model, NeoModel.uuidOf(model.newNode("vertx", UUID.randomUUID())));
   }

   public vertxNode getvertx(UUID uuid) {
   	return new vertxNode(model, uuid);
   } 

    public vertxOptionsNode newvertxOptions() {
   	return new vertxOptionsNode(model, NeoModel.uuidOf(model.newNode("vertxOptions", UUID.randomUUID())));
   }

   public vertxOptionsNode getvertxOptions(UUID uuid) {
   	return new vertxOptionsNode(model, uuid);
   } 

    public websocketFrameWriteNode newwebsocketFrameWrite() {
   	return new websocketFrameWriteNode(model, NeoModel.uuidOf(model.newNode("websocketFrameWrite", UUID.randomUUID())));
   }

   public websocketFrameWriteNode getwebsocketFrameWrite(UUID uuid) {
   	return new websocketFrameWriteNode(model, uuid);
   } 

    public websocketHandlerNode newwebsocketHandler() {
   	return new websocketHandlerNode(model, NeoModel.uuidOf(model.newNode("websocketHandler", UUID.randomUUID())));
   }

   public websocketHandlerNode getwebsocketHandler(UUID uuid) {
   	return new websocketHandlerNode(model, uuid);
   } 

    public websocketReadFrameNode newwebsocketReadFrame() {
   	return new websocketReadFrameNode(model, NeoModel.uuidOf(model.newNode("websocketReadFrame", UUID.randomUUID())));
   }

   public websocketReadFrameNode getwebsocketReadFrame(UUID uuid) {
   	return new websocketReadFrameNode(model, uuid);
   } 

    public websocketSingleFrameWriteNode newwebsocketSingleFrameWrite() {
   	return new websocketSingleFrameWriteNode(model, NeoModel.uuidOf(model.newNode("websocketSingleFrameWrite", UUID.randomUUID())));
   }

   public websocketSingleFrameWriteNode getwebsocketSingleFrameWrite(UUID uuid) {
   	return new websocketSingleFrameWriteNode(model, uuid);
   } 

    public websocketUpgradeNode newwebsocketUpgrade() {
   	return new websocketUpgradeNode(model, NeoModel.uuidOf(model.newNode("websocketUpgrade", UUID.randomUUID())));
   }

   public websocketUpgradeNode getwebsocketUpgrade(UUID uuid) {
   	return new websocketUpgradeNode(model, uuid);
   } 

    public websocketWriteNode newwebsocketWrite() {
   	return new websocketWriteNode(model, NeoModel.uuidOf(model.newNode("websocketWrite", UUID.randomUUID())));
   }

   public websocketWriteNode getwebsocketWrite(UUID uuid) {
   	return new websocketWriteNode(model, uuid);
   } 

    public workerVerticleNode newworkerVerticle() {
   	return new workerVerticleNode(model, NeoModel.uuidOf(model.newNode("workerVerticle", UUID.randomUUID())));
   }

   public workerVerticleNode getworkerVerticle(UUID uuid) {
   	return new workerVerticleNode(model, uuid);
   } 

    public writeFileAsynchNode newwriteFileAsynch() {
   	return new writeFileAsynchNode(model, NeoModel.uuidOf(model.newNode("writeFileAsynch", UUID.randomUUID())));
   }

   public writeFileAsynchNode getwriteFileAsynch(UUID uuid) {
   	return new writeFileAsynchNode(model, uuid);
   } 

    public writeSocketDataNode newwriteSocketData() {
   	return new writeSocketDataNode(model, NeoModel.uuidOf(model.newNode("writeSocketData", UUID.randomUUID())));
   }

   public writeSocketDataNode getwriteSocketData(UUID uuid) {
   	return new writeSocketDataNode(model, uuid);
   } 

    public static final class appendBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private appendBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.appendBufferST fill(VertxCoreGroup.appendBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newappendBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class asynchFileNode {

      private final NeoModel model;
   	private final UUID uuid;

      private asynchFileNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.asynchFileST fill(VertxCoreGroup.asynchFileST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newasynchFile()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class asynchVerticleStopNode {

      private final NeoModel model;
   	private final UUID uuid;

      private asynchVerticleStopNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.asynchVerticleStopST fill(VertxCoreGroup.asynchVerticleStopST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newasynchVerticleStop()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class blockMulticastNode {

      private final NeoModel model;
   	private final UUID uuid;

      private blockMulticastNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.blockMulticastST fill(VertxCoreGroup.blockMulticastST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newblockMulticast()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class blockingCodeNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   RESULT, RESULTHANDLER, STATEMENTS
   	}

      private blockingCodeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.blockingCodeST fill(VertxCoreGroup.blockingCodeST statement) {
   		fillResult(statement);
   		fillResultHandler(statement);
   		fillStatements(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newblockingCode()).toString();
   	}
       // result
      public blockingCodeNode setResult(String value) {
      	if (has(getNode(), "result")) getNode().removeProperty("result");
      	if (value!=null) getNode().setProperty("result", value);
         return this;
      }

      private blockingCodeNode fillResult(VertxCoreGroup.blockingCodeST statement) {
      	if (has(getNode(), "result")) statement.setResult(get(getNode(), "result"));
      	return this;
      } 

       // resultHandler
      public blockingCodeNode setResultHandler(String value) {
      	if (has(getNode(), "resultHandler")) getNode().removeProperty("resultHandler");
      	if (value!=null) getNode().setProperty("resultHandler", value);
         return this;
      }

      private blockingCodeNode fillResultHandler(VertxCoreGroup.blockingCodeST statement) {
      	if (has(getNode(), "resultHandler")) statement.setResultHandler(get(getNode(), "resultHandler"));
      	return this;
      } 

       // statements
      public blockingCodeNode addStatementsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("blockingCode_statements", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.STATEMENTS);
      	}
         return this;
      }

      private blockingCodeNode fillStatements(VertxCoreGroup.blockingCodeST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.STATEMENTS))
      		statement.addStatementsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class bodyHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private bodyHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.bodyHandlerST fill(VertxCoreGroup.bodyHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newbodyHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class bufCopyNode {

      private final NeoModel model;
   	private final UUID uuid;

      private bufCopyNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.bufCopyST fill(VertxCoreGroup.bufCopyST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newbufCopy()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class bufLengthNode {

      private final NeoModel model;
   	private final UUID uuid;

      private bufLengthNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.bufLengthST fill(VertxCoreGroup.bufLengthST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newbufLength()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class bufSliceNode {

      private final NeoModel model;
   	private final UUID uuid;

      private bufSliceNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.bufSliceST fill(VertxCoreGroup.bufSliceST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newbufSlice()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class bugfixNode {

      private final NeoModel model;
   	private final UUID uuid;

      private bugfixNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.bugfixST fill(VertxCoreGroup.bugfixST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newbugfix()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class cancelTimerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private cancelTimerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.cancelTimerST fill(VertxCoreGroup.cancelTimerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcancelTimer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class checkExistenceAndDeleteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private checkExistenceAndDeleteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.checkExistenceAndDeleteST fill(VertxCoreGroup.checkExistenceAndDeleteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcheckExistenceAndDelete()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class chunkFileUploadHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private chunkFileUploadHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.chunkFileUploadHandlerST fill(VertxCoreGroup.chunkFileUploadHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newchunkFileUploadHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientConnectNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientConnectNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientConnectST fill(VertxCoreGroup.clientConnectST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientConnect()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientRequestNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   CLIENT, CONTENT, HANDLEBODY, HANDLERESPONSE, HEADERS, HTTPMETHOD, URI
   	}

      private clientRequestNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientRequestST fill(VertxCoreGroup.clientRequestST statement) {
   		fillClient(statement);
   		fillContent(statement);
   		fillHandleBody(statement);
   		fillHandleResponse(statement);
   		fillHeaders(statement);
   		fillHttpMethod(statement);
   		fillUri(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientRequest()).toString();
   	}
       // client
      public clientRequestNode setClient(String value) {
      	if (has(getNode(), "client")) getNode().removeProperty("client");
      	if (value!=null) getNode().setProperty("client", value);
         return this;
      }

      private clientRequestNode fillClient(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "client")) statement.setClient(get(getNode(), "client"));
      	return this;
      } 

       // content
      public clientRequestNode setContent(String value) {
      	if (has(getNode(), "content")) getNode().removeProperty("content");
      	if (value!=null) getNode().setProperty("content", value);
         return this;
      }

      private clientRequestNode fillContent(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "content")) statement.setContent(get(getNode(), "content"));
      	return this;
      } 

       // handleBody
      public clientRequestNode setHandleBody(String value) {
      	if (has(getNode(), "handleBody")) getNode().removeProperty("handleBody");
      	if (value!=null) getNode().setProperty("handleBody", value);
         return this;
      }

      private clientRequestNode fillHandleBody(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "handleBody")) statement.setHandleBody(get(getNode(), "handleBody"));
      	return this;
      } 

       // handleResponse
      public clientRequestNode setHandleResponse(String value) {
      	if (has(getNode(), "handleResponse")) getNode().removeProperty("handleResponse");
      	if (value!=null) getNode().setProperty("handleResponse", value);
         return this;
      }

      private clientRequestNode fillHandleResponse(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "handleResponse")) statement.setHandleResponse(get(getNode(), "handleResponse"));
      	return this;
      } 

       // headers
      public clientRequestNode addHeadersValue(String name_, String value_) {
      	final Node newNode = model.newNode("clientRequest_headers", UUID.randomUUID());
      	getNode().createRelationshipTo(newNode, PARAMS.HEADERS);
      	if (name_ != null) newNode.setProperty("name", name_); 
      	if (value_ != null) newNode.setProperty("value", value_);    
      	return this;
      }

      private clientRequestNode fillHeaders(VertxCoreGroup.clientRequestST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.HEADERS)) {
      		final Node node = other(getNode(), relationship);
      		statement.addHeadersValue(node.hasProperty("name") ? node.getProperty("name") : null, node.hasProperty("value") ? node.getProperty("value") : null);
      	}
      	return this;
      } 

       // httpMethod
      public clientRequestNode setHttpMethod(String value) {
      	if (has(getNode(), "httpMethod")) getNode().removeProperty("httpMethod");
      	if (value!=null) getNode().setProperty("httpMethod", value);
         return this;
      }

      private clientRequestNode fillHttpMethod(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "httpMethod")) statement.setHttpMethod(get(getNode(), "httpMethod"));
      	return this;
      } 

       // uri
      public clientRequestNode setUri(String value) {
      	if (has(getNode(), "uri")) getNode().removeProperty("uri");
      	if (value!=null) getNode().setProperty("uri", value);
         return this;
      }

      private clientRequestNode fillUri(VertxCoreGroup.clientRequestST statement) {
      	if (has(getNode(), "uri")) statement.setUri(get(getNode(), "uri"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLST fill(VertxCoreGroup.clientSSLST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSL()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLKeystoreAuthNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLKeystoreAuthNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLKeystoreAuthST fill(VertxCoreGroup.clientSSLKeystoreAuthST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLKeystoreAuth()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLKeystoreAuthBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLKeystoreAuthBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLKeystoreAuthBufferST fill(VertxCoreGroup.clientSSLKeystoreAuthBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLKeystoreAuthBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPEMNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPEMNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPEMST fill(VertxCoreGroup.clientSSLPEMST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPEM()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPEMAuthNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPEMAuthNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPEMAuthST fill(VertxCoreGroup.clientSSLPEMAuthST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPEMAuth()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPEMAuthBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPEMAuthBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPEMAuthBufferST fill(VertxCoreGroup.clientSSLPEMAuthBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPEMAuthBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPEMBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPEMBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPEMBufferST fill(VertxCoreGroup.clientSSLPEMBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPEMBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPKCSAuthNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPKCSAuthNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPKCSAuthST fill(VertxCoreGroup.clientSSLPKCSAuthST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPKCSAuth()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPKCSAuthBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPKCSAuthBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPKCSAuthBufferST fill(VertxCoreGroup.clientSSLPKCSAuthBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPKCSAuthBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPKCS_12Node {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPKCS_12Node(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPKCS_12ST fill(VertxCoreGroup.clientSSLPKCS_12ST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPKCS_12()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLPKCS_12BufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLPKCS_12BufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLPKCS_12BufferST fill(VertxCoreGroup.clientSSLPKCS_12BufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLPKCS_12Buffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLTruststoreNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLTruststoreNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLTruststoreST fill(VertxCoreGroup.clientSSLTruststoreST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLTruststore()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientSSLTruststoreBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientSSLTruststoreBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientSSLTruststoreBufferST fill(VertxCoreGroup.clientSSLTruststoreBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientSSLTruststoreBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clientWebsocketNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clientWebsocketNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clientWebsocketST fill(VertxCoreGroup.clientWebsocketST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclientWebsocket()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class closeServerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private closeServerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.closeServerST fill(VertxCoreGroup.closeServerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcloseServer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterCommandLineNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterCommandLineNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterCommandLineST fill(VertxCoreGroup.clusterCommandLineST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterCommandLine()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterCounterNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterCounterNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterCounterST fill(VertxCoreGroup.clusterCounterST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterCounter()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterProgrammaticallyNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterProgrammaticallyNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterProgrammaticallyST fill(VertxCoreGroup.clusterProgrammaticallyST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterProgrammatically()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterSharedMapNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterSharedMapNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterSharedMapST fill(VertxCoreGroup.clusterSharedMapST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterSharedMap()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterWideLockNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterWideLockNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterWideLockST fill(VertxCoreGroup.clusterWideLockST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterWideLock()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class clusterWideLockTimeoutNode {

      private final NeoModel model;
   	private final UUID uuid;

      private clusterWideLockTimeoutNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.clusterWideLockTimeoutST fill(VertxCoreGroup.clusterWideLockTimeoutST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newclusterWideLockTimeout()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class cmdHighAvailabilityNode {

      private final NeoModel model;
   	private final UUID uuid;

      private cmdHighAvailabilityNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.cmdHighAvailabilityST fill(VertxCoreGroup.cmdHighAvailabilityST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcmdHighAvailability()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class cmdRunVerticlesNode {

      private final NeoModel model;
   	private final UUID uuid;

      private cmdRunVerticlesNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.cmdRunVerticlesST fill(VertxCoreGroup.cmdRunVerticlesST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcmdRunVerticles()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class configGetIntegerNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME
   	}

      private configGetIntegerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.configGetIntegerST fill(VertxCoreGroup.configGetIntegerST statement) {
   		fillName(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newconfigGetInteger()).toString();
   	}
       // name
      public configGetIntegerNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private configGetIntegerNode fillName(VertxCoreGroup.configGetIntegerST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class configGetStringNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME
   	}

      private configGetStringNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.configGetStringST fill(VertxCoreGroup.configGetStringST statement) {
   		fillName(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newconfigGetString()).toString();
   	}
       // name
      public configGetStringNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private configGetStringNode fillName(VertxCoreGroup.configGetStringST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class configureCipherSuiteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private configureCipherSuiteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.configureCipherSuiteST fill(VertxCoreGroup.configureCipherSuiteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newconfigureCipherSuite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class consumerCompletionHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private consumerCompletionHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.consumerCompletionHandlerST fill(VertxCoreGroup.consumerCompletionHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newconsumerCompletionHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class contextSharedDataNode {

      private final NeoModel model;
   	private final UUID uuid;

      private contextSharedDataNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.contextSharedDataST fill(VertxCoreGroup.contextSharedDataST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcontextSharedData()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class contextTypeNode {

      private final NeoModel model;
   	private final UUID uuid;

      private contextTypeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.contextTypeST fill(VertxCoreGroup.contextTypeST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcontextType()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class copyFileAsynchNode {

      private final NeoModel model;
   	private final UUID uuid;

      private copyFileAsynchNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.copyFileAsynchST fill(VertxCoreGroup.copyFileAsynchST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcopyFileAsynch()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class copyFileSynchNode {

      private final NeoModel model;
   	private final UUID uuid;

      private copyFileSynchNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.copyFileSynchST fill(VertxCoreGroup.copyFileSynchST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newcopyFileSynch()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class deployPolyVerticlesNode {

      private final NeoModel model;
   	private final UUID uuid;

      private deployPolyVerticlesNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.deployPolyVerticlesST fill(VertxCoreGroup.deployPolyVerticlesST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdeployPolyVerticles()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class deployVerticleProgrammaticallyNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   ONFAIL, ONSUCCESS, OPTIONS, REFERENCE, TYPE
   	}

      private deployVerticleProgrammaticallyNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.deployVerticleProgrammaticallyST fill(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
   		fillOnFail(statement);
   		fillOnSuccess(statement);
   		fillOptions(statement);
   		fillReference(statement);
   		fillType(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdeployVerticleProgrammatically()).toString();
   	}
       // onFail
      public deployVerticleProgrammaticallyNode setOnFail(String value) {
      	if (has(getNode(), "onFail")) getNode().removeProperty("onFail");
      	if (value!=null) getNode().setProperty("onFail", value);
         return this;
      }

      private deployVerticleProgrammaticallyNode fillOnFail(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
      	if (has(getNode(), "onFail")) statement.setOnFail(get(getNode(), "onFail"));
      	return this;
      } 

       // onSuccess
      public deployVerticleProgrammaticallyNode setOnSuccess(String value) {
      	if (has(getNode(), "onSuccess")) getNode().removeProperty("onSuccess");
      	if (value!=null) getNode().setProperty("onSuccess", value);
         return this;
      }

      private deployVerticleProgrammaticallyNode fillOnSuccess(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
      	if (has(getNode(), "onSuccess")) statement.setOnSuccess(get(getNode(), "onSuccess"));
      	return this;
      } 

       // options
      public deployVerticleProgrammaticallyNode setOptions(String value) {
      	if (has(getNode(), "options")) getNode().removeProperty("options");
      	if (value!=null) getNode().setProperty("options", value);
         return this;
      }

      private deployVerticleProgrammaticallyNode fillOptions(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
      	if (has(getNode(), "options")) statement.setOptions(get(getNode(), "options"));
      	return this;
      } 

       // reference
      public deployVerticleProgrammaticallyNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private deployVerticleProgrammaticallyNode fillReference(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // type
      public deployVerticleProgrammaticallyNode setType(String value) {
      	if (has(getNode(), "type")) getNode().removeProperty("type");
      	if (value!=null) getNode().setProperty("type", value);
         return this;
      }

      private deployVerticleProgrammaticallyNode fillType(VertxCoreGroup.deployVerticleProgrammaticallyST statement) {
      	if (has(getNode(), "type")) statement.setType(get(getNode(), "type"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class deployVerticleStartNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   CONFIG, NAME, ONSUCCESS
   	}

      private deployVerticleStartNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.deployVerticleStartST fill(VertxCoreGroup.deployVerticleStartST statement) {
   		fillConfig(statement);
   		fillName(statement);
   		fillOnSuccess(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdeployVerticleStart()).toString();
   	}
       // config
      public deployVerticleStartNode setConfig(String value) {
      	if (has(getNode(), "config")) getNode().removeProperty("config");
      	if (value!=null) getNode().setProperty("config", value);
         return this;
      }

      private deployVerticleStartNode fillConfig(VertxCoreGroup.deployVerticleStartST statement) {
      	if (has(getNode(), "config")) statement.setConfig(get(getNode(), "config"));
      	return this;
      } 

       // name
      public deployVerticleStartNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private deployVerticleStartNode fillName(VertxCoreGroup.deployVerticleStartST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // onSuccess
      public deployVerticleStartNode setOnSuccess(String value) {
      	if (has(getNode(), "onSuccess")) getNode().removeProperty("onSuccess");
      	if (value!=null) getNode().setProperty("onSuccess", value);
         return this;
      }

      private deployVerticleStartNode fillOnSuccess(VertxCoreGroup.deployVerticleStartST statement) {
      	if (has(getNode(), "onSuccess")) statement.setOnSuccess(get(getNode(), "onSuccess"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsClientNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsClientNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsClientST fill(VertxCoreGroup.dnsClientST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsClient()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsLookupNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsLookupNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsLookupST fill(VertxCoreGroup.dnsLookupST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsLookup()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsLookup4Node {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsLookup4Node(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsLookup4ST fill(VertxCoreGroup.dnsLookup4ST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsLookup4()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsLookup6Node {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsLookup6Node(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsLookup6ST fill(VertxCoreGroup.dnsLookup6ST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsLookup6()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveANode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveANode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveAST fill(VertxCoreGroup.dnsResolveAST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveA()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveAAAANode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveAAAANode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveAAAAST fill(VertxCoreGroup.dnsResolveAAAAST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveAAAA()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveCNAMENode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveCNAMENode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveCNAMEST fill(VertxCoreGroup.dnsResolveCNAMEST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveCNAME()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveMXNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveMXNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveMXST fill(VertxCoreGroup.dnsResolveMXST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveMX()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveNSNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveNSNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveNSST fill(VertxCoreGroup.dnsResolveNSST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveNS()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolvePTRNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolvePTRNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolvePTRST fill(VertxCoreGroup.dnsResolvePTRST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolvePTR()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveSRVNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveSRVNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveSRVST fill(VertxCoreGroup.dnsResolveSRVST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveSRV()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResolveTXTNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResolveTXTNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResolveTXTST fill(VertxCoreGroup.dnsResolveTXTST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResolveTXT()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsResponseCodeNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsResponseCodeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsResponseCodeST fill(VertxCoreGroup.dnsResponseCodeST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsResponseCode()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class dnsReverseLookupNode {

      private final NeoModel model;
   	private final UUID uuid;

      private dnsReverseLookupNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.dnsReverseLookupST fill(VertxCoreGroup.dnsReverseLookupST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newdnsReverseLookup()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class ebConsumeNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   ADDRESS, ONMESSAGE
   	}

      private ebConsumeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.ebConsumeST fill(VertxCoreGroup.ebConsumeST statement) {
   		fillAddress(statement);
   		fillOnMessage(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newebConsume()).toString();
   	}
       // address
      public ebConsumeNode setAddress(String value) {
      	if (has(getNode(), "address")) getNode().removeProperty("address");
      	if (value!=null) getNode().setProperty("address", value);
         return this;
      }

      private ebConsumeNode fillAddress(VertxCoreGroup.ebConsumeST statement) {
      	if (has(getNode(), "address")) statement.setAddress(get(getNode(), "address"));
      	return this;
      } 

       // onMessage
      public ebConsumeNode setOnMessage(String value) {
      	if (has(getNode(), "onMessage")) getNode().removeProperty("onMessage");
      	if (value!=null) getNode().setProperty("onMessage", value);
         return this;
      }

      private ebConsumeNode fillOnMessage(VertxCoreGroup.ebConsumeST statement) {
      	if (has(getNode(), "onMessage")) statement.setOnMessage(get(getNode(), "onMessage"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class ebPublishNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   ADDRESS, VALUE
   	}

      private ebPublishNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.ebPublishST fill(VertxCoreGroup.ebPublishST statement) {
   		fillAddress(statement);
   		fillValue(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newebPublish()).toString();
   	}
       // address
      public ebPublishNode setAddress(String value) {
      	if (has(getNode(), "address")) getNode().removeProperty("address");
      	if (value!=null) getNode().setProperty("address", value);
         return this;
      }

      private ebPublishNode fillAddress(VertxCoreGroup.ebPublishST statement) {
      	if (has(getNode(), "address")) statement.setAddress(get(getNode(), "address"));
      	return this;
      } 

       // value
      public ebPublishNode setValue(String value) {
      	if (has(getNode(), "value")) getNode().removeProperty("value");
      	if (value!=null) getNode().setProperty("value", value);
         return this;
      }

      private ebPublishNode fillValue(VertxCoreGroup.ebPublishST statement) {
      	if (has(getNode(), "value")) statement.setValue(get(getNode(), "value"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class encodeArrayNode {

      private final NeoModel model;
   	private final UUID uuid;

      private encodeArrayNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.encodeArrayST fill(VertxCoreGroup.encodeArrayST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newencodeArray()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class fileStreamNode {

      private final NeoModel model;
   	private final UUID uuid;

      private fileStreamNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.fileStreamST fill(VertxCoreGroup.fileStreamST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newfileStream()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class formFileStreamUploadNode {

      private final NeoModel model;
   	private final UUID uuid;

      private formFileStreamUploadNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.formFileStreamUploadST fill(VertxCoreGroup.formFileStreamUploadST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newformFileStreamUpload()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class formFileUploadHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private formFileUploadHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.formFileUploadHandlerST fill(VertxCoreGroup.formFileUploadHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newformFileUploadHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class formHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private formHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.formHandlerST fill(VertxCoreGroup.formHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newformHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class getDataFromMapNode {

      private final NeoModel model;
   	private final UUID uuid;

      private getDataFromMapNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.getDataFromMapST fill(VertxCoreGroup.getDataFromMapST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newgetDataFromMap()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class getJsonNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME, REFERENCE, TYPE
   	}

      private getJsonNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.getJsonST fill(VertxCoreGroup.getJsonST statement) {
   		fillName(statement);
   		fillReference(statement);
   		fillType(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newgetJson()).toString();
   	}
       // name
      public getJsonNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private getJsonNode fillName(VertxCoreGroup.getJsonST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // reference
      public getJsonNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private getJsonNode fillReference(VertxCoreGroup.getJsonST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // type
      public getJsonNode setType(String value) {
      	if (has(getNode(), "type")) getNode().removeProperty("type");
      	if (value!=null) getNode().setProperty("type", value);
         return this;
      }

      private getJsonNode fillType(VertxCoreGroup.getJsonST statement) {
      	if (has(getNode(), "type")) statement.setType(get(getNode(), "type"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class getJsonArrayNode {

      private final NeoModel model;
   	private final UUID uuid;

      private getJsonArrayNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.getJsonArrayST fill(VertxCoreGroup.getJsonArrayST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newgetJsonArray()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class getRequestHeadersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private getRequestHeadersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.getRequestHeadersST fill(VertxCoreGroup.getRequestHeadersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newgetRequestHeaders()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   CLIENTOPTIONS, REFERENCE
   	}

      private httpClientNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientST fill(VertxCoreGroup.httpClientST statement) {
   		fillClientOptions(statement);
   		fillReference(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClient()).toString();
   	}
       // clientOptions
      public httpClientNode setClientOptions(String value) {
      	if (has(getNode(), "clientOptions")) getNode().removeProperty("clientOptions");
      	if (value!=null) getNode().setProperty("clientOptions", value);
         return this;
      }

      private httpClientNode fillClientOptions(VertxCoreGroup.httpClientST statement) {
      	if (has(getNode(), "clientOptions")) statement.setClientOptions(get(getNode(), "clientOptions"));
      	return this;
      } 

       // reference
      public httpClientNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private httpClientNode fillReference(VertxCoreGroup.httpClientST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientChunkedRequestNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientChunkedRequestNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientChunkedRequestST fill(VertxCoreGroup.httpClientChunkedRequestST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientChunkedRequest()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientContinueHandlingNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientContinueHandlingNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientContinueHandlingST fill(VertxCoreGroup.httpClientContinueHandlingST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientContinueHandling()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientEndRequestNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientEndRequestNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientEndRequestST fill(VertxCoreGroup.httpClientEndRequestST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientEndRequest()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientEndRequestBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientEndRequestBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientEndRequestBufferST fill(VertxCoreGroup.httpClientEndRequestBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientEndRequestBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientHandleExceptionNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientHandleExceptionNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientHandleExceptionST fill(VertxCoreGroup.httpClientHandleExceptionST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientHandleException()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientHandleExceptionResponseNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientHandleExceptionResponseNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientHandleExceptionResponseST fill(VertxCoreGroup.httpClientHandleExceptionResponseST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientHandleExceptionResponse()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientOptionsNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   CONNECTTIMEOUT, DEFAULTHOST, DEFAULTPORT, IDLETIMEOUT, KEEPALIVE, KEYSTOREOPTIONS, MAXPOOLSIZE, MAXWEBSOCKETFRAMESIZE, PEMKEYCERTOPTIONS, PEMTRUSTOPTIONS, PFXKEYCERTOPTIONS, PFXTRUSTOPTIONS, PIPELINING, PROTOCOLVERSION, RECEIVEBUFFERSIZE, REFERENCE, REUSEADDRESS, SENDBUFFERSIZE, SOLINGER, SSL, TCPKEEPALIVE, TCPNODELAY, TRAFFICCLASS, TRUSTALL, TRUSTSTORE, TRYUSECOMPRESSION, USEPOOLEDBUFFERS, VERIFYHOST
   	}

      private httpClientOptionsNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientOptionsST fill(VertxCoreGroup.httpClientOptionsST statement) {
   		fillConnectTimeout(statement);
   		fillDefaultHost(statement);
   		fillDefaultPort(statement);
   		fillIdleTimeout(statement);
   		fillKeepAlive(statement);
   		fillKeyStoreOptions(statement);
   		fillMaxPoolSize(statement);
   		fillMaxWebsocketFrameSize(statement);
   		fillPemKeyCertOptions(statement);
   		fillPemTrustOptions(statement);
   		fillPfxKeycertOptions(statement);
   		fillPfxTrustOptions(statement);
   		fillPipelining(statement);
   		fillProtocolVersion(statement);
   		fillReceiveBufferSize(statement);
   		fillReference(statement);
   		fillReuseAddress(statement);
   		fillSendBufferSize(statement);
   		fillSoLinger(statement);
   		fillSsl(statement);
   		fillTcpKeepAlive(statement);
   		fillTcpNoDelay(statement);
   		fillTrafficClass(statement);
   		fillTrustAll(statement);
   		fillTrustStore(statement);
   		fillTryUseCompression(statement);
   		fillUsePooledBuffers(statement);
   		fillVerifyHost(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientOptions()).toString();
   	}
       // connectTimeout
      public httpClientOptionsNode setConnectTimeout(String value) {
      	if (has(getNode(), "connectTimeout")) getNode().removeProperty("connectTimeout");
      	if (value!=null) getNode().setProperty("connectTimeout", value);
         return this;
      }

      private httpClientOptionsNode fillConnectTimeout(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "connectTimeout")) statement.setConnectTimeout(get(getNode(), "connectTimeout"));
      	return this;
      } 

       // defaultHost
      public httpClientOptionsNode setDefaultHost(String value) {
      	if (has(getNode(), "defaultHost")) getNode().removeProperty("defaultHost");
      	if (value!=null) getNode().setProperty("defaultHost", value);
         return this;
      }

      private httpClientOptionsNode fillDefaultHost(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "defaultHost")) statement.setDefaultHost(get(getNode(), "defaultHost"));
      	return this;
      } 

       // defaultPort
      public httpClientOptionsNode setDefaultPort(String value) {
      	if (has(getNode(), "defaultPort")) getNode().removeProperty("defaultPort");
      	if (value!=null) getNode().setProperty("defaultPort", value);
         return this;
      }

      private httpClientOptionsNode fillDefaultPort(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "defaultPort")) statement.setDefaultPort(get(getNode(), "defaultPort"));
      	return this;
      } 

       // idleTimeout
      public httpClientOptionsNode setIdleTimeout(String value) {
      	if (has(getNode(), "idleTimeout")) getNode().removeProperty("idleTimeout");
      	if (value!=null) getNode().setProperty("idleTimeout", value);
         return this;
      }

      private httpClientOptionsNode fillIdleTimeout(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "idleTimeout")) statement.setIdleTimeout(get(getNode(), "idleTimeout"));
      	return this;
      } 

       // keepAlive
      public httpClientOptionsNode setKeepAlive(String value) {
      	if (has(getNode(), "keepAlive")) getNode().removeProperty("keepAlive");
      	if (value!=null) getNode().setProperty("keepAlive", value);
         return this;
      }

      private httpClientOptionsNode fillKeepAlive(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "keepAlive")) statement.setKeepAlive(get(getNode(), "keepAlive"));
      	return this;
      } 

       // keyStoreOptions
      public httpClientOptionsNode setKeyStoreOptions(String value) {
      	if (has(getNode(), "keyStoreOptions")) getNode().removeProperty("keyStoreOptions");
      	if (value!=null) getNode().setProperty("keyStoreOptions", value);
         return this;
      }

      private httpClientOptionsNode fillKeyStoreOptions(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "keyStoreOptions")) statement.setKeyStoreOptions(get(getNode(), "keyStoreOptions"));
      	return this;
      } 

       // maxPoolSize
      public httpClientOptionsNode setMaxPoolSize(String value) {
      	if (has(getNode(), "maxPoolSize")) getNode().removeProperty("maxPoolSize");
      	if (value!=null) getNode().setProperty("maxPoolSize", value);
         return this;
      }

      private httpClientOptionsNode fillMaxPoolSize(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "maxPoolSize")) statement.setMaxPoolSize(get(getNode(), "maxPoolSize"));
      	return this;
      } 

       // maxWebsocketFrameSize
      public httpClientOptionsNode setMaxWebsocketFrameSize(String value) {
      	if (has(getNode(), "maxWebsocketFrameSize")) getNode().removeProperty("maxWebsocketFrameSize");
      	if (value!=null) getNode().setProperty("maxWebsocketFrameSize", value);
         return this;
      }

      private httpClientOptionsNode fillMaxWebsocketFrameSize(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "maxWebsocketFrameSize")) statement.setMaxWebsocketFrameSize(get(getNode(), "maxWebsocketFrameSize"));
      	return this;
      } 

       // pemKeyCertOptions
      public httpClientOptionsNode setPemKeyCertOptions(String value) {
      	if (has(getNode(), "pemKeyCertOptions")) getNode().removeProperty("pemKeyCertOptions");
      	if (value!=null) getNode().setProperty("pemKeyCertOptions", value);
         return this;
      }

      private httpClientOptionsNode fillPemKeyCertOptions(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "pemKeyCertOptions")) statement.setPemKeyCertOptions(get(getNode(), "pemKeyCertOptions"));
      	return this;
      } 

       // pemTrustOptions
      public httpClientOptionsNode setPemTrustOptions(String value) {
      	if (has(getNode(), "pemTrustOptions")) getNode().removeProperty("pemTrustOptions");
      	if (value!=null) getNode().setProperty("pemTrustOptions", value);
         return this;
      }

      private httpClientOptionsNode fillPemTrustOptions(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "pemTrustOptions")) statement.setPemTrustOptions(get(getNode(), "pemTrustOptions"));
      	return this;
      } 

       // pfxKeycertOptions
      public httpClientOptionsNode setPfxKeycertOptions(String value) {
      	if (has(getNode(), "pfxKeycertOptions")) getNode().removeProperty("pfxKeycertOptions");
      	if (value!=null) getNode().setProperty("pfxKeycertOptions", value);
         return this;
      }

      private httpClientOptionsNode fillPfxKeycertOptions(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "pfxKeycertOptions")) statement.setPfxKeycertOptions(get(getNode(), "pfxKeycertOptions"));
      	return this;
      } 

       // pfxTrustOptions
      public httpClientOptionsNode setPfxTrustOptions(String value) {
      	if (has(getNode(), "pfxTrustOptions")) getNode().removeProperty("pfxTrustOptions");
      	if (value!=null) getNode().setProperty("pfxTrustOptions", value);
         return this;
      }

      private httpClientOptionsNode fillPfxTrustOptions(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "pfxTrustOptions")) statement.setPfxTrustOptions(get(getNode(), "pfxTrustOptions"));
      	return this;
      } 

       // pipelining
      public httpClientOptionsNode setPipelining(String value) {
      	if (has(getNode(), "pipelining")) getNode().removeProperty("pipelining");
      	if (value!=null) getNode().setProperty("pipelining", value);
         return this;
      }

      private httpClientOptionsNode fillPipelining(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "pipelining")) statement.setPipelining(get(getNode(), "pipelining"));
      	return this;
      } 

       // protocolVersion
      public httpClientOptionsNode setProtocolVersion(String value) {
      	if (has(getNode(), "protocolVersion")) getNode().removeProperty("protocolVersion");
      	if (value!=null) getNode().setProperty("protocolVersion", value);
         return this;
      }

      private httpClientOptionsNode fillProtocolVersion(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "protocolVersion")) statement.setProtocolVersion(get(getNode(), "protocolVersion"));
      	return this;
      } 

       // receiveBufferSize
      public httpClientOptionsNode setReceiveBufferSize(String value) {
      	if (has(getNode(), "receiveBufferSize")) getNode().removeProperty("receiveBufferSize");
      	if (value!=null) getNode().setProperty("receiveBufferSize", value);
         return this;
      }

      private httpClientOptionsNode fillReceiveBufferSize(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "receiveBufferSize")) statement.setReceiveBufferSize(get(getNode(), "receiveBufferSize"));
      	return this;
      } 

       // reference
      public httpClientOptionsNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private httpClientOptionsNode fillReference(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // reuseAddress
      public httpClientOptionsNode setReuseAddress(String value) {
      	if (has(getNode(), "reuseAddress")) getNode().removeProperty("reuseAddress");
      	if (value!=null) getNode().setProperty("reuseAddress", value);
         return this;
      }

      private httpClientOptionsNode fillReuseAddress(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "reuseAddress")) statement.setReuseAddress(get(getNode(), "reuseAddress"));
      	return this;
      } 

       // sendBufferSize
      public httpClientOptionsNode setSendBufferSize(String value) {
      	if (has(getNode(), "sendBufferSize")) getNode().removeProperty("sendBufferSize");
      	if (value!=null) getNode().setProperty("sendBufferSize", value);
         return this;
      }

      private httpClientOptionsNode fillSendBufferSize(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "sendBufferSize")) statement.setSendBufferSize(get(getNode(), "sendBufferSize"));
      	return this;
      } 

       // soLinger
      public httpClientOptionsNode setSoLinger(String value) {
      	if (has(getNode(), "soLinger")) getNode().removeProperty("soLinger");
      	if (value!=null) getNode().setProperty("soLinger", value);
         return this;
      }

      private httpClientOptionsNode fillSoLinger(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "soLinger")) statement.setSoLinger(get(getNode(), "soLinger"));
      	return this;
      } 

       // ssl
      public httpClientOptionsNode setSsl(String value) {
      	if (has(getNode(), "ssl")) getNode().removeProperty("ssl");
      	if (value!=null) getNode().setProperty("ssl", value);
         return this;
      }

      private httpClientOptionsNode fillSsl(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "ssl")) statement.setSsl(get(getNode(), "ssl"));
      	return this;
      } 

       // tcpKeepAlive
      public httpClientOptionsNode setTcpKeepAlive(String value) {
      	if (has(getNode(), "tcpKeepAlive")) getNode().removeProperty("tcpKeepAlive");
      	if (value!=null) getNode().setProperty("tcpKeepAlive", value);
         return this;
      }

      private httpClientOptionsNode fillTcpKeepAlive(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "tcpKeepAlive")) statement.setTcpKeepAlive(get(getNode(), "tcpKeepAlive"));
      	return this;
      } 

       // tcpNoDelay
      public httpClientOptionsNode setTcpNoDelay(String value) {
      	if (has(getNode(), "tcpNoDelay")) getNode().removeProperty("tcpNoDelay");
      	if (value!=null) getNode().setProperty("tcpNoDelay", value);
         return this;
      }

      private httpClientOptionsNode fillTcpNoDelay(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "tcpNoDelay")) statement.setTcpNoDelay(get(getNode(), "tcpNoDelay"));
      	return this;
      } 

       // trafficClass
      public httpClientOptionsNode setTrafficClass(String value) {
      	if (has(getNode(), "trafficClass")) getNode().removeProperty("trafficClass");
      	if (value!=null) getNode().setProperty("trafficClass", value);
         return this;
      }

      private httpClientOptionsNode fillTrafficClass(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "trafficClass")) statement.setTrafficClass(get(getNode(), "trafficClass"));
      	return this;
      } 

       // trustAll
      public httpClientOptionsNode setTrustAll(String value) {
      	if (has(getNode(), "trustAll")) getNode().removeProperty("trustAll");
      	if (value!=null) getNode().setProperty("trustAll", value);
         return this;
      }

      private httpClientOptionsNode fillTrustAll(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "trustAll")) statement.setTrustAll(get(getNode(), "trustAll"));
      	return this;
      } 

       // trustStore
      public httpClientOptionsNode setTrustStore(String value) {
      	if (has(getNode(), "trustStore")) getNode().removeProperty("trustStore");
      	if (value!=null) getNode().setProperty("trustStore", value);
         return this;
      }

      private httpClientOptionsNode fillTrustStore(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "trustStore")) statement.setTrustStore(get(getNode(), "trustStore"));
      	return this;
      } 

       // tryUseCompression
      public httpClientOptionsNode setTryUseCompression(String value) {
      	if (has(getNode(), "tryUseCompression")) getNode().removeProperty("tryUseCompression");
      	if (value!=null) getNode().setProperty("tryUseCompression", value);
         return this;
      }

      private httpClientOptionsNode fillTryUseCompression(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "tryUseCompression")) statement.setTryUseCompression(get(getNode(), "tryUseCompression"));
      	return this;
      } 

       // usePooledBuffers
      public httpClientOptionsNode setUsePooledBuffers(String value) {
      	if (has(getNode(), "usePooledBuffers")) getNode().removeProperty("usePooledBuffers");
      	if (value!=null) getNode().setProperty("usePooledBuffers", value);
         return this;
      }

      private httpClientOptionsNode fillUsePooledBuffers(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "usePooledBuffers")) statement.setUsePooledBuffers(get(getNode(), "usePooledBuffers"));
      	return this;
      } 

       // verifyHost
      public httpClientOptionsNode setVerifyHost(String value) {
      	if (has(getNode(), "verifyHost")) getNode().removeProperty("verifyHost");
      	if (value!=null) getNode().setProperty("verifyHost", value);
         return this;
      }

      private httpClientOptionsNode fillVerifyHost(VertxCoreGroup.httpClientOptionsST statement) {
      	if (has(getNode(), "verifyHost")) statement.setVerifyHost(get(getNode(), "verifyHost"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientPumpFileNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientPumpFileNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientPumpFileST fill(VertxCoreGroup.httpClientPumpFileST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientPumpFile()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientPutRequestHeadersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientPutRequestHeadersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientPutRequestHeadersST fill(VertxCoreGroup.httpClientPutRequestHeadersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientPutRequestHeaders()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientRequestTimeoutNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientRequestTimeoutNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientRequestTimeoutST fill(VertxCoreGroup.httpClientRequestTimeoutST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientRequestTimeout()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientResponseBodyChunkNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientResponseBodyChunkNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientResponseBodyChunkST fill(VertxCoreGroup.httpClientResponseBodyChunkST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientResponseBodyChunk()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientResponseBodyHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientResponseBodyHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientResponseBodyHandlerST fill(VertxCoreGroup.httpClientResponseBodyHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientResponseBodyHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientResponseHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientResponseHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientResponseHandlerST fill(VertxCoreGroup.httpClientResponseHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientResponseHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientResponseHeadersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientResponseHeadersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientResponseHeadersST fill(VertxCoreGroup.httpClientResponseHeadersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientResponseHeaders()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientResponseInMemoryNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientResponseInMemoryNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientResponseInMemoryST fill(VertxCoreGroup.httpClientResponseInMemoryST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientResponseInMemory()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientSetRequestHeadersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientSetRequestHeadersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientSetRequestHeadersST fill(VertxCoreGroup.httpClientSetRequestHeadersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientSetRequestHeaders()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpClientWriteToRequestNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpClientWriteToRequestNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpClientWriteToRequestST fill(VertxCoreGroup.httpClientWriteToRequestST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpClientWriteToRequest()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponseEndNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponseEndNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponseEndST fill(VertxCoreGroup.httpResponseEndST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponseEnd()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponsePutHeaderNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponsePutHeaderNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponsePutHeaderST fill(VertxCoreGroup.httpResponsePutHeaderST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponsePutHeader()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponsePutTrailersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponsePutTrailersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponsePutTrailersST fill(VertxCoreGroup.httpResponsePutTrailersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponsePutTrailers()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponseSTartNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponseSTartNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponseSTartST fill(VertxCoreGroup.httpResponseSTartST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponseSTart()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponseSetHeaderNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponseSetHeaderNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponseSetHeaderST fill(VertxCoreGroup.httpResponseSetHeaderST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponseSetHeader()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponseSetTrailersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponseSetTrailersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponseSetTrailersST fill(VertxCoreGroup.httpResponseSetTrailersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponseSetTrailers()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpResponseWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpResponseWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpResponseWriteST fill(VertxCoreGroup.httpResponseWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpResponseWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpServeFileNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpServeFileNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpServeFileST fill(VertxCoreGroup.httpServeFileST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpServeFile()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpServerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpServerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpServerST fill(VertxCoreGroup.httpServerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpServer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpServerIncomingNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpServerIncomingNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpServerIncomingST fill(VertxCoreGroup.httpServerIncomingST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpServerIncoming()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpServerListenHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpServerListenHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpServerListenHandlerST fill(VertxCoreGroup.httpServerListenHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpServerListenHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class httpServerPartialFileNode {

      private final NeoModel model;
   	private final UUID uuid;

      private httpServerPartialFileNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.httpServerPartialFileST fill(VertxCoreGroup.httpServerPartialFileST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newhttpServerPartialFile()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class inMemoryBodyAggrNode {

      private final NeoModel model;
   	private final UUID uuid;

      private inMemoryBodyAggrNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.inMemoryBodyAggrST fill(VertxCoreGroup.inMemoryBodyAggrST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newinMemoryBodyAggr()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class inMemoryBodyAggrShortNode {

      private final NeoModel model;
   	private final UUID uuid;

      private inMemoryBodyAggrShortNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.inMemoryBodyAggrShortST fill(VertxCoreGroup.inMemoryBodyAggrShortST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newinMemoryBodyAggrShort()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class isolateVerticleDeploymentNode {

      private final NeoModel model;
   	private final UUID uuid;

      private isolateVerticleDeploymentNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.isolateVerticleDeploymentST fill(VertxCoreGroup.isolateVerticleDeploymentST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newisolateVerticleDeployment()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class jsonNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   REFERENCE, VALUES
   	}

      private jsonNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.jsonST fill(VertxCoreGroup.jsonST statement) {
   		fillReference(statement);
   		fillValues(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newjson()).toString();
   	}
       // reference
      public jsonNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private jsonNode fillReference(VertxCoreGroup.jsonST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // values
      public jsonNode addValuesValue(String key_, String value_) {
      	final Node newNode = model.newNode("json_values", UUID.randomUUID());
      	getNode().createRelationshipTo(newNode, PARAMS.VALUES);
      	if (key_ != null) newNode.setProperty("key", key_); 
      	if (value_ != null) newNode.setProperty("value", value_);    
      	return this;
      }

      private jsonNode fillValues(VertxCoreGroup.jsonST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.VALUES)) {
      		final Node node = other(getNode(), relationship);
      		statement.addValuesValue(node.hasProperty("key") ? node.getProperty("key") : null, node.hasProperty("value") ? node.getProperty("value") : null);
      	}
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class jsonFromStringNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   REFERENCE, STRING
   	}

      private jsonFromStringNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.jsonFromStringST fill(VertxCoreGroup.jsonFromStringST statement) {
   		fillReference(statement);
   		fillString(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newjsonFromString()).toString();
   	}
       // reference
      public jsonFromStringNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private jsonFromStringNode fillReference(VertxCoreGroup.jsonFromStringST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // string
      public jsonFromStringNode setString(String value) {
      	if (has(getNode(), "string")) getNode().removeProperty("string");
      	if (value!=null) getNode().setProperty("string", value);
         return this;
      }

      private jsonFromStringNode fillString(VertxCoreGroup.jsonFromStringST statement) {
      	if (has(getNode(), "string")) statement.setString(get(getNode(), "string"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class jsonGetIntegerNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME, REFERENCE
   	}

      private jsonGetIntegerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.jsonGetIntegerST fill(VertxCoreGroup.jsonGetIntegerST statement) {
   		fillName(statement);
   		fillReference(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newjsonGetInteger()).toString();
   	}
       // name
      public jsonGetIntegerNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private jsonGetIntegerNode fillName(VertxCoreGroup.jsonGetIntegerST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // reference
      public jsonGetIntegerNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private jsonGetIntegerNode fillReference(VertxCoreGroup.jsonGetIntegerST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class jsonGetStringNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME, REFERENCE
   	}

      private jsonGetStringNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.jsonGetStringST fill(VertxCoreGroup.jsonGetStringST statement) {
   		fillName(statement);
   		fillReference(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newjsonGetString()).toString();
   	}
       // name
      public jsonGetStringNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private jsonGetStringNode fillName(VertxCoreGroup.jsonGetStringST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // reference
      public jsonGetStringNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private jsonGetStringNode fillReference(VertxCoreGroup.jsonGetStringST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class leaveMulticastGroupNode {

      private final NeoModel model;
   	private final UUID uuid;

      private leaveMulticastGroupNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.leaveMulticastGroupST fill(VertxCoreGroup.leaveMulticastGroupST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newleaveMulticastGroup()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class localSharedMapNode {

      private final NeoModel model;
   	private final UUID uuid;

      private localSharedMapNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.localSharedMapST fill(VertxCoreGroup.localSharedMapST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newlocalSharedMap()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class messageCodecNode {

      private final NeoModel model;
   	private final UUID uuid;

      private messageCodecNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.messageCodecST fill(VertxCoreGroup.messageCodecST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmessageCodec()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class messageHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   NAME, PACKAGENAME, STATEMENT
   	}

      private messageHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.messageHandlerST fill(VertxCoreGroup.messageHandlerST statement) {
   		fillName(statement);
   		fillPackageName(statement);
   		fillStatement(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmessageHandler()).toString();
   	}
       // name
      public messageHandlerNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private messageHandlerNode fillName(VertxCoreGroup.messageHandlerST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // packageName
      public messageHandlerNode setPackageName(String value) {
      	if (has(getNode(), "packageName")) getNode().removeProperty("packageName");
      	if (value!=null) getNode().setProperty("packageName", value);
         return this;
      }

      private messageHandlerNode fillPackageName(VertxCoreGroup.messageHandlerST statement) {
      	if (has(getNode(), "packageName")) statement.setPackageName(get(getNode(), "packageName"));
      	return this;
      } 

       // statement
      public messageHandlerNode setStatement(String value) {
      	if (has(getNode(), "statement")) getNode().removeProperty("statement");
      	if (value!=null) getNode().setProperty("statement", value);
         return this;
      }

      private messageHandlerNode fillStatement(VertxCoreGroup.messageHandlerST statement) {
      	if (has(getNode(), "statement")) statement.setStatement(get(getNode(), "statement"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class messageHeadersNode {

      private final NeoModel model;
   	private final UUID uuid;

      private messageHeadersNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.messageHeadersST fill(VertxCoreGroup.messageHeadersST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmessageHeaders()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class multipleServersCommandLineNode {

      private final NeoModel model;
   	private final UUID uuid;

      private multipleServersCommandLineNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.multipleServersCommandLineST fill(VertxCoreGroup.multipleServersCommandLineST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmultipleServersCommandLine()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class multipleServersProgrammaticallyNode {

      private final NeoModel model;
   	private final UUID uuid;

      private multipleServersProgrammaticallyNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.multipleServersProgrammaticallyST fill(VertxCoreGroup.multipleServersProgrammaticallyST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmultipleServersProgrammatically()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class multpileServersVerticleNode {

      private final NeoModel model;
   	private final UUID uuid;

      private multpileServersVerticleNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.multpileServersVerticleST fill(VertxCoreGroup.multpileServersVerticleST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmultpileServersVerticle()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class mvnNode {

      private final NeoModel model;
   	private final UUID uuid;

      private mvnNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.mvnST fill(VertxCoreGroup.mvnST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmvn()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class mvnAuthShiroNode {

      private final NeoModel model;
   	private final UUID uuid;

      private mvnAuthShiroNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.mvnAuthShiroST fill(VertxCoreGroup.mvnAuthShiroST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmvnAuthShiro()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class mvnDropwizardMetricsNode {

      private final NeoModel model;
   	private final UUID uuid;

      private mvnDropwizardMetricsNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.mvnDropwizardMetricsST fill(VertxCoreGroup.mvnDropwizardMetricsST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmvnDropwizardMetrics()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class mvnJunitNode {

      private final NeoModel model;
   	private final UUID uuid;

      private mvnJunitNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.mvnJunitST fill(VertxCoreGroup.mvnJunitST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newmvnJunit()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newAsynchVerticleNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newAsynchVerticleNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newAsynchVerticleST fill(VertxCoreGroup.newAsynchVerticleST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewAsynchVerticle()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newBufferST fill(VertxCoreGroup.newBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newBufferByteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newBufferByteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newBufferByteST fill(VertxCoreGroup.newBufferByteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewBufferByte()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newBufferSizeNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newBufferSizeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newBufferSizeST fill(VertxCoreGroup.newBufferSizeST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewBufferSize()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newBufferStringNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newBufferStringNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newBufferStringST fill(VertxCoreGroup.newBufferStringST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewBufferString()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newBufferStringEncodedNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newBufferStringEncodedNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newBufferStringEncodedST fill(VertxCoreGroup.newBufferStringEncodedST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewBufferStringEncoded()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newDatagramSocketNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newDatagramSocketNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newDatagramSocketST fill(VertxCoreGroup.newDatagramSocketST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewDatagramSocket()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newEventBusNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newEventBusNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newEventBusST fill(VertxCoreGroup.newEventBusST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewEventBus()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newJsonArrayNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newJsonArrayNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newJsonArrayST fill(VertxCoreGroup.newJsonArrayST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewJsonArray()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newTCPClientNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newTCPClientNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newTCPClientST fill(VertxCoreGroup.newTCPClientST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewTCPClient()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class newTcpServerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private newTcpServerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.newTcpServerST fill(VertxCoreGroup.newTcpServerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newnewTcpServer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class oneShotTimerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private oneShotTimerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.oneShotTimerST fill(VertxCoreGroup.oneShotTimerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newoneShotTimer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class periodicTimerNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   MS, REFERENCE, STATEMENTS
   	}

      private periodicTimerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.periodicTimerST fill(VertxCoreGroup.periodicTimerST statement) {
   		fillMs(statement);
   		fillReference(statement);
   		fillStatements(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newperiodicTimer()).toString();
   	}
       // ms
      public periodicTimerNode setMs(String value) {
      	if (has(getNode(), "ms")) getNode().removeProperty("ms");
      	if (value!=null) getNode().setProperty("ms", value);
         return this;
      }

      private periodicTimerNode fillMs(VertxCoreGroup.periodicTimerST statement) {
      	if (has(getNode(), "ms")) statement.setMs(get(getNode(), "ms"));
      	return this;
      } 

       // reference
      public periodicTimerNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private periodicTimerNode fillReference(VertxCoreGroup.periodicTimerST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

       // statements
      public periodicTimerNode addStatementsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("periodicTimer_statements", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.STATEMENTS);
      	}
         return this;
      }

      private periodicTimerNode fillStatements(VertxCoreGroup.periodicTimerST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.STATEMENTS))
      		statement.addStatementsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class postWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private postWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.postWriteST fill(VertxCoreGroup.postWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newpostWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class publishMessageNode {

      private final NeoModel model;
   	private final UUID uuid;

      private publishMessageNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.publishMessageST fill(VertxCoreGroup.publishMessageST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newpublishMessage()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class pumpResponseNode {

      private final NeoModel model;
   	private final UUID uuid;

      private pumpResponseNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.pumpResponseST fill(VertxCoreGroup.pumpResponseST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newpumpResponse()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class pumpStreamsNode {

      private final NeoModel model;
   	private final UUID uuid;

      private pumpStreamsNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.pumpStreamsST fill(VertxCoreGroup.pumpStreamsST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newpumpStreams()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class putDataInMapNode {

      private final NeoModel model;
   	private final UUID uuid;

      private putDataInMapNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.putDataInMapST fill(VertxCoreGroup.putDataInMapST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newputDataInMap()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class putJsonNode {

      private final NeoModel model;
   	private final UUID uuid;

      private putJsonNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.putJsonST fill(VertxCoreGroup.putJsonST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newputJson()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class randomAccessBufferWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private randomAccessBufferWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.randomAccessBufferWriteST fill(VertxCoreGroup.randomAccessBufferWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrandomAccessBufferWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class randomAccessReadNode {

      private final NeoModel model;
   	private final UUID uuid;

      private randomAccessReadNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.randomAccessReadST fill(VertxCoreGroup.randomAccessReadST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrandomAccessRead()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class randomAccessWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private randomAccessWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.randomAccessWriteST fill(VertxCoreGroup.randomAccessWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrandomAccessWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class readBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private readBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.readBufferST fill(VertxCoreGroup.readBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreadBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class readFileAsynchNode {

      private final NeoModel model;
   	private final UUID uuid;

      private readFileAsynchNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.readFileAsynchST fill(VertxCoreGroup.readFileAsynchST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreadFileAsynch()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class readSocketDataNode {

      private final NeoModel model;
   	private final UUID uuid;

      private readSocketDataNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.readSocketDataST fill(VertxCoreGroup.readSocketDataST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreadSocketData()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class readUnsignedNumberNode {

      private final NeoModel model;
   	private final UUID uuid;

      private readUnsignedNumberNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.readUnsignedNumberST fill(VertxCoreGroup.readUnsignedNumberST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreadUnsignedNumber()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class receiveDatagramPacketNode {

      private final NeoModel model;
   	private final UUID uuid;

      private receiveDatagramPacketNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.receiveDatagramPacketST fill(VertxCoreGroup.receiveDatagramPacketST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreceiveDatagramPacket()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class receiveMulticastNode {

      private final NeoModel model;
   	private final UUID uuid;

      private receiveMulticastNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.receiveMulticastST fill(VertxCoreGroup.receiveMulticastST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreceiveMulticast()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class recordParserNode {

      private final NeoModel model;
   	private final UUID uuid;

      private recordParserNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.recordParserST fill(VertxCoreGroup.recordParserST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrecordParser()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class recordParserFixedNode {

      private final NeoModel model;
   	private final UUID uuid;

      private recordParserFixedNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.recordParserFixedST fill(VertxCoreGroup.recordParserFixedST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrecordParserFixed()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class registerHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private registerHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.registerHandlerST fill(VertxCoreGroup.registerHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newregisterHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class replyMessageNode {

      private final NeoModel model;
   	private final UUID uuid;

      private replyMessageNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.replyMessageST fill(VertxCoreGroup.replyMessageST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreplyMessage()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class replyReceivedMessageNode {

      private final NeoModel model;
   	private final UUID uuid;

      private replyReceivedMessageNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.replyReceivedMessageST fill(VertxCoreGroup.replyReceivedMessageST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newreplyReceivedMessage()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class requestHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private requestHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.requestHandlerST fill(VertxCoreGroup.requestHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrequestHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class retriveContextNode {

      private final NeoModel model;
   	private final UUID uuid;

      private retriveContextNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.retriveContextST fill(VertxCoreGroup.retriveContextST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newretriveContext()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class revokateAuthNode {

      private final NeoModel model;
   	private final UUID uuid;

      private revokateAuthNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.revokateAuthST fill(VertxCoreGroup.revokateAuthST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrevokateAuth()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class revokateAuthBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private revokateAuthBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.revokateAuthBufferST fill(VertxCoreGroup.revokateAuthBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrevokateAuthBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class runInContextNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   STATEMENTS
   	}

      private runInContextNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.runInContextST fill(VertxCoreGroup.runInContextST statement) {
   		fillStatements(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newrunInContext()).toString();
   	}
       // statements
      public runInContextNode addStatementsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("runInContext_statements", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.STATEMENTS);
      	}
         return this;
      }

      private runInContextNode fillStatements(VertxCoreGroup.runInContextST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.STATEMENTS))
      		statement.addStatementsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class sendFileNode {

      private final NeoModel model;
   	private final UUID uuid;

      private sendFileNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.sendFileST fill(VertxCoreGroup.sendFileST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newsendFile()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class sendMessageNode {

      private final NeoModel model;
   	private final UUID uuid;

      private sendMessageNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.sendMessageST fill(VertxCoreGroup.sendMessageST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newsendMessage()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class sendMulticastNode {

      private final NeoModel model;
   	private final UUID uuid;

      private sendMulticastNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.sendMulticastST fill(VertxCoreGroup.sendMulticastST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newsendMulticast()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverConnectionHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverConnectionHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverConnectionHandlerST fill(VertxCoreGroup.serverConnectionHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverConnectionHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverListenHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverListenHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverListenHandlerST fill(VertxCoreGroup.serverListenHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverListenHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLBufferConfigurationNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLBufferConfigurationNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLBufferConfigurationST fill(VertxCoreGroup.serverSSLBufferConfigurationST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLBufferConfiguration()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLKeystoreNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLKeystoreNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLKeystoreST fill(VertxCoreGroup.serverSSLKeystoreST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLKeystore()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLKeystoreBuffNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLKeystoreBuffNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLKeystoreBuffST fill(VertxCoreGroup.serverSSLKeystoreBuffST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLKeystoreBuff()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPEMNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPEMNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPEMST fill(VertxCoreGroup.serverSSLPEMST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPEM()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPEMAuthorityNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPEMAuthorityNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPEMAuthorityST fill(VertxCoreGroup.serverSSLPEMAuthorityST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPEMAuthority()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPEMAuthorityBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPEMAuthorityBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPEMAuthorityBufferST fill(VertxCoreGroup.serverSSLPEMAuthorityBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPEMAuthorityBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPEMBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPEMBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPEMBufferST fill(VertxCoreGroup.serverSSLPEMBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPEMBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPKCS_12Node {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPKCS_12Node(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPKCS_12ST fill(VertxCoreGroup.serverSSLPKCS_12ST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPKCS_12()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPKCS_12AuthorityNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPKCS_12AuthorityNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPKCS_12AuthorityST fill(VertxCoreGroup.serverSSLPKCS_12AuthorityST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPKCS_12Authority()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLPKCS_12AuthorityBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLPKCS_12AuthorityBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLPKCS_12AuthorityBufferST fill(VertxCoreGroup.serverSSLPKCS_12AuthorityBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLPKCS_12AuthorityBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLTrustAuthorityNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLTrustAuthorityNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLTrustAuthorityST fill(VertxCoreGroup.serverSSLTrustAuthorityST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLTrustAuthority()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class serverSSLTrustAuthorityBufferNode {

      private final NeoModel model;
   	private final UUID uuid;

      private serverSSLTrustAuthorityBufferNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.serverSSLTrustAuthorityBufferST fill(VertxCoreGroup.serverSSLTrustAuthorityBufferST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newserverSSLTrustAuthorityBuffer()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class simpleWriteRequestNode {

      private final NeoModel model;
   	private final UUID uuid;

      private simpleWriteRequestNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.simpleWriteRequestST fill(VertxCoreGroup.simpleWriteRequestST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newsimpleWriteRequest()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class socketClosedHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private socketClosedHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.socketClosedHandlerST fill(VertxCoreGroup.socketClosedHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newsocketClosedHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class undeployVerticlesNode {

      private final NeoModel model;
   	private final UUID uuid;

      private undeployVerticlesNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.undeployVerticlesST fill(VertxCoreGroup.undeployVerticlesST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newundeployVerticles()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class verticleNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   FIELDS, IMPORTS, NAME, PACKAGENAME, STARTSTATEMENTS, STOPSTATEMENTS, VERTICLES
   	}

      private verticleNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.verticleST fill(VertxCoreGroup.verticleST statement) {
   		fillFields(statement);
   		fillImports(statement);
   		fillName(statement);
   		fillPackageName(statement);
   		fillStartStatements(statement);
   		fillStopStatements(statement);
   		fillVerticles(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newverticle()).toString();
   	}
       // fields
      public verticleNode addFieldsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("verticle_fields", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.FIELDS);
      	}
         return this;
      }

      private verticleNode fillFields(VertxCoreGroup.verticleST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.FIELDS))
      		statement.addFieldsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

       // imports
      public verticleNode addImportsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("verticle_imports", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.IMPORTS);
      	}
         return this;
      }

      private verticleNode fillImports(VertxCoreGroup.verticleST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.IMPORTS))
      		statement.addImportsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

       // name
      public verticleNode setName(String value) {
      	if (has(getNode(), "name")) getNode().removeProperty("name");
      	if (value!=null) getNode().setProperty("name", value);
         return this;
      }

      private verticleNode fillName(VertxCoreGroup.verticleST statement) {
      	if (has(getNode(), "name")) statement.setName(get(getNode(), "name"));
      	return this;
      } 

       // packageName
      public verticleNode setPackageName(String value) {
      	if (has(getNode(), "packageName")) getNode().removeProperty("packageName");
      	if (value!=null) getNode().setProperty("packageName", value);
         return this;
      }

      private verticleNode fillPackageName(VertxCoreGroup.verticleST statement) {
      	if (has(getNode(), "packageName")) statement.setPackageName(get(getNode(), "packageName"));
      	return this;
      } 

       // startStatements
      public verticleNode addStartStatementsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("verticle_startStatements", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.STARTSTATEMENTS);
      	}
         return this;
      }

      private verticleNode fillStartStatements(VertxCoreGroup.verticleST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.STARTSTATEMENTS))
      		statement.addStartStatementsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

       // stopStatements
      public verticleNode addStopStatementsValue(String value) {
      	if (value != null) {
      		final Node newNode = model.newNode("verticle_stopStatements", UUID.randomUUID());
      		newNode.setProperty("value", value);
      		getNode().createRelationshipTo(newNode, PARAMS.STOPSTATEMENTS);
      	}
         return this;
      }

      private verticleNode fillStopStatements(VertxCoreGroup.verticleST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.STOPSTATEMENTS))
      		statement.addStopStatementsValue(getOtherProperty(getNode(), relationship, "value"));
      	return this;
      } 

       // verticles
      public verticleNode addVerticlesValue(String deploy_) {
      	final Node newNode = model.newNode("verticle_verticles", UUID.randomUUID());
      	getNode().createRelationshipTo(newNode, PARAMS.VERTICLES);
      	if (deploy_ != null) newNode.setProperty("deploy", deploy_);    
      	return this;
      }

      private verticleNode fillVerticles(VertxCoreGroup.verticleST statement) {
      	for (Relationship relationship : outgoing(getNode(), PARAMS.VERTICLES)) {
      		final Node node = other(getNode(), relationship);
      		statement.addVerticlesValue(node.hasProperty("deploy") ? node.getProperty("deploy") : null);
      	}
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class verticleConfigurationNode {

      private final NeoModel model;
   	private final UUID uuid;

      private verticleConfigurationNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.verticleConfigurationST fill(VertxCoreGroup.verticleConfigurationST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newverticleConfiguration()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class verticleInstancesNode {

      private final NeoModel model;
   	private final UUID uuid;

      private verticleInstancesNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.verticleInstancesST fill(VertxCoreGroup.verticleInstancesST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newverticleInstances()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class vertxNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   OPTIONS, REFERENCE
   	}

      private vertxNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.vertxST fill(VertxCoreGroup.vertxST statement) {
   		fillOptions(statement);
   		fillReference(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newvertx()).toString();
   	}
       // options
      public vertxNode setOptions(String value) {
      	if (has(getNode(), "options")) getNode().removeProperty("options");
      	if (value!=null) getNode().setProperty("options", value);
         return this;
      }

      private vertxNode fillOptions(VertxCoreGroup.vertxST statement) {
      	if (has(getNode(), "options")) statement.setOptions(get(getNode(), "options"));
      	return this;
      } 

       // reference
      public vertxNode setReference(String value) {
      	if (has(getNode(), "reference")) getNode().removeProperty("reference");
      	if (value!=null) getNode().setProperty("reference", value);
         return this;
      }

      private vertxNode fillReference(VertxCoreGroup.vertxST statement) {
      	if (has(getNode(), "reference")) statement.setReference(get(getNode(), "reference"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class vertxOptionsNode {

      private final NeoModel model;
   	private final UUID uuid;

   	private enum PARAMS implements org.neo4j.graphdb.RelationshipType {
   	   BLOCKEDTHREADCHECKINTERVAL, CLUSTERHOST, CLUSTERMANAGER, CLUSTERPINGINTERVAL, CLUSTERPINGREPLYINTERVAL, CLUSTERPORT, CLUSTERPUBLICHOST, CLUSTERPUBLICPORT, CLUSTERED, EVENTLOOPPOOLSIZE, HAENABLED, HAGROUP, INTERNALBLOCKINGPOOLSIZE, MAXEVENTLOOPEXECUTETIME, MAXWORKEREXECUTETIME, METRICS, QUORUMSIZE, WARNINGEXCEPTIONTIME, WORKERPOOLSIZE
   	}

      private vertxOptionsNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.vertxOptionsST fill(VertxCoreGroup.vertxOptionsST statement) {
   		fillBlockedThreadCheckInterval(statement);
   		fillClusterHost(statement);
   		fillClusterManager(statement);
   		fillClusterPingInterval(statement);
   		fillClusterPingReplyInterval(statement);
   		fillClusterPort(statement);
   		fillClusterPublicHost(statement);
   		fillClusterPublicPort(statement);
   		fillClustered(statement);
   		fillEventLoopPoolSize(statement);
   		fillHaEnabled(statement);
   		fillHaGroup(statement);
   		fillInternalBlockingPoolSize(statement);
   		fillMaxEventLoopExecuteTime(statement);
   		fillMaxWorkerExecuteTime(statement);
   		fillMetrics(statement);
   		fillQuorumSize(statement);
   		fillWarningExceptionTime(statement);
   		fillWorkerPoolSize(statement);
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newvertxOptions()).toString();
   	}
       // blockedThreadCheckInterval
      public vertxOptionsNode setBlockedThreadCheckInterval(String value) {
      	if (has(getNode(), "blockedThreadCheckInterval")) getNode().removeProperty("blockedThreadCheckInterval");
      	if (value!=null) getNode().setProperty("blockedThreadCheckInterval", value);
         return this;
      }

      private vertxOptionsNode fillBlockedThreadCheckInterval(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "blockedThreadCheckInterval")) statement.setBlockedThreadCheckInterval(get(getNode(), "blockedThreadCheckInterval"));
      	return this;
      } 

       // clusterHost
      public vertxOptionsNode setClusterHost(String value) {
      	if (has(getNode(), "clusterHost")) getNode().removeProperty("clusterHost");
      	if (value!=null) getNode().setProperty("clusterHost", value);
         return this;
      }

      private vertxOptionsNode fillClusterHost(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterHost")) statement.setClusterHost(get(getNode(), "clusterHost"));
      	return this;
      } 

       // clusterManager
      public vertxOptionsNode setClusterManager(String value) {
      	if (has(getNode(), "clusterManager")) getNode().removeProperty("clusterManager");
      	if (value!=null) getNode().setProperty("clusterManager", value);
         return this;
      }

      private vertxOptionsNode fillClusterManager(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterManager")) statement.setClusterManager(get(getNode(), "clusterManager"));
      	return this;
      } 

       // clusterPingInterval
      public vertxOptionsNode setClusterPingInterval(String value) {
      	if (has(getNode(), "clusterPingInterval")) getNode().removeProperty("clusterPingInterval");
      	if (value!=null) getNode().setProperty("clusterPingInterval", value);
         return this;
      }

      private vertxOptionsNode fillClusterPingInterval(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterPingInterval")) statement.setClusterPingInterval(get(getNode(), "clusterPingInterval"));
      	return this;
      } 

       // clusterPingReplyInterval
      public vertxOptionsNode setClusterPingReplyInterval(String value) {
      	if (has(getNode(), "clusterPingReplyInterval")) getNode().removeProperty("clusterPingReplyInterval");
      	if (value!=null) getNode().setProperty("clusterPingReplyInterval", value);
         return this;
      }

      private vertxOptionsNode fillClusterPingReplyInterval(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterPingReplyInterval")) statement.setClusterPingReplyInterval(get(getNode(), "clusterPingReplyInterval"));
      	return this;
      } 

       // clusterPort
      public vertxOptionsNode setClusterPort(String value) {
      	if (has(getNode(), "clusterPort")) getNode().removeProperty("clusterPort");
      	if (value!=null) getNode().setProperty("clusterPort", value);
         return this;
      }

      private vertxOptionsNode fillClusterPort(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterPort")) statement.setClusterPort(get(getNode(), "clusterPort"));
      	return this;
      } 

       // clusterPublicHost
      public vertxOptionsNode setClusterPublicHost(String value) {
      	if (has(getNode(), "clusterPublicHost")) getNode().removeProperty("clusterPublicHost");
      	if (value!=null) getNode().setProperty("clusterPublicHost", value);
         return this;
      }

      private vertxOptionsNode fillClusterPublicHost(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterPublicHost")) statement.setClusterPublicHost(get(getNode(), "clusterPublicHost"));
      	return this;
      } 

       // clusterPublicPort
      public vertxOptionsNode setClusterPublicPort(String value) {
      	if (has(getNode(), "clusterPublicPort")) getNode().removeProperty("clusterPublicPort");
      	if (value!=null) getNode().setProperty("clusterPublicPort", value);
         return this;
      }

      private vertxOptionsNode fillClusterPublicPort(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clusterPublicPort")) statement.setClusterPublicPort(get(getNode(), "clusterPublicPort"));
      	return this;
      } 

       // clustered
      public vertxOptionsNode setClustered(String value) {
      	if (has(getNode(), "clustered")) getNode().removeProperty("clustered");
      	if (value!=null) getNode().setProperty("clustered", value);
         return this;
      }

      private vertxOptionsNode fillClustered(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "clustered")) statement.setClustered(get(getNode(), "clustered"));
      	return this;
      } 

       // eventLoopPoolSize
      public vertxOptionsNode setEventLoopPoolSize(String value) {
      	if (has(getNode(), "eventLoopPoolSize")) getNode().removeProperty("eventLoopPoolSize");
      	if (value!=null) getNode().setProperty("eventLoopPoolSize", value);
         return this;
      }

      private vertxOptionsNode fillEventLoopPoolSize(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "eventLoopPoolSize")) statement.setEventLoopPoolSize(get(getNode(), "eventLoopPoolSize"));
      	return this;
      } 

       // haEnabled
      public vertxOptionsNode setHaEnabled(String value) {
      	if (has(getNode(), "haEnabled")) getNode().removeProperty("haEnabled");
      	if (value!=null) getNode().setProperty("haEnabled", value);
         return this;
      }

      private vertxOptionsNode fillHaEnabled(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "haEnabled")) statement.setHaEnabled(get(getNode(), "haEnabled"));
      	return this;
      } 

       // haGroup
      public vertxOptionsNode setHaGroup(String value) {
      	if (has(getNode(), "haGroup")) getNode().removeProperty("haGroup");
      	if (value!=null) getNode().setProperty("haGroup", value);
         return this;
      }

      private vertxOptionsNode fillHaGroup(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "haGroup")) statement.setHaGroup(get(getNode(), "haGroup"));
      	return this;
      } 

       // internalBlockingPoolSize
      public vertxOptionsNode setInternalBlockingPoolSize(String value) {
      	if (has(getNode(), "internalBlockingPoolSize")) getNode().removeProperty("internalBlockingPoolSize");
      	if (value!=null) getNode().setProperty("internalBlockingPoolSize", value);
         return this;
      }

      private vertxOptionsNode fillInternalBlockingPoolSize(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "internalBlockingPoolSize")) statement.setInternalBlockingPoolSize(get(getNode(), "internalBlockingPoolSize"));
      	return this;
      } 

       // maxEventLoopExecuteTime
      public vertxOptionsNode setMaxEventLoopExecuteTime(String value) {
      	if (has(getNode(), "maxEventLoopExecuteTime")) getNode().removeProperty("maxEventLoopExecuteTime");
      	if (value!=null) getNode().setProperty("maxEventLoopExecuteTime", value);
         return this;
      }

      private vertxOptionsNode fillMaxEventLoopExecuteTime(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "maxEventLoopExecuteTime")) statement.setMaxEventLoopExecuteTime(get(getNode(), "maxEventLoopExecuteTime"));
      	return this;
      } 

       // maxWorkerExecuteTime
      public vertxOptionsNode setMaxWorkerExecuteTime(String value) {
      	if (has(getNode(), "maxWorkerExecuteTime")) getNode().removeProperty("maxWorkerExecuteTime");
      	if (value!=null) getNode().setProperty("maxWorkerExecuteTime", value);
         return this;
      }

      private vertxOptionsNode fillMaxWorkerExecuteTime(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "maxWorkerExecuteTime")) statement.setMaxWorkerExecuteTime(get(getNode(), "maxWorkerExecuteTime"));
      	return this;
      } 

       // metrics
      public vertxOptionsNode setMetrics(String value) {
      	if (has(getNode(), "metrics")) getNode().removeProperty("metrics");
      	if (value!=null) getNode().setProperty("metrics", value);
         return this;
      }

      private vertxOptionsNode fillMetrics(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "metrics")) statement.setMetrics(get(getNode(), "metrics"));
      	return this;
      } 

       // quorumSize
      public vertxOptionsNode setQuorumSize(String value) {
      	if (has(getNode(), "quorumSize")) getNode().removeProperty("quorumSize");
      	if (value!=null) getNode().setProperty("quorumSize", value);
         return this;
      }

      private vertxOptionsNode fillQuorumSize(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "quorumSize")) statement.setQuorumSize(get(getNode(), "quorumSize"));
      	return this;
      } 

       // warningExceptionTime
      public vertxOptionsNode setWarningExceptionTime(String value) {
      	if (has(getNode(), "warningExceptionTime")) getNode().removeProperty("warningExceptionTime");
      	if (value!=null) getNode().setProperty("warningExceptionTime", value);
         return this;
      }

      private vertxOptionsNode fillWarningExceptionTime(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "warningExceptionTime")) statement.setWarningExceptionTime(get(getNode(), "warningExceptionTime"));
      	return this;
      } 

       // workerPoolSize
      public vertxOptionsNode setWorkerPoolSize(String value) {
      	if (has(getNode(), "workerPoolSize")) getNode().removeProperty("workerPoolSize");
      	if (value!=null) getNode().setProperty("workerPoolSize", value);
         return this;
      }

      private vertxOptionsNode fillWorkerPoolSize(VertxCoreGroup.vertxOptionsST statement) {
      	if (has(getNode(), "workerPoolSize")) statement.setWorkerPoolSize(get(getNode(), "workerPoolSize"));
      	return this;
      } 

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketFrameWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketFrameWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketFrameWriteST fill(VertxCoreGroup.websocketFrameWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketFrameWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketHandlerNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketHandlerNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketHandlerST fill(VertxCoreGroup.websocketHandlerST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketHandler()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketReadFrameNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketReadFrameNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketReadFrameST fill(VertxCoreGroup.websocketReadFrameST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketReadFrame()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketSingleFrameWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketSingleFrameWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketSingleFrameWriteST fill(VertxCoreGroup.websocketSingleFrameWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketSingleFrameWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketUpgradeNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketUpgradeNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketUpgradeST fill(VertxCoreGroup.websocketUpgradeST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketUpgrade()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class websocketWriteNode {

      private final NeoModel model;
   	private final UUID uuid;

      private websocketWriteNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.websocketWriteST fill(VertxCoreGroup.websocketWriteST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwebsocketWrite()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class workerVerticleNode {

      private final NeoModel model;
   	private final UUID uuid;

      private workerVerticleNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.workerVerticleST fill(VertxCoreGroup.workerVerticleST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newworkerVerticle()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class writeFileAsynchNode {

      private final NeoModel model;
   	private final UUID uuid;

      private writeFileAsynchNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.writeFileAsynchST fill(VertxCoreGroup.writeFileAsynchST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwriteFileAsynch()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 

    public static final class writeSocketDataNode {

      private final NeoModel model;
   	private final UUID uuid;

      private writeSocketDataNode(final NeoModel model, UUID uuid) {
   		this.model = model;
   		this.uuid = uuid;
   	}

   	public VertxCoreGroup.writeSocketDataST fill(VertxCoreGroup.writeSocketDataST statement) {
   		return statement;
   	}

   	@Override
   	public String toString() {
   		return fill(group.newwriteSocketData()).toString();
   	}

   	public UUID getUUID() {
   		return uuid;
   	}

   	public Node getNode() {
   		return model.getNode(uuid);
   	}
   } 
} 