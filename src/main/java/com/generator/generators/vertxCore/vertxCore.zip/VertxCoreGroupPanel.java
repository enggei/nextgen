 package com.generator.generators.vertxCore;

import com.generator.generators.vertxCore.vertx.*;
import com.generator.generators.templates.domain.GeneratedFile;
import com.generator.util.CompileUtil;
import com.generator.util.SwingUtil;
import com.generator.util.FileUtil;
import com.generator.util.VertxUtil;
import io.vertx.core.Verticle;
import io.vertx.core.Vertx;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.UUID;

/**
 * from wrapped STGroupFile
 */
public final class VertxCoreGroupPanel extends JPanel {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(VertxCoreGroupPanel.class);

	public static void main(String[] args) {
		System.setProperty("generator.path", "src/main/java/com/generator/generators");
		final Vertx vertx = Vertx.vertx();
		final JPanel owner = new JPanel(new BorderLayout());
		final JTabbedPane declarationsPanel = new JTabbedPane();
		owner.add(new VertxCoreGroupPanel(vertx, declarationsPanel, new JTextField("/media/storage/nextgen/src/main/java")), BorderLayout.NORTH);
		owner.add(declarationsPanel, BorderLayout.CENTER);
		SwingUtil.showPanel(owner);
	}

	public VertxCoreGroupPanel(Vertx vertx, final JTabbedPane declarationsPanel, final JTextField txtRoot) {
		super(new com.generator.util.WrapLayout());
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "appendBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					appendBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("appendBufferInstance", new GroupappendBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "asynchFileVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					asynchFileVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("asynchFileInstance", new GroupasynchFilePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "asynchVerticleStopVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					asynchVerticleStopVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("asynchVerticleStopInstance", new GroupasynchVerticleStopPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "blockMulticastVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					blockMulticastVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("blockMulticastInstance", new GroupblockMulticastPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "blockingCodeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					blockingCodeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("blockingCodeInstance", new GroupblockingCodePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "bodyHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					bodyHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("bodyHandlerInstance", new GroupbodyHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "bufCopyVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					bufCopyVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("bufCopyInstance", new GroupbufCopyPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "bufLengthVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					bufLengthVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("bufLengthInstance", new GroupbufLengthPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "bufSliceVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					bufSliceVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("bufSliceInstance", new GroupbufSlicePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "bugfixVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					bugfixVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("bugfixInstance", new GroupbugfixPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "cancelTimerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					cancelTimerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("cancelTimerInstance", new GroupcancelTimerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "checkExistenceAndDeleteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					checkExistenceAndDeleteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("checkExistenceAndDeleteInstance", new GroupcheckExistenceAndDeletePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "chunkFileUploadHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					chunkFileUploadHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("chunkFileUploadHandlerInstance", new GroupchunkFileUploadHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientConnectVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientConnectVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientConnectInstance", new GroupclientConnectPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientRequestVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientRequestVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientRequestInstance", new GroupclientRequestPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLInstance", new GroupclientSSLPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLKeystoreAuthVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLKeystoreAuthVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLKeystoreAuthInstance", new GroupclientSSLKeystoreAuthPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLKeystoreAuthBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLKeystoreAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLKeystoreAuthBufferInstance", new GroupclientSSLKeystoreAuthBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPEMVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPEMVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPEMInstance", new GroupclientSSLPEMPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPEMAuthVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPEMAuthVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPEMAuthInstance", new GroupclientSSLPEMAuthPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPEMAuthBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPEMAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPEMAuthBufferInstance", new GroupclientSSLPEMAuthBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPEMBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPEMBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPEMBufferInstance", new GroupclientSSLPEMBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPKCSAuthVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPKCSAuthVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPKCSAuthInstance", new GroupclientSSLPKCSAuthPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPKCSAuthBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPKCSAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPKCSAuthBufferInstance", new GroupclientSSLPKCSAuthBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPKCS_12Verticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPKCS_12Verticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPKCS_12Instance", new GroupclientSSLPKCS_12Panel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLPKCS_12BufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLPKCS_12BufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLPKCS_12BufferInstance", new GroupclientSSLPKCS_12BufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLTruststoreVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLTruststoreVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLTruststoreInstance", new GroupclientSSLTruststorePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientSSLTruststoreBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientSSLTruststoreBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientSSLTruststoreBufferInstance", new GroupclientSSLTruststoreBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clientWebsocketVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clientWebsocketVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clientWebsocketInstance", new GroupclientWebsocketPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "closeServerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					closeServerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("closeServerInstance", new GroupcloseServerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterCommandLineVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterCommandLineVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterCommandLineInstance", new GroupclusterCommandLinePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterCounterVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterCounterVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterCounterInstance", new GroupclusterCounterPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterProgrammaticallyVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterProgrammaticallyInstance", new GroupclusterProgrammaticallyPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterSharedMapVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterSharedMapVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterSharedMapInstance", new GroupclusterSharedMapPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterWideLockVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterWideLockVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterWideLockInstance", new GroupclusterWideLockPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "clusterWideLockTimeoutVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					clusterWideLockTimeoutVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("clusterWideLockTimeoutInstance", new GroupclusterWideLockTimeoutPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "cmdHighAvailabilityVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					cmdHighAvailabilityVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("cmdHighAvailabilityInstance", new GroupcmdHighAvailabilityPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "cmdRunVerticlesVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					cmdRunVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("cmdRunVerticlesInstance", new GroupcmdRunVerticlesPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "configGetIntegerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					configGetIntegerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("configGetIntegerInstance", new GroupconfigGetIntegerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "configGetStringVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					configGetStringVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("configGetStringInstance", new GroupconfigGetStringPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "configureCipherSuiteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					configureCipherSuiteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("configureCipherSuiteInstance", new GroupconfigureCipherSuitePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "consumerCompletionHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					consumerCompletionHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("consumerCompletionHandlerInstance", new GroupconsumerCompletionHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "contextSharedDataVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					contextSharedDataVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("contextSharedDataInstance", new GroupcontextSharedDataPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "contextTypeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					contextTypeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("contextTypeInstance", new GroupcontextTypePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "copyFileAsynchVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					copyFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("copyFileAsynchInstance", new GroupcopyFileAsynchPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "copyFileSynchVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					copyFileSynchVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("copyFileSynchInstance", new GroupcopyFileSynchPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "deployPolyVerticlesVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					deployPolyVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("deployPolyVerticlesInstance", new GroupdeployPolyVerticlesPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "deployVerticleProgrammaticallyVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					deployVerticleProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("deployVerticleProgrammaticallyInstance", new GroupdeployVerticleProgrammaticallyPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "deployVerticleStartVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					deployVerticleStartVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("deployVerticleStartInstance", new GroupdeployVerticleStartPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsClientVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsClientVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsClientInstance", new GroupdnsClientPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsLookupVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsLookupVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsLookupInstance", new GroupdnsLookupPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsLookup4Verticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsLookup4Verticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsLookup4Instance", new GroupdnsLookup4Panel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsLookup6Verticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsLookup6Verticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsLookup6Instance", new GroupdnsLookup6Panel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveAVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveAVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveAInstance", new GroupdnsResolveAPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveAAAAVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveAAAAVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveAAAAInstance", new GroupdnsResolveAAAAPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveCNAMEVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveCNAMEVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveCNAMEInstance", new GroupdnsResolveCNAMEPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveMXVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveMXVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveMXInstance", new GroupdnsResolveMXPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveNSVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveNSVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveNSInstance", new GroupdnsResolveNSPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolvePTRVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolvePTRVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolvePTRInstance", new GroupdnsResolvePTRPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveSRVVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveSRVVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveSRVInstance", new GroupdnsResolveSRVPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResolveTXTVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResolveTXTVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResolveTXTInstance", new GroupdnsResolveTXTPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsResponseCodeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsResponseCodeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsResponseCodeInstance", new GroupdnsResponseCodePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "dnsReverseLookupVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					dnsReverseLookupVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("dnsReverseLookupInstance", new GroupdnsReverseLookupPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "ebConsumeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					ebConsumeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("ebConsumeInstance", new GroupebConsumePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "ebPublishVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					ebPublishVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("ebPublishInstance", new GroupebPublishPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "encodeArrayVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					encodeArrayVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("encodeArrayInstance", new GroupencodeArrayPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "fileStreamVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					fileStreamVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("fileStreamInstance", new GroupfileStreamPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "formFileStreamUploadVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					formFileStreamUploadVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("formFileStreamUploadInstance", new GroupformFileStreamUploadPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "formFileUploadHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					formFileUploadHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("formFileUploadHandlerInstance", new GroupformFileUploadHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "formHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					formHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("formHandlerInstance", new GroupformHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "getDataFromMapVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					getDataFromMapVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("getDataFromMapInstance", new GroupgetDataFromMapPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "getJsonVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					getJsonVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("getJsonInstance", new GroupgetJsonPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "getJsonArrayVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					getJsonArrayVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("getJsonArrayInstance", new GroupgetJsonArrayPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "getRequestHeadersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					getRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("getRequestHeadersInstance", new GroupgetRequestHeadersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientInstance", new GrouphttpClientPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientChunkedRequestVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientChunkedRequestVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientChunkedRequestInstance", new GrouphttpClientChunkedRequestPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientContinueHandlingVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientContinueHandlingVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientContinueHandlingInstance", new GrouphttpClientContinueHandlingPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientEndRequestVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientEndRequestVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientEndRequestInstance", new GrouphttpClientEndRequestPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientEndRequestBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientEndRequestBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientEndRequestBufferInstance", new GrouphttpClientEndRequestBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientHandleExceptionVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientHandleExceptionVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientHandleExceptionInstance", new GrouphttpClientHandleExceptionPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientHandleExceptionResponseVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientHandleExceptionResponseVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientHandleExceptionResponseInstance", new GrouphttpClientHandleExceptionResponsePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientOptionsVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientOptionsVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientOptionsInstance", new GrouphttpClientOptionsPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientPumpFileVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientPumpFileVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientPumpFileInstance", new GrouphttpClientPumpFilePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientPutRequestHeadersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientPutRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientPutRequestHeadersInstance", new GrouphttpClientPutRequestHeadersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientRequestTimeoutVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientRequestTimeoutVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientRequestTimeoutInstance", new GrouphttpClientRequestTimeoutPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientResponseBodyChunkVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientResponseBodyChunkVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientResponseBodyChunkInstance", new GrouphttpClientResponseBodyChunkPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientResponseBodyHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientResponseBodyHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientResponseBodyHandlerInstance", new GrouphttpClientResponseBodyHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientResponseHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientResponseHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientResponseHandlerInstance", new GrouphttpClientResponseHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientResponseHeadersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientResponseHeadersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientResponseHeadersInstance", new GrouphttpClientResponseHeadersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientResponseInMemoryVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientResponseInMemoryVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientResponseInMemoryInstance", new GrouphttpClientResponseInMemoryPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientSetRequestHeadersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientSetRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientSetRequestHeadersInstance", new GrouphttpClientSetRequestHeadersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpClientWriteToRequestVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpClientWriteToRequestVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpClientWriteToRequestInstance", new GrouphttpClientWriteToRequestPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponseEndVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponseEndVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponseEndInstance", new GrouphttpResponseEndPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponsePutHeaderVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponsePutHeaderVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponsePutHeaderInstance", new GrouphttpResponsePutHeaderPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponsePutTrailersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponsePutTrailersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponsePutTrailersInstance", new GrouphttpResponsePutTrailersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponseSTartVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponseSTartVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponseSTartInstance", new GrouphttpResponseSTartPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponseSetHeaderVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponseSetHeaderVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponseSetHeaderInstance", new GrouphttpResponseSetHeaderPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponseSetTrailersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponseSetTrailersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponseSetTrailersInstance", new GrouphttpResponseSetTrailersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpResponseWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpResponseWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpResponseWriteInstance", new GrouphttpResponseWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpServeFileVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpServeFileVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpServeFileInstance", new GrouphttpServeFilePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpServerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpServerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpServerInstance", new GrouphttpServerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpServerIncomingVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpServerIncomingVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpServerIncomingInstance", new GrouphttpServerIncomingPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpServerListenHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpServerListenHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpServerListenHandlerInstance", new GrouphttpServerListenHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "httpServerPartialFileVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					httpServerPartialFileVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("httpServerPartialFileInstance", new GrouphttpServerPartialFilePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "inMemoryBodyAggrVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					inMemoryBodyAggrVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("inMemoryBodyAggrInstance", new GroupinMemoryBodyAggrPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "inMemoryBodyAggrShortVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					inMemoryBodyAggrShortVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("inMemoryBodyAggrShortInstance", new GroupinMemoryBodyAggrShortPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "isolateVerticleDeploymentVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					isolateVerticleDeploymentVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("isolateVerticleDeploymentInstance", new GroupisolateVerticleDeploymentPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "jsonVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					jsonVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("jsonInstance", new GroupjsonPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "jsonFromStringVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					jsonFromStringVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("jsonFromStringInstance", new GroupjsonFromStringPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "jsonGetIntegerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					jsonGetIntegerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("jsonGetIntegerInstance", new GroupjsonGetIntegerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "jsonGetStringVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					jsonGetStringVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("jsonGetStringInstance", new GroupjsonGetStringPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "leaveMulticastGroupVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					leaveMulticastGroupVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("leaveMulticastGroupInstance", new GroupleaveMulticastGroupPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "localSharedMapVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					localSharedMapVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("localSharedMapInstance", new GrouplocalSharedMapPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "messageCodecVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					messageCodecVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("messageCodecInstance", new GroupmessageCodecPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "messageHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					messageHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("messageHandlerInstance", new GroupmessageHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "messageHeadersVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					messageHeadersVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("messageHeadersInstance", new GroupmessageHeadersPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "multipleServersCommandLineVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					multipleServersCommandLineVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("multipleServersCommandLineInstance", new GroupmultipleServersCommandLinePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "multipleServersProgrammaticallyVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					multipleServersProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("multipleServersProgrammaticallyInstance", new GroupmultipleServersProgrammaticallyPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "multpileServersVerticleVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					multpileServersVerticleVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("multpileServersVerticleInstance", new GroupmultpileServersVerticlePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "mvnVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					mvnVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("mvnInstance", new GroupmvnPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "mvnAuthShiroVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					mvnAuthShiroVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("mvnAuthShiroInstance", new GroupmvnAuthShiroPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "mvnDropwizardMetricsVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					mvnDropwizardMetricsVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("mvnDropwizardMetricsInstance", new GroupmvnDropwizardMetricsPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "mvnJunitVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					mvnJunitVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("mvnJunitInstance", new GroupmvnJunitPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newAsynchVerticleVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newAsynchVerticleVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newAsynchVerticleInstance", new GroupnewAsynchVerticlePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newBufferInstance", new GroupnewBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newBufferByteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newBufferByteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newBufferByteInstance", new GroupnewBufferBytePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newBufferSizeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newBufferSizeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newBufferSizeInstance", new GroupnewBufferSizePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newBufferStringVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newBufferStringVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newBufferStringInstance", new GroupnewBufferStringPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newBufferStringEncodedVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newBufferStringEncodedVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newBufferStringEncodedInstance", new GroupnewBufferStringEncodedPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newDatagramSocketVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newDatagramSocketVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newDatagramSocketInstance", new GroupnewDatagramSocketPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newEventBusVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newEventBusVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newEventBusInstance", new GroupnewEventBusPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newJsonArrayVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newJsonArrayVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newJsonArrayInstance", new GroupnewJsonArrayPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newTCPClientVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newTCPClientVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newTCPClientInstance", new GroupnewTCPClientPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "newTcpServerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					newTcpServerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("newTcpServerInstance", new GroupnewTcpServerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "oneShotTimerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					oneShotTimerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("oneShotTimerInstance", new GrouponeShotTimerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "periodicTimerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					periodicTimerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("periodicTimerInstance", new GroupperiodicTimerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "postWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					postWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("postWriteInstance", new GrouppostWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "publishMessageVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					publishMessageVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("publishMessageInstance", new GrouppublishMessagePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "pumpResponseVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					pumpResponseVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("pumpResponseInstance", new GrouppumpResponsePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "pumpStreamsVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					pumpStreamsVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("pumpStreamsInstance", new GrouppumpStreamsPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "putDataInMapVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					putDataInMapVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("putDataInMapInstance", new GroupputDataInMapPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "putJsonVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					putJsonVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("putJsonInstance", new GroupputJsonPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "randomAccessBufferWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					randomAccessBufferWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("randomAccessBufferWriteInstance", new GrouprandomAccessBufferWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "randomAccessReadVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					randomAccessReadVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("randomAccessReadInstance", new GrouprandomAccessReadPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "randomAccessWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					randomAccessWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("randomAccessWriteInstance", new GrouprandomAccessWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "readBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					readBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("readBufferInstance", new GroupreadBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "readFileAsynchVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					readFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("readFileAsynchInstance", new GroupreadFileAsynchPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "readSocketDataVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					readSocketDataVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("readSocketDataInstance", new GroupreadSocketDataPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "readUnsignedNumberVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					readUnsignedNumberVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("readUnsignedNumberInstance", new GroupreadUnsignedNumberPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "receiveDatagramPacketVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					receiveDatagramPacketVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("receiveDatagramPacketInstance", new GroupreceiveDatagramPacketPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "receiveMulticastVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					receiveMulticastVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("receiveMulticastInstance", new GroupreceiveMulticastPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "recordParserVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					recordParserVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("recordParserInstance", new GrouprecordParserPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "recordParserFixedVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					recordParserFixedVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("recordParserFixedInstance", new GrouprecordParserFixedPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "registerHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					registerHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("registerHandlerInstance", new GroupregisterHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "replyMessageVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					replyMessageVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("replyMessageInstance", new GroupreplyMessagePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "replyReceivedMessageVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					replyReceivedMessageVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("replyReceivedMessageInstance", new GroupreplyReceivedMessagePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "requestHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					requestHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("requestHandlerInstance", new GrouprequestHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "retriveContextVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					retriveContextVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("retriveContextInstance", new GroupretriveContextPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "revokateAuthVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					revokateAuthVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("revokateAuthInstance", new GrouprevokateAuthPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "revokateAuthBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					revokateAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("revokateAuthBufferInstance", new GrouprevokateAuthBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "runInContextVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					runInContextVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("runInContextInstance", new GrouprunInContextPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "sendFileVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					sendFileVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("sendFileInstance", new GroupsendFilePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "sendMessageVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					sendMessageVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("sendMessageInstance", new GroupsendMessagePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "sendMulticastVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					sendMulticastVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("sendMulticastInstance", new GroupsendMulticastPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverConnectionHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverConnectionHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverConnectionHandlerInstance", new GroupserverConnectionHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverListenHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverListenHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverListenHandlerInstance", new GroupserverListenHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLBufferConfigurationVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLBufferConfigurationVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLBufferConfigurationInstance", new GroupserverSSLBufferConfigurationPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLKeystoreVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLKeystoreVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLKeystoreInstance", new GroupserverSSLKeystorePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLKeystoreBuffVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLKeystoreBuffVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLKeystoreBuffInstance", new GroupserverSSLKeystoreBuffPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPEMVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPEMVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPEMInstance", new GroupserverSSLPEMPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPEMAuthorityVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPEMAuthorityVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPEMAuthorityInstance", new GroupserverSSLPEMAuthorityPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPEMAuthorityBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPEMAuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPEMAuthorityBufferInstance", new GroupserverSSLPEMAuthorityBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPEMBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPEMBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPEMBufferInstance", new GroupserverSSLPEMBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPKCS_12Verticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPKCS_12Verticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPKCS_12Instance", new GroupserverSSLPKCS_12Panel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPKCS_12AuthorityVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPKCS_12AuthorityVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPKCS_12AuthorityInstance", new GroupserverSSLPKCS_12AuthorityPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLPKCS_12AuthorityBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLPKCS_12AuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLPKCS_12AuthorityBufferInstance", new GroupserverSSLPKCS_12AuthorityBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLTrustAuthorityVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLTrustAuthorityVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLTrustAuthorityInstance", new GroupserverSSLTrustAuthorityPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "serverSSLTrustAuthorityBufferVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					serverSSLTrustAuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("serverSSLTrustAuthorityBufferInstance", new GroupserverSSLTrustAuthorityBufferPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "simpleWriteRequestVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					simpleWriteRequestVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("simpleWriteRequestInstance", new GroupsimpleWriteRequestPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "socketClosedHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					socketClosedHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("socketClosedHandlerInstance", new GroupsocketClosedHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "undeployVerticlesVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					undeployVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("undeployVerticlesInstance", new GroupundeployVerticlesPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "verticleVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					verticleVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("verticleInstance", new GroupverticlePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "verticleConfigurationVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					verticleConfigurationVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("verticleConfigurationInstance", new GroupverticleConfigurationPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "verticleInstancesVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					verticleInstancesVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("verticleInstancesInstance", new GroupverticleInstancesPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "vertxVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					vertxVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("vertxInstance", new GroupvertxPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "vertxOptionsVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					vertxOptionsVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("vertxOptionsInstance", new GroupvertxOptionsPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketFrameWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketFrameWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketFrameWriteInstance", new GroupwebsocketFrameWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketHandlerVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketHandlerVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketHandlerInstance", new GroupwebsocketHandlerPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketReadFrameVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketReadFrameVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketReadFrameInstance", new GroupwebsocketReadFramePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketSingleFrameWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketSingleFrameWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketSingleFrameWriteInstance", new GroupwebsocketSingleFrameWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketUpgradeVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketUpgradeVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketUpgradeInstance", new GroupwebsocketUpgradePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "websocketWriteVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					websocketWriteVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("websocketWriteInstance", new GroupwebsocketWritePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "workerVerticleVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					workerVerticleVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("workerVerticleInstance", new GroupworkerVerticlePanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "writeFileAsynchVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					writeFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("writeFileAsynchInstance", new GroupwriteFileAsynchPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
		 add(deployVerticleAction(vertx, txtRoot, "com.generator.generators.vertxCore.vertx", "writeSocketDataVerticle", new VertxUtil.SuccessHandler<String>() {
			@Override
			public void onSuccess(String result) {
				SwingUtilities.invokeLater(() -> {
					final UUID instanceID = UUID.randomUUID();
					writeSocketDataVerticle.sendInstanceMessage(vertx, instanceID, s ->
						SwingUtilities.invokeLater(() -> {
							declarationsPanel.add("writeSocketDataInstance", new GroupwriteSocketDataPanel(vertx));
						}));
				});
			}

			@Override
			public void onFail(Throwable t) {

			}
		}));  
	}

	private static JButton deployVerticleAction(final Vertx vertx, final JTextField txtRoot, final String packageName, final String name, final VertxUtil.SuccessHandler<String> handler) {
		return new JButton(new AbstractAction("new " + name) {
			@Override
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(() -> {
					final File file = new File(txtRoot.getText(), GeneratedFile.packageToPath(packageName, name + ".java"));
					log.info("deploying from file " + file.getAbsolutePath() + "");
					try {
						VertxUtil.deploy(vertx, (Verticle) CompileUtil.compileAndLoad(packageName + "." + name, FileUtil.readIntact(file)), log, handler);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				});
			}
		});
	}

	 private static final class GroupappendBufferPanel extends JPanel {

			public GroupappendBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						appendBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupappendBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						appendBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupasynchFilePanel extends JPanel {

			public GroupasynchFilePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						asynchFileVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupasynchFileInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						asynchFileVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupasynchVerticleStopPanel extends JPanel {

			public GroupasynchVerticleStopPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						asynchVerticleStopVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupasynchVerticleStopInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						asynchVerticleStopVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupblockMulticastPanel extends JPanel {

			public GroupblockMulticastPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						blockMulticastVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupblockMulticastInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						blockMulticastVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupblockingCodePanel extends JPanel {

			public GroupblockingCodePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						blockingCodeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupblockingCodeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel resultEditor = new JPanel(new GridLayout(1,3));

				resultEditor.add(new JLabel("result "));
				final JTextField txtresult = new JTextField(10);
				resultEditor.add(txtresult);
				resultEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						blockingCodeVerticle.sendResultMessage(vertx, instanceID, txtresult.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(resultEditor); 
				 final JPanel resultHandlerEditor = new JPanel(new GridLayout(1,3));

				resultHandlerEditor.add(new JLabel("resultHandler "));
				final JTextField txtresultHandler = new JTextField(10);
				resultHandlerEditor.add(txtresultHandler);
				resultHandlerEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						blockingCodeVerticle.sendResultHandlerMessage(vertx, instanceID, txtresultHandler.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(resultHandlerEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						blockingCodeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupbodyHandlerPanel extends JPanel {

			public GroupbodyHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						bodyHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupbodyHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						bodyHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupbufCopyPanel extends JPanel {

			public GroupbufCopyPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						bufCopyVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupbufCopyInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						bufCopyVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupbufLengthPanel extends JPanel {

			public GroupbufLengthPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						bufLengthVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupbufLengthInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						bufLengthVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupbufSlicePanel extends JPanel {

			public GroupbufSlicePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						bufSliceVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupbufSliceInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						bufSliceVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupbugfixPanel extends JPanel {

			public GroupbugfixPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						bugfixVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupbugfixInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						bugfixVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcancelTimerPanel extends JPanel {

			public GroupcancelTimerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						cancelTimerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcancelTimerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						cancelTimerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcheckExistenceAndDeletePanel extends JPanel {

			public GroupcheckExistenceAndDeletePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						checkExistenceAndDeleteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcheckExistenceAndDeleteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						checkExistenceAndDeleteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupchunkFileUploadHandlerPanel extends JPanel {

			public GroupchunkFileUploadHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						chunkFileUploadHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupchunkFileUploadHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						chunkFileUploadHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientConnectPanel extends JPanel {

			public GroupclientConnectPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientConnectVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientConnectInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientConnectVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientRequestPanel extends JPanel {

			public GroupclientRequestPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientRequestVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientRequestInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel clientEditor = new JPanel(new GridLayout(1,3));

				clientEditor.add(new JLabel("client "));
				final JTextField txtclient = new JTextField(10);
				clientEditor.add(txtclient);
				clientEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendClientMessage(vertx, instanceID, txtclient.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clientEditor); 
				 final JPanel contentEditor = new JPanel(new GridLayout(1,3));

				contentEditor.add(new JLabel("content "));
				final JTextField txtcontent = new JTextField(10);
				contentEditor.add(txtcontent);
				contentEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendContentMessage(vertx, instanceID, txtcontent.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(contentEditor); 
				 final JPanel handleBodyEditor = new JPanel(new GridLayout(1,3));

				handleBodyEditor.add(new JLabel("handleBody "));
				final JTextField txthandleBody = new JTextField(10);
				handleBodyEditor.add(txthandleBody);
				handleBodyEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendHandleBodyMessage(vertx, instanceID, txthandleBody.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(handleBodyEditor); 
				 final JPanel handleResponseEditor = new JPanel(new GridLayout(1,3));

				handleResponseEditor.add(new JLabel("handleResponse "));
				final JTextField txthandleResponse = new JTextField(10);
				handleResponseEditor.add(txthandleResponse);
				handleResponseEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendHandleResponseMessage(vertx, instanceID, txthandleResponse.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(handleResponseEditor); 
				 final JPanel httpMethodEditor = new JPanel(new GridLayout(1,3));

				httpMethodEditor.add(new JLabel("httpMethod "));
				final JTextField txthttpMethod = new JTextField(10);
				httpMethodEditor.add(txthttpMethod);
				httpMethodEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendHttpMethodMessage(vertx, instanceID, txthttpMethod.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(httpMethodEditor); 
				 final JPanel uriEditor = new JPanel(new GridLayout(1,3));

				uriEditor.add(new JLabel("uri "));
				final JTextField txturi = new JTextField(10);
				uriEditor.add(txturi);
				uriEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						clientRequestVerticle.sendUriMessage(vertx, instanceID, txturi.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(uriEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientRequestVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPanel extends JPanel {

			public GroupclientSSLPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLKeystoreAuthPanel extends JPanel {

			public GroupclientSSLKeystoreAuthPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLKeystoreAuthVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLKeystoreAuthInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLKeystoreAuthVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLKeystoreAuthBufferPanel extends JPanel {

			public GroupclientSSLKeystoreAuthBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLKeystoreAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLKeystoreAuthBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLKeystoreAuthBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPEMPanel extends JPanel {

			public GroupclientSSLPEMPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPEMVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPEMInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPEMVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPEMAuthPanel extends JPanel {

			public GroupclientSSLPEMAuthPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPEMAuthVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPEMAuthInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPEMAuthVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPEMAuthBufferPanel extends JPanel {

			public GroupclientSSLPEMAuthBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPEMAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPEMAuthBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPEMAuthBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPEMBufferPanel extends JPanel {

			public GroupclientSSLPEMBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPEMBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPEMBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPEMBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPKCSAuthPanel extends JPanel {

			public GroupclientSSLPKCSAuthPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPKCSAuthVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPKCSAuthInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPKCSAuthVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPKCSAuthBufferPanel extends JPanel {

			public GroupclientSSLPKCSAuthBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPKCSAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPKCSAuthBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPKCSAuthBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPKCS_12Panel extends JPanel {

			public GroupclientSSLPKCS_12Panel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPKCS_12Verticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPKCS_12Instance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPKCS_12Verticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLPKCS_12BufferPanel extends JPanel {

			public GroupclientSSLPKCS_12BufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLPKCS_12BufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLPKCS_12BufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLPKCS_12BufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLTruststorePanel extends JPanel {

			public GroupclientSSLTruststorePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLTruststoreVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLTruststoreInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLTruststoreVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientSSLTruststoreBufferPanel extends JPanel {

			public GroupclientSSLTruststoreBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientSSLTruststoreBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientSSLTruststoreBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientSSLTruststoreBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclientWebsocketPanel extends JPanel {

			public GroupclientWebsocketPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clientWebsocketVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclientWebsocketInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clientWebsocketVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcloseServerPanel extends JPanel {

			public GroupcloseServerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						closeServerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcloseServerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						closeServerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterCommandLinePanel extends JPanel {

			public GroupclusterCommandLinePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterCommandLineVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterCommandLineInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterCommandLineVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterCounterPanel extends JPanel {

			public GroupclusterCounterPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterCounterVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterCounterInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterCounterVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterProgrammaticallyPanel extends JPanel {

			public GroupclusterProgrammaticallyPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterProgrammaticallyInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterProgrammaticallyVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterSharedMapPanel extends JPanel {

			public GroupclusterSharedMapPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterSharedMapVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterSharedMapInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterSharedMapVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterWideLockPanel extends JPanel {

			public GroupclusterWideLockPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterWideLockVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterWideLockInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterWideLockVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupclusterWideLockTimeoutPanel extends JPanel {

			public GroupclusterWideLockTimeoutPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						clusterWideLockTimeoutVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupclusterWideLockTimeoutInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						clusterWideLockTimeoutVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcmdHighAvailabilityPanel extends JPanel {

			public GroupcmdHighAvailabilityPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						cmdHighAvailabilityVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcmdHighAvailabilityInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						cmdHighAvailabilityVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcmdRunVerticlesPanel extends JPanel {

			public GroupcmdRunVerticlesPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						cmdRunVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcmdRunVerticlesInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						cmdRunVerticlesVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupconfigGetIntegerPanel extends JPanel {

			public GroupconfigGetIntegerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						configGetIntegerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupconfigGetIntegerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						configGetIntegerVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						configGetIntegerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupconfigGetStringPanel extends JPanel {

			public GroupconfigGetStringPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						configGetStringVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupconfigGetStringInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						configGetStringVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						configGetStringVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupconfigureCipherSuitePanel extends JPanel {

			public GroupconfigureCipherSuitePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						configureCipherSuiteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupconfigureCipherSuiteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						configureCipherSuiteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupconsumerCompletionHandlerPanel extends JPanel {

			public GroupconsumerCompletionHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						consumerCompletionHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupconsumerCompletionHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						consumerCompletionHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcontextSharedDataPanel extends JPanel {

			public GroupcontextSharedDataPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						contextSharedDataVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcontextSharedDataInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						contextSharedDataVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcontextTypePanel extends JPanel {

			public GroupcontextTypePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						contextTypeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcontextTypeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						contextTypeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcopyFileAsynchPanel extends JPanel {

			public GroupcopyFileAsynchPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						copyFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcopyFileAsynchInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						copyFileAsynchVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupcopyFileSynchPanel extends JPanel {

			public GroupcopyFileSynchPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						copyFileSynchVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupcopyFileSynchInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						copyFileSynchVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdeployPolyVerticlesPanel extends JPanel {

			public GroupdeployPolyVerticlesPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						deployPolyVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdeployPolyVerticlesInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						deployPolyVerticlesVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdeployVerticleProgrammaticallyPanel extends JPanel {

			public GroupdeployVerticleProgrammaticallyPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						deployVerticleProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdeployVerticleProgrammaticallyInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel onFailEditor = new JPanel(new GridLayout(1,3));

				onFailEditor.add(new JLabel("onFail "));
				final JTextField txtonFail = new JTextField(10);
				onFailEditor.add(txtonFail);
				onFailEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleProgrammaticallyVerticle.sendOnFailMessage(vertx, instanceID, txtonFail.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(onFailEditor); 
				 final JPanel onSuccessEditor = new JPanel(new GridLayout(1,3));

				onSuccessEditor.add(new JLabel("onSuccess "));
				final JTextField txtonSuccess = new JTextField(10);
				onSuccessEditor.add(txtonSuccess);
				onSuccessEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleProgrammaticallyVerticle.sendOnSuccessMessage(vertx, instanceID, txtonSuccess.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(onSuccessEditor); 
				 final JPanel optionsEditor = new JPanel(new GridLayout(1,3));

				optionsEditor.add(new JLabel("options "));
				final JTextField txtoptions = new JTextField(10);
				optionsEditor.add(txtoptions);
				optionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleProgrammaticallyVerticle.sendOptionsMessage(vertx, instanceID, txtoptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(optionsEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleProgrammaticallyVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 
				 final JPanel typeEditor = new JPanel(new GridLayout(1,3));

				typeEditor.add(new JLabel("type "));
				final JTextField txttype = new JTextField(10);
				typeEditor.add(txttype);
				typeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleProgrammaticallyVerticle.sendTypeMessage(vertx, instanceID, txttype.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(typeEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						deployVerticleProgrammaticallyVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdeployVerticleStartPanel extends JPanel {

			public GroupdeployVerticleStartPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						deployVerticleStartVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdeployVerticleStartInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel configEditor = new JPanel(new GridLayout(1,3));

				configEditor.add(new JLabel("config "));
				final JTextField txtconfig = new JTextField(10);
				configEditor.add(txtconfig);
				configEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleStartVerticle.sendConfigMessage(vertx, instanceID, txtconfig.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(configEditor); 
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleStartVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel onSuccessEditor = new JPanel(new GridLayout(1,3));

				onSuccessEditor.add(new JLabel("onSuccess "));
				final JTextField txtonSuccess = new JTextField(10);
				onSuccessEditor.add(txtonSuccess);
				onSuccessEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						deployVerticleStartVerticle.sendOnSuccessMessage(vertx, instanceID, txtonSuccess.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(onSuccessEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						deployVerticleStartVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsClientPanel extends JPanel {

			public GroupdnsClientPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsClientVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsClientInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsClientVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsLookupPanel extends JPanel {

			public GroupdnsLookupPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsLookupVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsLookupInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsLookupVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsLookup4Panel extends JPanel {

			public GroupdnsLookup4Panel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsLookup4Verticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsLookup4Instance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsLookup4Verticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsLookup6Panel extends JPanel {

			public GroupdnsLookup6Panel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsLookup6Verticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsLookup6Instance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsLookup6Verticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveAPanel extends JPanel {

			public GroupdnsResolveAPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveAVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveAInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveAVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveAAAAPanel extends JPanel {

			public GroupdnsResolveAAAAPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveAAAAVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveAAAAInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveAAAAVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveCNAMEPanel extends JPanel {

			public GroupdnsResolveCNAMEPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveCNAMEVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveCNAMEInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveCNAMEVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveMXPanel extends JPanel {

			public GroupdnsResolveMXPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveMXVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveMXInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveMXVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveNSPanel extends JPanel {

			public GroupdnsResolveNSPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveNSVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveNSInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveNSVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolvePTRPanel extends JPanel {

			public GroupdnsResolvePTRPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolvePTRVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolvePTRInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolvePTRVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveSRVPanel extends JPanel {

			public GroupdnsResolveSRVPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveSRVVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveSRVInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveSRVVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResolveTXTPanel extends JPanel {

			public GroupdnsResolveTXTPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResolveTXTVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResolveTXTInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResolveTXTVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsResponseCodePanel extends JPanel {

			public GroupdnsResponseCodePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsResponseCodeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsResponseCodeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsResponseCodeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupdnsReverseLookupPanel extends JPanel {

			public GroupdnsReverseLookupPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						dnsReverseLookupVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupdnsReverseLookupInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						dnsReverseLookupVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupebConsumePanel extends JPanel {

			public GroupebConsumePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						ebConsumeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupebConsumeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel addressEditor = new JPanel(new GridLayout(1,3));

				addressEditor.add(new JLabel("address "));
				final JTextField txtaddress = new JTextField(10);
				addressEditor.add(txtaddress);
				addressEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						ebConsumeVerticle.sendAddressMessage(vertx, instanceID, txtaddress.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(addressEditor); 
				 final JPanel onMessageEditor = new JPanel(new GridLayout(1,3));

				onMessageEditor.add(new JLabel("onMessage "));
				final JTextField txtonMessage = new JTextField(10);
				onMessageEditor.add(txtonMessage);
				onMessageEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						ebConsumeVerticle.sendOnMessageMessage(vertx, instanceID, txtonMessage.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(onMessageEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						ebConsumeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupebPublishPanel extends JPanel {

			public GroupebPublishPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						ebPublishVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupebPublishInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel addressEditor = new JPanel(new GridLayout(1,3));

				addressEditor.add(new JLabel("address "));
				final JTextField txtaddress = new JTextField(10);
				addressEditor.add(txtaddress);
				addressEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						ebPublishVerticle.sendAddressMessage(vertx, instanceID, txtaddress.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(addressEditor); 
				 final JPanel valueEditor = new JPanel(new GridLayout(1,3));

				valueEditor.add(new JLabel("value "));
				final JTextField txtvalue = new JTextField(10);
				valueEditor.add(txtvalue);
				valueEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						ebPublishVerticle.sendValueMessage(vertx, instanceID, txtvalue.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(valueEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						ebPublishVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupencodeArrayPanel extends JPanel {

			public GroupencodeArrayPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						encodeArrayVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupencodeArrayInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						encodeArrayVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupfileStreamPanel extends JPanel {

			public GroupfileStreamPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						fileStreamVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupfileStreamInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						fileStreamVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupformFileStreamUploadPanel extends JPanel {

			public GroupformFileStreamUploadPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						formFileStreamUploadVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupformFileStreamUploadInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						formFileStreamUploadVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupformFileUploadHandlerPanel extends JPanel {

			public GroupformFileUploadHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						formFileUploadHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupformFileUploadHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						formFileUploadHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupformHandlerPanel extends JPanel {

			public GroupformHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						formHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupformHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						formHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupgetDataFromMapPanel extends JPanel {

			public GroupgetDataFromMapPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						getDataFromMapVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupgetDataFromMapInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						getDataFromMapVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupgetJsonPanel extends JPanel {

			public GroupgetJsonPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						getJsonVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupgetJsonInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						getJsonVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						getJsonVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 
				 final JPanel typeEditor = new JPanel(new GridLayout(1,3));

				typeEditor.add(new JLabel("type "));
				final JTextField txttype = new JTextField(10);
				typeEditor.add(txttype);
				typeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						getJsonVerticle.sendTypeMessage(vertx, instanceID, txttype.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(typeEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						getJsonVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupgetJsonArrayPanel extends JPanel {

			public GroupgetJsonArrayPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						getJsonArrayVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupgetJsonArrayInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						getJsonArrayVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupgetRequestHeadersPanel extends JPanel {

			public GroupgetRequestHeadersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						getRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupgetRequestHeadersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						getRequestHeadersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientPanel extends JPanel {

			public GrouphttpClientPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel clientOptionsEditor = new JPanel(new GridLayout(1,3));

				clientOptionsEditor.add(new JLabel("clientOptions "));
				final JTextField txtclientOptions = new JTextField(10);
				clientOptionsEditor.add(txtclientOptions);
				clientOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientVerticle.sendClientOptionsMessage(vertx, instanceID, txtclientOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clientOptionsEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientChunkedRequestPanel extends JPanel {

			public GrouphttpClientChunkedRequestPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientChunkedRequestVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientChunkedRequestInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientChunkedRequestVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientContinueHandlingPanel extends JPanel {

			public GrouphttpClientContinueHandlingPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientContinueHandlingVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientContinueHandlingInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientContinueHandlingVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientEndRequestPanel extends JPanel {

			public GrouphttpClientEndRequestPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientEndRequestVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientEndRequestInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientEndRequestVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientEndRequestBufferPanel extends JPanel {

			public GrouphttpClientEndRequestBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientEndRequestBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientEndRequestBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientEndRequestBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientHandleExceptionPanel extends JPanel {

			public GrouphttpClientHandleExceptionPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientHandleExceptionVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientHandleExceptionInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientHandleExceptionVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientHandleExceptionResponsePanel extends JPanel {

			public GrouphttpClientHandleExceptionResponsePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientHandleExceptionResponseVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientHandleExceptionResponseInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientHandleExceptionResponseVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientOptionsPanel extends JPanel {

			public GrouphttpClientOptionsPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientOptionsVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientOptionsInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel connectTimeoutEditor = new JPanel(new GridLayout(1,3));

				connectTimeoutEditor.add(new JLabel("connectTimeout "));
				final JTextField txtconnectTimeout = new JTextField(10);
				connectTimeoutEditor.add(txtconnectTimeout);
				connectTimeoutEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendConnectTimeoutMessage(vertx, instanceID, txtconnectTimeout.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(connectTimeoutEditor); 
				 final JPanel defaultHostEditor = new JPanel(new GridLayout(1,3));

				defaultHostEditor.add(new JLabel("defaultHost "));
				final JTextField txtdefaultHost = new JTextField(10);
				defaultHostEditor.add(txtdefaultHost);
				defaultHostEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendDefaultHostMessage(vertx, instanceID, txtdefaultHost.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(defaultHostEditor); 
				 final JPanel defaultPortEditor = new JPanel(new GridLayout(1,3));

				defaultPortEditor.add(new JLabel("defaultPort "));
				final JTextField txtdefaultPort = new JTextField(10);
				defaultPortEditor.add(txtdefaultPort);
				defaultPortEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendDefaultPortMessage(vertx, instanceID, txtdefaultPort.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(defaultPortEditor); 
				 final JPanel idleTimeoutEditor = new JPanel(new GridLayout(1,3));

				idleTimeoutEditor.add(new JLabel("idleTimeout "));
				final JTextField txtidleTimeout = new JTextField(10);
				idleTimeoutEditor.add(txtidleTimeout);
				idleTimeoutEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendIdleTimeoutMessage(vertx, instanceID, txtidleTimeout.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(idleTimeoutEditor); 
				 final JPanel keepAliveEditor = new JPanel(new GridLayout(1,3));

				keepAliveEditor.add(new JLabel("keepAlive "));
				final JTextField txtkeepAlive = new JTextField(10);
				keepAliveEditor.add(txtkeepAlive);
				keepAliveEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendKeepAliveMessage(vertx, instanceID, txtkeepAlive.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(keepAliveEditor); 
				 final JPanel keyStoreOptionsEditor = new JPanel(new GridLayout(1,3));

				keyStoreOptionsEditor.add(new JLabel("keyStoreOptions "));
				final JTextField txtkeyStoreOptions = new JTextField(10);
				keyStoreOptionsEditor.add(txtkeyStoreOptions);
				keyStoreOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendKeyStoreOptionsMessage(vertx, instanceID, txtkeyStoreOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(keyStoreOptionsEditor); 
				 final JPanel maxPoolSizeEditor = new JPanel(new GridLayout(1,3));

				maxPoolSizeEditor.add(new JLabel("maxPoolSize "));
				final JTextField txtmaxPoolSize = new JTextField(10);
				maxPoolSizeEditor.add(txtmaxPoolSize);
				maxPoolSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendMaxPoolSizeMessage(vertx, instanceID, txtmaxPoolSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(maxPoolSizeEditor); 
				 final JPanel maxWebsocketFrameSizeEditor = new JPanel(new GridLayout(1,3));

				maxWebsocketFrameSizeEditor.add(new JLabel("maxWebsocketFrameSize "));
				final JTextField txtmaxWebsocketFrameSize = new JTextField(10);
				maxWebsocketFrameSizeEditor.add(txtmaxWebsocketFrameSize);
				maxWebsocketFrameSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendMaxWebsocketFrameSizeMessage(vertx, instanceID, txtmaxWebsocketFrameSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(maxWebsocketFrameSizeEditor); 
				 final JPanel pemKeyCertOptionsEditor = new JPanel(new GridLayout(1,3));

				pemKeyCertOptionsEditor.add(new JLabel("pemKeyCertOptions "));
				final JTextField txtpemKeyCertOptions = new JTextField(10);
				pemKeyCertOptionsEditor.add(txtpemKeyCertOptions);
				pemKeyCertOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendPemKeyCertOptionsMessage(vertx, instanceID, txtpemKeyCertOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(pemKeyCertOptionsEditor); 
				 final JPanel pemTrustOptionsEditor = new JPanel(new GridLayout(1,3));

				pemTrustOptionsEditor.add(new JLabel("pemTrustOptions "));
				final JTextField txtpemTrustOptions = new JTextField(10);
				pemTrustOptionsEditor.add(txtpemTrustOptions);
				pemTrustOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendPemTrustOptionsMessage(vertx, instanceID, txtpemTrustOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(pemTrustOptionsEditor); 
				 final JPanel pfxKeycertOptionsEditor = new JPanel(new GridLayout(1,3));

				pfxKeycertOptionsEditor.add(new JLabel("pfxKeycertOptions "));
				final JTextField txtpfxKeycertOptions = new JTextField(10);
				pfxKeycertOptionsEditor.add(txtpfxKeycertOptions);
				pfxKeycertOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendPfxKeycertOptionsMessage(vertx, instanceID, txtpfxKeycertOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(pfxKeycertOptionsEditor); 
				 final JPanel pfxTrustOptionsEditor = new JPanel(new GridLayout(1,3));

				pfxTrustOptionsEditor.add(new JLabel("pfxTrustOptions "));
				final JTextField txtpfxTrustOptions = new JTextField(10);
				pfxTrustOptionsEditor.add(txtpfxTrustOptions);
				pfxTrustOptionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendPfxTrustOptionsMessage(vertx, instanceID, txtpfxTrustOptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(pfxTrustOptionsEditor); 
				 final JPanel pipeliningEditor = new JPanel(new GridLayout(1,3));

				pipeliningEditor.add(new JLabel("pipelining "));
				final JTextField txtpipelining = new JTextField(10);
				pipeliningEditor.add(txtpipelining);
				pipeliningEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendPipeliningMessage(vertx, instanceID, txtpipelining.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(pipeliningEditor); 
				 final JPanel protocolVersionEditor = new JPanel(new GridLayout(1,3));

				protocolVersionEditor.add(new JLabel("protocolVersion "));
				final JTextField txtprotocolVersion = new JTextField(10);
				protocolVersionEditor.add(txtprotocolVersion);
				protocolVersionEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendProtocolVersionMessage(vertx, instanceID, txtprotocolVersion.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(protocolVersionEditor); 
				 final JPanel receiveBufferSizeEditor = new JPanel(new GridLayout(1,3));

				receiveBufferSizeEditor.add(new JLabel("receiveBufferSize "));
				final JTextField txtreceiveBufferSize = new JTextField(10);
				receiveBufferSizeEditor.add(txtreceiveBufferSize);
				receiveBufferSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendReceiveBufferSizeMessage(vertx, instanceID, txtreceiveBufferSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(receiveBufferSizeEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 
				 final JPanel reuseAddressEditor = new JPanel(new GridLayout(1,3));

				reuseAddressEditor.add(new JLabel("reuseAddress "));
				final JTextField txtreuseAddress = new JTextField(10);
				reuseAddressEditor.add(txtreuseAddress);
				reuseAddressEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendReuseAddressMessage(vertx, instanceID, txtreuseAddress.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(reuseAddressEditor); 
				 final JPanel sendBufferSizeEditor = new JPanel(new GridLayout(1,3));

				sendBufferSizeEditor.add(new JLabel("sendBufferSize "));
				final JTextField txtsendBufferSize = new JTextField(10);
				sendBufferSizeEditor.add(txtsendBufferSize);
				sendBufferSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendSendBufferSizeMessage(vertx, instanceID, txtsendBufferSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(sendBufferSizeEditor); 
				 final JPanel soLingerEditor = new JPanel(new GridLayout(1,3));

				soLingerEditor.add(new JLabel("soLinger "));
				final JTextField txtsoLinger = new JTextField(10);
				soLingerEditor.add(txtsoLinger);
				soLingerEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendSoLingerMessage(vertx, instanceID, txtsoLinger.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(soLingerEditor); 
				 final JPanel sslEditor = new JPanel(new GridLayout(1,3));

				sslEditor.add(new JLabel("ssl "));
				final JTextField txtssl = new JTextField(10);
				sslEditor.add(txtssl);
				sslEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendSslMessage(vertx, instanceID, txtssl.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(sslEditor); 
				 final JPanel tcpKeepAliveEditor = new JPanel(new GridLayout(1,3));

				tcpKeepAliveEditor.add(new JLabel("tcpKeepAlive "));
				final JTextField txttcpKeepAlive = new JTextField(10);
				tcpKeepAliveEditor.add(txttcpKeepAlive);
				tcpKeepAliveEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTcpKeepAliveMessage(vertx, instanceID, txttcpKeepAlive.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(tcpKeepAliveEditor); 
				 final JPanel tcpNoDelayEditor = new JPanel(new GridLayout(1,3));

				tcpNoDelayEditor.add(new JLabel("tcpNoDelay "));
				final JTextField txttcpNoDelay = new JTextField(10);
				tcpNoDelayEditor.add(txttcpNoDelay);
				tcpNoDelayEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTcpNoDelayMessage(vertx, instanceID, txttcpNoDelay.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(tcpNoDelayEditor); 
				 final JPanel trafficClassEditor = new JPanel(new GridLayout(1,3));

				trafficClassEditor.add(new JLabel("trafficClass "));
				final JTextField txttrafficClass = new JTextField(10);
				trafficClassEditor.add(txttrafficClass);
				trafficClassEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTrafficClassMessage(vertx, instanceID, txttrafficClass.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(trafficClassEditor); 
				 final JPanel trustAllEditor = new JPanel(new GridLayout(1,3));

				trustAllEditor.add(new JLabel("trustAll "));
				final JTextField txttrustAll = new JTextField(10);
				trustAllEditor.add(txttrustAll);
				trustAllEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTrustAllMessage(vertx, instanceID, txttrustAll.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(trustAllEditor); 
				 final JPanel trustStoreEditor = new JPanel(new GridLayout(1,3));

				trustStoreEditor.add(new JLabel("trustStore "));
				final JTextField txttrustStore = new JTextField(10);
				trustStoreEditor.add(txttrustStore);
				trustStoreEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTrustStoreMessage(vertx, instanceID, txttrustStore.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(trustStoreEditor); 
				 final JPanel tryUseCompressionEditor = new JPanel(new GridLayout(1,3));

				tryUseCompressionEditor.add(new JLabel("tryUseCompression "));
				final JTextField txttryUseCompression = new JTextField(10);
				tryUseCompressionEditor.add(txttryUseCompression);
				tryUseCompressionEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendTryUseCompressionMessage(vertx, instanceID, txttryUseCompression.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(tryUseCompressionEditor); 
				 final JPanel usePooledBuffersEditor = new JPanel(new GridLayout(1,3));

				usePooledBuffersEditor.add(new JLabel("usePooledBuffers "));
				final JTextField txtusePooledBuffers = new JTextField(10);
				usePooledBuffersEditor.add(txtusePooledBuffers);
				usePooledBuffersEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendUsePooledBuffersMessage(vertx, instanceID, txtusePooledBuffers.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(usePooledBuffersEditor); 
				 final JPanel verifyHostEditor = new JPanel(new GridLayout(1,3));

				verifyHostEditor.add(new JLabel("verifyHost "));
				final JTextField txtverifyHost = new JTextField(10);
				verifyHostEditor.add(txtverifyHost);
				verifyHostEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						httpClientOptionsVerticle.sendVerifyHostMessage(vertx, instanceID, txtverifyHost.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(verifyHostEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientOptionsVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientPumpFilePanel extends JPanel {

			public GrouphttpClientPumpFilePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientPumpFileVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientPumpFileInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientPumpFileVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientPutRequestHeadersPanel extends JPanel {

			public GrouphttpClientPutRequestHeadersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientPutRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientPutRequestHeadersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientPutRequestHeadersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientRequestTimeoutPanel extends JPanel {

			public GrouphttpClientRequestTimeoutPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientRequestTimeoutVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientRequestTimeoutInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientRequestTimeoutVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientResponseBodyChunkPanel extends JPanel {

			public GrouphttpClientResponseBodyChunkPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientResponseBodyChunkVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientResponseBodyChunkInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientResponseBodyChunkVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientResponseBodyHandlerPanel extends JPanel {

			public GrouphttpClientResponseBodyHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientResponseBodyHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientResponseBodyHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientResponseBodyHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientResponseHandlerPanel extends JPanel {

			public GrouphttpClientResponseHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientResponseHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientResponseHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientResponseHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientResponseHeadersPanel extends JPanel {

			public GrouphttpClientResponseHeadersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientResponseHeadersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientResponseHeadersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientResponseHeadersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientResponseInMemoryPanel extends JPanel {

			public GrouphttpClientResponseInMemoryPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientResponseInMemoryVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientResponseInMemoryInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientResponseInMemoryVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientSetRequestHeadersPanel extends JPanel {

			public GrouphttpClientSetRequestHeadersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientSetRequestHeadersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientSetRequestHeadersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientSetRequestHeadersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpClientWriteToRequestPanel extends JPanel {

			public GrouphttpClientWriteToRequestPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpClientWriteToRequestVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpClientWriteToRequestInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpClientWriteToRequestVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponseEndPanel extends JPanel {

			public GrouphttpResponseEndPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponseEndVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponseEndInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponseEndVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponsePutHeaderPanel extends JPanel {

			public GrouphttpResponsePutHeaderPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponsePutHeaderVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponsePutHeaderInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponsePutHeaderVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponsePutTrailersPanel extends JPanel {

			public GrouphttpResponsePutTrailersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponsePutTrailersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponsePutTrailersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponsePutTrailersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponseSTartPanel extends JPanel {

			public GrouphttpResponseSTartPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponseSTartVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponseSTartInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponseSTartVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponseSetHeaderPanel extends JPanel {

			public GrouphttpResponseSetHeaderPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponseSetHeaderVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponseSetHeaderInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponseSetHeaderVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponseSetTrailersPanel extends JPanel {

			public GrouphttpResponseSetTrailersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponseSetTrailersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponseSetTrailersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponseSetTrailersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpResponseWritePanel extends JPanel {

			public GrouphttpResponseWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpResponseWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpResponseWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpResponseWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpServeFilePanel extends JPanel {

			public GrouphttpServeFilePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpServeFileVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpServeFileInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpServeFileVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpServerPanel extends JPanel {

			public GrouphttpServerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpServerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpServerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpServerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpServerIncomingPanel extends JPanel {

			public GrouphttpServerIncomingPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpServerIncomingVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpServerIncomingInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpServerIncomingVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpServerListenHandlerPanel extends JPanel {

			public GrouphttpServerListenHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpServerListenHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpServerListenHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpServerListenHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouphttpServerPartialFilePanel extends JPanel {

			public GrouphttpServerPartialFilePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						httpServerPartialFileVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouphttpServerPartialFileInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						httpServerPartialFileVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupinMemoryBodyAggrPanel extends JPanel {

			public GroupinMemoryBodyAggrPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						inMemoryBodyAggrVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupinMemoryBodyAggrInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						inMemoryBodyAggrVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupinMemoryBodyAggrShortPanel extends JPanel {

			public GroupinMemoryBodyAggrShortPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						inMemoryBodyAggrShortVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupinMemoryBodyAggrShortInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						inMemoryBodyAggrShortVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupisolateVerticleDeploymentPanel extends JPanel {

			public GroupisolateVerticleDeploymentPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						isolateVerticleDeploymentVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupisolateVerticleDeploymentInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						isolateVerticleDeploymentVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupjsonPanel extends JPanel {

			public GroupjsonPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						jsonVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupjsonInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						jsonVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupjsonFromStringPanel extends JPanel {

			public GroupjsonFromStringPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						jsonFromStringVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupjsonFromStringInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonFromStringVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 
				 final JPanel stringEditor = new JPanel(new GridLayout(1,3));

				stringEditor.add(new JLabel("string "));
				final JTextField txtstring = new JTextField(10);
				stringEditor.add(txtstring);
				stringEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonFromStringVerticle.sendStringMessage(vertx, instanceID, txtstring.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(stringEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						jsonFromStringVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupjsonGetIntegerPanel extends JPanel {

			public GroupjsonGetIntegerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						jsonGetIntegerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupjsonGetIntegerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonGetIntegerVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonGetIntegerVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						jsonGetIntegerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupjsonGetStringPanel extends JPanel {

			public GroupjsonGetStringPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						jsonGetStringVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupjsonGetStringInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonGetStringVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						jsonGetStringVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						jsonGetStringVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupleaveMulticastGroupPanel extends JPanel {

			public GroupleaveMulticastGroupPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						leaveMulticastGroupVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupleaveMulticastGroupInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						leaveMulticastGroupVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouplocalSharedMapPanel extends JPanel {

			public GrouplocalSharedMapPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						localSharedMapVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouplocalSharedMapInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						localSharedMapVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmessageCodecPanel extends JPanel {

			public GroupmessageCodecPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						messageCodecVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmessageCodecInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						messageCodecVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmessageHandlerPanel extends JPanel {

			public GroupmessageHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						messageHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmessageHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						messageHandlerVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel packageNameEditor = new JPanel(new GridLayout(1,3));

				packageNameEditor.add(new JLabel("packageName "));
				final JTextField txtpackageName = new JTextField(10);
				packageNameEditor.add(txtpackageName);
				packageNameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						messageHandlerVerticle.sendPackageNameMessage(vertx, instanceID, txtpackageName.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(packageNameEditor); 
				 final JPanel statementEditor = new JPanel(new GridLayout(1,3));

				statementEditor.add(new JLabel("statement "));
				final JTextField txtstatement = new JTextField(10);
				statementEditor.add(txtstatement);
				statementEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						messageHandlerVerticle.sendStatementMessage(vertx, instanceID, txtstatement.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(statementEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						messageHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmessageHeadersPanel extends JPanel {

			public GroupmessageHeadersPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						messageHeadersVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmessageHeadersInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						messageHeadersVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmultipleServersCommandLinePanel extends JPanel {

			public GroupmultipleServersCommandLinePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						multipleServersCommandLineVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmultipleServersCommandLineInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						multipleServersCommandLineVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmultipleServersProgrammaticallyPanel extends JPanel {

			public GroupmultipleServersProgrammaticallyPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						multipleServersProgrammaticallyVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmultipleServersProgrammaticallyInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						multipleServersProgrammaticallyVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmultpileServersVerticlePanel extends JPanel {

			public GroupmultpileServersVerticlePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						multpileServersVerticleVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmultpileServersVerticleInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						multpileServersVerticleVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmvnPanel extends JPanel {

			public GroupmvnPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						mvnVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmvnInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						mvnVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmvnAuthShiroPanel extends JPanel {

			public GroupmvnAuthShiroPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						mvnAuthShiroVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmvnAuthShiroInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						mvnAuthShiroVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmvnDropwizardMetricsPanel extends JPanel {

			public GroupmvnDropwizardMetricsPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						mvnDropwizardMetricsVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmvnDropwizardMetricsInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						mvnDropwizardMetricsVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupmvnJunitPanel extends JPanel {

			public GroupmvnJunitPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						mvnJunitVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupmvnJunitInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						mvnJunitVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewAsynchVerticlePanel extends JPanel {

			public GroupnewAsynchVerticlePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newAsynchVerticleVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewAsynchVerticleInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newAsynchVerticleVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewBufferPanel extends JPanel {

			public GroupnewBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewBufferBytePanel extends JPanel {

			public GroupnewBufferBytePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newBufferByteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewBufferByteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newBufferByteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewBufferSizePanel extends JPanel {

			public GroupnewBufferSizePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newBufferSizeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewBufferSizeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newBufferSizeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewBufferStringPanel extends JPanel {

			public GroupnewBufferStringPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newBufferStringVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewBufferStringInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newBufferStringVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewBufferStringEncodedPanel extends JPanel {

			public GroupnewBufferStringEncodedPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newBufferStringEncodedVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewBufferStringEncodedInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newBufferStringEncodedVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewDatagramSocketPanel extends JPanel {

			public GroupnewDatagramSocketPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newDatagramSocketVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewDatagramSocketInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newDatagramSocketVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewEventBusPanel extends JPanel {

			public GroupnewEventBusPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newEventBusVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewEventBusInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newEventBusVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewJsonArrayPanel extends JPanel {

			public GroupnewJsonArrayPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newJsonArrayVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewJsonArrayInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newJsonArrayVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewTCPClientPanel extends JPanel {

			public GroupnewTCPClientPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newTCPClientVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewTCPClientInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newTCPClientVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupnewTcpServerPanel extends JPanel {

			public GroupnewTcpServerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						newTcpServerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupnewTcpServerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						newTcpServerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouponeShotTimerPanel extends JPanel {

			public GrouponeShotTimerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						oneShotTimerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouponeShotTimerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						oneShotTimerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupperiodicTimerPanel extends JPanel {

			public GroupperiodicTimerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						periodicTimerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupperiodicTimerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel msEditor = new JPanel(new GridLayout(1,3));

				msEditor.add(new JLabel("ms "));
				final JTextField txtms = new JTextField(10);
				msEditor.add(txtms);
				msEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						periodicTimerVerticle.sendMsMessage(vertx, instanceID, txtms.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(msEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						periodicTimerVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						periodicTimerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouppostWritePanel extends JPanel {

			public GrouppostWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						postWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouppostWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						postWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouppublishMessagePanel extends JPanel {

			public GrouppublishMessagePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						publishMessageVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouppublishMessageInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						publishMessageVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouppumpResponsePanel extends JPanel {

			public GrouppumpResponsePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						pumpResponseVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouppumpResponseInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						pumpResponseVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouppumpStreamsPanel extends JPanel {

			public GrouppumpStreamsPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						pumpStreamsVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouppumpStreamsInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						pumpStreamsVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupputDataInMapPanel extends JPanel {

			public GroupputDataInMapPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						putDataInMapVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupputDataInMapInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						putDataInMapVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupputJsonPanel extends JPanel {

			public GroupputJsonPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						putJsonVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupputJsonInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						putJsonVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprandomAccessBufferWritePanel extends JPanel {

			public GrouprandomAccessBufferWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						randomAccessBufferWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprandomAccessBufferWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						randomAccessBufferWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprandomAccessReadPanel extends JPanel {

			public GrouprandomAccessReadPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						randomAccessReadVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprandomAccessReadInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						randomAccessReadVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprandomAccessWritePanel extends JPanel {

			public GrouprandomAccessWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						randomAccessWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprandomAccessWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						randomAccessWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreadBufferPanel extends JPanel {

			public GroupreadBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						readBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreadBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						readBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreadFileAsynchPanel extends JPanel {

			public GroupreadFileAsynchPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						readFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreadFileAsynchInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						readFileAsynchVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreadSocketDataPanel extends JPanel {

			public GroupreadSocketDataPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						readSocketDataVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreadSocketDataInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						readSocketDataVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreadUnsignedNumberPanel extends JPanel {

			public GroupreadUnsignedNumberPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						readUnsignedNumberVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreadUnsignedNumberInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						readUnsignedNumberVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreceiveDatagramPacketPanel extends JPanel {

			public GroupreceiveDatagramPacketPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						receiveDatagramPacketVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreceiveDatagramPacketInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						receiveDatagramPacketVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreceiveMulticastPanel extends JPanel {

			public GroupreceiveMulticastPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						receiveMulticastVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreceiveMulticastInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						receiveMulticastVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprecordParserPanel extends JPanel {

			public GrouprecordParserPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						recordParserVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprecordParserInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						recordParserVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprecordParserFixedPanel extends JPanel {

			public GrouprecordParserFixedPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						recordParserFixedVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprecordParserFixedInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						recordParserFixedVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupregisterHandlerPanel extends JPanel {

			public GroupregisterHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						registerHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupregisterHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						registerHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreplyMessagePanel extends JPanel {

			public GroupreplyMessagePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						replyMessageVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreplyMessageInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						replyMessageVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupreplyReceivedMessagePanel extends JPanel {

			public GroupreplyReceivedMessagePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						replyReceivedMessageVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupreplyReceivedMessageInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						replyReceivedMessageVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprequestHandlerPanel extends JPanel {

			public GrouprequestHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						requestHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprequestHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						requestHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupretriveContextPanel extends JPanel {

			public GroupretriveContextPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						retriveContextVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupretriveContextInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						retriveContextVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprevokateAuthPanel extends JPanel {

			public GrouprevokateAuthPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						revokateAuthVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprevokateAuthInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						revokateAuthVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprevokateAuthBufferPanel extends JPanel {

			public GrouprevokateAuthBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						revokateAuthBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprevokateAuthBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						revokateAuthBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GrouprunInContextPanel extends JPanel {

			public GrouprunInContextPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						runInContextVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GrouprunInContextInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						runInContextVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupsendFilePanel extends JPanel {

			public GroupsendFilePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						sendFileVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupsendFileInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						sendFileVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupsendMessagePanel extends JPanel {

			public GroupsendMessagePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						sendMessageVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupsendMessageInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						sendMessageVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupsendMulticastPanel extends JPanel {

			public GroupsendMulticastPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						sendMulticastVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupsendMulticastInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						sendMulticastVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverConnectionHandlerPanel extends JPanel {

			public GroupserverConnectionHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverConnectionHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverConnectionHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverConnectionHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverListenHandlerPanel extends JPanel {

			public GroupserverListenHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverListenHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverListenHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverListenHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLBufferConfigurationPanel extends JPanel {

			public GroupserverSSLBufferConfigurationPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLBufferConfigurationVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLBufferConfigurationInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLBufferConfigurationVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLKeystorePanel extends JPanel {

			public GroupserverSSLKeystorePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLKeystoreVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLKeystoreInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLKeystoreVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLKeystoreBuffPanel extends JPanel {

			public GroupserverSSLKeystoreBuffPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLKeystoreBuffVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLKeystoreBuffInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLKeystoreBuffVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPEMPanel extends JPanel {

			public GroupserverSSLPEMPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPEMVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPEMInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPEMVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPEMAuthorityPanel extends JPanel {

			public GroupserverSSLPEMAuthorityPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPEMAuthorityVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPEMAuthorityInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPEMAuthorityVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPEMAuthorityBufferPanel extends JPanel {

			public GroupserverSSLPEMAuthorityBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPEMAuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPEMAuthorityBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPEMAuthorityBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPEMBufferPanel extends JPanel {

			public GroupserverSSLPEMBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPEMBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPEMBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPEMBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPKCS_12Panel extends JPanel {

			public GroupserverSSLPKCS_12Panel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPKCS_12Verticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPKCS_12Instance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPKCS_12Verticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPKCS_12AuthorityPanel extends JPanel {

			public GroupserverSSLPKCS_12AuthorityPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPKCS_12AuthorityVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPKCS_12AuthorityInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPKCS_12AuthorityVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLPKCS_12AuthorityBufferPanel extends JPanel {

			public GroupserverSSLPKCS_12AuthorityBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLPKCS_12AuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLPKCS_12AuthorityBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLPKCS_12AuthorityBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLTrustAuthorityPanel extends JPanel {

			public GroupserverSSLTrustAuthorityPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLTrustAuthorityVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLTrustAuthorityInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLTrustAuthorityVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupserverSSLTrustAuthorityBufferPanel extends JPanel {

			public GroupserverSSLTrustAuthorityBufferPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						serverSSLTrustAuthorityBufferVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupserverSSLTrustAuthorityBufferInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						serverSSLTrustAuthorityBufferVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupsimpleWriteRequestPanel extends JPanel {

			public GroupsimpleWriteRequestPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						simpleWriteRequestVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupsimpleWriteRequestInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						simpleWriteRequestVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupsocketClosedHandlerPanel extends JPanel {

			public GroupsocketClosedHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						socketClosedHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupsocketClosedHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						socketClosedHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupundeployVerticlesPanel extends JPanel {

			public GroupundeployVerticlesPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						undeployVerticlesVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupundeployVerticlesInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						undeployVerticlesVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupverticlePanel extends JPanel {

			public GroupverticlePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						verticleVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupverticleInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel nameEditor = new JPanel(new GridLayout(1,3));

				nameEditor.add(new JLabel("name "));
				final JTextField txtname = new JTextField(10);
				nameEditor.add(txtname);
				nameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						verticleVerticle.sendNameMessage(vertx, instanceID, txtname.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(nameEditor); 
				 final JPanel packageNameEditor = new JPanel(new GridLayout(1,3));

				packageNameEditor.add(new JLabel("packageName "));
				final JTextField txtpackageName = new JTextField(10);
				packageNameEditor.add(txtpackageName);
				packageNameEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						verticleVerticle.sendPackageNameMessage(vertx, instanceID, txtpackageName.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(packageNameEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						verticleVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupverticleConfigurationPanel extends JPanel {

			public GroupverticleConfigurationPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						verticleConfigurationVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupverticleConfigurationInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						verticleConfigurationVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupverticleInstancesPanel extends JPanel {

			public GroupverticleInstancesPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						verticleInstancesVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupverticleInstancesInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						verticleInstancesVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupvertxPanel extends JPanel {

			public GroupvertxPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						vertxVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupvertxInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel optionsEditor = new JPanel(new GridLayout(1,3));

				optionsEditor.add(new JLabel("options "));
				final JTextField txtoptions = new JTextField(10);
				optionsEditor.add(txtoptions);
				optionsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxVerticle.sendOptionsMessage(vertx, instanceID, txtoptions.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(optionsEditor); 
				 final JPanel referenceEditor = new JPanel(new GridLayout(1,3));

				referenceEditor.add(new JLabel("reference "));
				final JTextField txtreference = new JTextField(10);
				referenceEditor.add(txtreference);
				referenceEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxVerticle.sendReferenceMessage(vertx, instanceID, txtreference.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(referenceEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						vertxVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupvertxOptionsPanel extends JPanel {

			public GroupvertxOptionsPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						vertxOptionsVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupvertxOptionsInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui
				 final JPanel blockedThreadCheckIntervalEditor = new JPanel(new GridLayout(1,3));

				blockedThreadCheckIntervalEditor.add(new JLabel("blockedThreadCheckInterval "));
				final JTextField txtblockedThreadCheckInterval = new JTextField(10);
				blockedThreadCheckIntervalEditor.add(txtblockedThreadCheckInterval);
				blockedThreadCheckIntervalEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendBlockedThreadCheckIntervalMessage(vertx, instanceID, txtblockedThreadCheckInterval.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(blockedThreadCheckIntervalEditor); 
				 final JPanel clusterHostEditor = new JPanel(new GridLayout(1,3));

				clusterHostEditor.add(new JLabel("clusterHost "));
				final JTextField txtclusterHost = new JTextField(10);
				clusterHostEditor.add(txtclusterHost);
				clusterHostEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterHostMessage(vertx, instanceID, txtclusterHost.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterHostEditor); 
				 final JPanel clusterManagerEditor = new JPanel(new GridLayout(1,3));

				clusterManagerEditor.add(new JLabel("clusterManager "));
				final JTextField txtclusterManager = new JTextField(10);
				clusterManagerEditor.add(txtclusterManager);
				clusterManagerEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterManagerMessage(vertx, instanceID, txtclusterManager.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterManagerEditor); 
				 final JPanel clusterPingIntervalEditor = new JPanel(new GridLayout(1,3));

				clusterPingIntervalEditor.add(new JLabel("clusterPingInterval "));
				final JTextField txtclusterPingInterval = new JTextField(10);
				clusterPingIntervalEditor.add(txtclusterPingInterval);
				clusterPingIntervalEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterPingIntervalMessage(vertx, instanceID, txtclusterPingInterval.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterPingIntervalEditor); 
				 final JPanel clusterPingReplyIntervalEditor = new JPanel(new GridLayout(1,3));

				clusterPingReplyIntervalEditor.add(new JLabel("clusterPingReplyInterval "));
				final JTextField txtclusterPingReplyInterval = new JTextField(10);
				clusterPingReplyIntervalEditor.add(txtclusterPingReplyInterval);
				clusterPingReplyIntervalEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterPingReplyIntervalMessage(vertx, instanceID, txtclusterPingReplyInterval.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterPingReplyIntervalEditor); 
				 final JPanel clusterPortEditor = new JPanel(new GridLayout(1,3));

				clusterPortEditor.add(new JLabel("clusterPort "));
				final JTextField txtclusterPort = new JTextField(10);
				clusterPortEditor.add(txtclusterPort);
				clusterPortEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterPortMessage(vertx, instanceID, txtclusterPort.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterPortEditor); 
				 final JPanel clusterPublicHostEditor = new JPanel(new GridLayout(1,3));

				clusterPublicHostEditor.add(new JLabel("clusterPublicHost "));
				final JTextField txtclusterPublicHost = new JTextField(10);
				clusterPublicHostEditor.add(txtclusterPublicHost);
				clusterPublicHostEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterPublicHostMessage(vertx, instanceID, txtclusterPublicHost.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterPublicHostEditor); 
				 final JPanel clusterPublicPortEditor = new JPanel(new GridLayout(1,3));

				clusterPublicPortEditor.add(new JLabel("clusterPublicPort "));
				final JTextField txtclusterPublicPort = new JTextField(10);
				clusterPublicPortEditor.add(txtclusterPublicPort);
				clusterPublicPortEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusterPublicPortMessage(vertx, instanceID, txtclusterPublicPort.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusterPublicPortEditor); 
				 final JPanel clusteredEditor = new JPanel(new GridLayout(1,3));

				clusteredEditor.add(new JLabel("clustered "));
				final JTextField txtclustered = new JTextField(10);
				clusteredEditor.add(txtclustered);
				clusteredEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendClusteredMessage(vertx, instanceID, txtclustered.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(clusteredEditor); 
				 final JPanel eventLoopPoolSizeEditor = new JPanel(new GridLayout(1,3));

				eventLoopPoolSizeEditor.add(new JLabel("eventLoopPoolSize "));
				final JTextField txteventLoopPoolSize = new JTextField(10);
				eventLoopPoolSizeEditor.add(txteventLoopPoolSize);
				eventLoopPoolSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendEventLoopPoolSizeMessage(vertx, instanceID, txteventLoopPoolSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(eventLoopPoolSizeEditor); 
				 final JPanel haEnabledEditor = new JPanel(new GridLayout(1,3));

				haEnabledEditor.add(new JLabel("haEnabled "));
				final JTextField txthaEnabled = new JTextField(10);
				haEnabledEditor.add(txthaEnabled);
				haEnabledEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendHaEnabledMessage(vertx, instanceID, txthaEnabled.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(haEnabledEditor); 
				 final JPanel haGroupEditor = new JPanel(new GridLayout(1,3));

				haGroupEditor.add(new JLabel("haGroup "));
				final JTextField txthaGroup = new JTextField(10);
				haGroupEditor.add(txthaGroup);
				haGroupEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendHaGroupMessage(vertx, instanceID, txthaGroup.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(haGroupEditor); 
				 final JPanel internalBlockingPoolSizeEditor = new JPanel(new GridLayout(1,3));

				internalBlockingPoolSizeEditor.add(new JLabel("internalBlockingPoolSize "));
				final JTextField txtinternalBlockingPoolSize = new JTextField(10);
				internalBlockingPoolSizeEditor.add(txtinternalBlockingPoolSize);
				internalBlockingPoolSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendInternalBlockingPoolSizeMessage(vertx, instanceID, txtinternalBlockingPoolSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(internalBlockingPoolSizeEditor); 
				 final JPanel maxEventLoopExecuteTimeEditor = new JPanel(new GridLayout(1,3));

				maxEventLoopExecuteTimeEditor.add(new JLabel("maxEventLoopExecuteTime "));
				final JTextField txtmaxEventLoopExecuteTime = new JTextField(10);
				maxEventLoopExecuteTimeEditor.add(txtmaxEventLoopExecuteTime);
				maxEventLoopExecuteTimeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendMaxEventLoopExecuteTimeMessage(vertx, instanceID, txtmaxEventLoopExecuteTime.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(maxEventLoopExecuteTimeEditor); 
				 final JPanel maxWorkerExecuteTimeEditor = new JPanel(new GridLayout(1,3));

				maxWorkerExecuteTimeEditor.add(new JLabel("maxWorkerExecuteTime "));
				final JTextField txtmaxWorkerExecuteTime = new JTextField(10);
				maxWorkerExecuteTimeEditor.add(txtmaxWorkerExecuteTime);
				maxWorkerExecuteTimeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendMaxWorkerExecuteTimeMessage(vertx, instanceID, txtmaxWorkerExecuteTime.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(maxWorkerExecuteTimeEditor); 
				 final JPanel metricsEditor = new JPanel(new GridLayout(1,3));

				metricsEditor.add(new JLabel("metrics "));
				final JTextField txtmetrics = new JTextField(10);
				metricsEditor.add(txtmetrics);
				metricsEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendMetricsMessage(vertx, instanceID, txtmetrics.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(metricsEditor); 
				 final JPanel quorumSizeEditor = new JPanel(new GridLayout(1,3));

				quorumSizeEditor.add(new JLabel("quorumSize "));
				final JTextField txtquorumSize = new JTextField(10);
				quorumSizeEditor.add(txtquorumSize);
				quorumSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendQuorumSizeMessage(vertx, instanceID, txtquorumSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(quorumSizeEditor); 
				 final JPanel warningExceptionTimeEditor = new JPanel(new GridLayout(1,3));

				warningExceptionTimeEditor.add(new JLabel("warningExceptionTime "));
				final JTextField txtwarningExceptionTime = new JTextField(10);
				warningExceptionTimeEditor.add(txtwarningExceptionTime);
				warningExceptionTimeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendWarningExceptionTimeMessage(vertx, instanceID, txtwarningExceptionTime.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(warningExceptionTimeEditor); 
				 final JPanel workerPoolSizeEditor = new JPanel(new GridLayout(1,3));

				workerPoolSizeEditor.add(new JLabel("workerPoolSize "));
				final JTextField txtworkerPoolSize = new JTextField(10);
				workerPoolSizeEditor.add(txtworkerPoolSize);
				workerPoolSizeEditor.add(new JButton(new AbstractAction("set") {
					@Override
					public void actionPerformed(ActionEvent e) {
						// DomainBooleanPropertySetterVerticle.sendPropertyNameMessage
						vertxOptionsVerticle.sendWorkerPoolSizeMessage(vertx, instanceID, txtworkerPoolSize.getText(), s -> SwingUtilities.invokeLater(() -> {
							((JButton) e.getSource()).setEnabled(false);
						}));
					}
				}));
				actionPanel.add(workerPoolSizeEditor); 

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						vertxOptionsVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketFrameWritePanel extends JPanel {

			public GroupwebsocketFrameWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketFrameWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketFrameWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketFrameWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketHandlerPanel extends JPanel {

			public GroupwebsocketHandlerPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketHandlerVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketHandlerInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketHandlerVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketReadFramePanel extends JPanel {

			public GroupwebsocketReadFramePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketReadFrameVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketReadFrameInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketReadFrameVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketSingleFrameWritePanel extends JPanel {

			public GroupwebsocketSingleFrameWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketSingleFrameWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketSingleFrameWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketSingleFrameWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketUpgradePanel extends JPanel {

			public GroupwebsocketUpgradePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketUpgradeVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketUpgradeInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketUpgradeVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwebsocketWritePanel extends JPanel {

			public GroupwebsocketWritePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						websocketWriteVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwebsocketWriteInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						websocketWriteVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupworkerVerticlePanel extends JPanel {

			public GroupworkerVerticlePanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						workerVerticleVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupworkerVerticleInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						workerVerticleVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwriteFileAsynchPanel extends JPanel {

			public GroupwriteFileAsynchPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						writeFileAsynchVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwriteFileAsynchInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						writeFileAsynchVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
	 private static final class GroupwriteSocketDataPanel extends JPanel {

			public GroupwriteSocketDataPanel(Vertx vertx) {
				super(new BorderLayout());

				final JTabbedPane instancesPanel = new JTabbedPane();

				final JButton btnDeploy = new JButton(new AbstractAction("newInstance") {
					@Override
					public void actionPerformed(ActionEvent e) {
						final UUID instanceID = UUID.randomUUID();
						writeSocketDataVerticle.sendInstanceMessage(vertx, instanceID, s -> {
							instancesPanel.add(instanceID.toString(), actionPanel(vertx, instanceID));
						});
					}
				});
				add(btnDeploy, BorderLayout.NORTH);
				add(instancesPanel, BorderLayout.CENTER);
			}

			private JPanel actionPanel(Vertx vertx, UUID instanceID) {

				final JPanel actionPanel = new JPanel(new com.generator.util.WrapLayout());

				actionPanel.add(new JLabel("GroupwriteSocketDataInstance "));
				actionPanel.add(new JLabel(instanceID.toString()));
				actionPanel.add(new JLabel());

				// todo all properties here, with their proper ui

				final JPanel container = new JPanel(new BorderLayout());
				container.add(actionPanel, BorderLayout.NORTH);			

				actionPanel.add(new JLabel("Output "));
				final JTextArea txtToString = new JTextArea(10, 50);
				actionPanel.add(txtToString);
				actionPanel.add(new JButton(new AbstractAction("toString") {
					@Override
					public void actionPerformed(ActionEvent e) {
						writeSocketDataVerticle.sendToStringMessage(vertx, instanceID, s -> SwingUtilities.invokeLater(() -> {
							txtToString.setText(s);
						}));
					}
				}));
				container.add(new JScrollPane(txtToString), BorderLayout.CENTER);

				return container;
			}
		} 
} 