

 package com.generator.generators.vertxCore.vertx;

import com.generator.util.VertxUtil;
import com.generator.generators.vertxCore.VertxCoreGroup;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

import static com.generator.util.VertxUtil.*;

/**
 * goe on 5/20/16.
 */
public class vertxOptionsVerticle extends AbstractVerticle {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(vertxOptionsVerticle.class);

	public static void sendInstanceMessage(Vertx vertx, java.util.UUID instanceId, Handler<String> instanceHandler) {
		sendMessage(vertx, "new.VertxCoreGroup.vertxOptions", instanceId.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendvertxOptionsMessage failed");
			}
		});
	}

	public static void sendToStringMessage(Vertx vertx, java.util.UUID id, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".toString", id.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendToStringMessage " + id + ".toString failed", t);
			}
	});
}      


	 public static void sendBlockedThreadCheckIntervalMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".blockedThreadCheckInterval", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendBlockedThreadCheckIntervalMessage " + id + ".blockedThreadCheckInterval failed", t);
			}
		});
	}  

	 public static void sendClusterHostMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterHost", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterHostMessage " + id + ".clusterHost failed", t);
			}
		});
	}  

	 public static void sendClusterManagerMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterManager", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterManagerMessage " + id + ".clusterManager failed", t);
			}
		});
	}  

	 public static void sendClusterPingIntervalMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterPingInterval", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterPingIntervalMessage " + id + ".clusterPingInterval failed", t);
			}
		});
	}  

	 public static void sendClusterPingReplyIntervalMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterPingReplyInterval", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterPingReplyIntervalMessage " + id + ".clusterPingReplyInterval failed", t);
			}
		});
	}  

	 public static void sendClusterPortMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterPort", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterPortMessage " + id + ".clusterPort failed", t);
			}
		});
	}  

	 public static void sendClusterPublicHostMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterPublicHost", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterPublicHostMessage " + id + ".clusterPublicHost failed", t);
			}
		});
	}  

	 public static void sendClusterPublicPortMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clusterPublicPort", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusterPublicPortMessage " + id + ".clusterPublicPort failed", t);
			}
		});
	}  

	 public static void sendClusteredMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".clustered", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClusteredMessage " + id + ".clustered failed", t);
			}
		});
	}  

	 public static void sendEventLoopPoolSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".eventLoopPoolSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendEventLoopPoolSizeMessage " + id + ".eventLoopPoolSize failed", t);
			}
		});
	}  

	 public static void sendHaEnabledMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".haEnabled", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHaEnabledMessage " + id + ".haEnabled failed", t);
			}
		});
	}  

	 public static void sendHaGroupMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".haGroup", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHaGroupMessage " + id + ".haGroup failed", t);
			}
		});
	}  

	 public static void sendInternalBlockingPoolSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".internalBlockingPoolSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendInternalBlockingPoolSizeMessage " + id + ".internalBlockingPoolSize failed", t);
			}
		});
	}  

	 public static void sendMaxEventLoopExecuteTimeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".maxEventLoopExecuteTime", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendMaxEventLoopExecuteTimeMessage " + id + ".maxEventLoopExecuteTime failed", t);
			}
		});
	}  

	 public static void sendMaxWorkerExecuteTimeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".maxWorkerExecuteTime", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendMaxWorkerExecuteTimeMessage " + id + ".maxWorkerExecuteTime failed", t);
			}
		});
	}  

	 public static void sendMetricsMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".metrics", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendMetricsMessage " + id + ".metrics failed", t);
			}
		});
	}  

	 public static void sendQuorumSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".quorumSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendQuorumSizeMessage " + id + ".quorumSize failed", t);
			}
		});
	}  

	 public static void sendWarningExceptionTimeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".warningExceptionTime", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendWarningExceptionTimeMessage " + id + ".warningExceptionTime failed", t);
			}
		});
	}  

	 public static void sendWorkerPoolSizeMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".workerPoolSize", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendWorkerPoolSizeMessage " + id + ".workerPoolSize failed", t);
			}
		});
	}  

	@Override
	public void start(Future<Void> startFuture) throws Exception {

		final VertxCoreGroup templateGroup = new VertxCoreGroup();

		consume(vertx, deploymentID(), "new.VertxCoreGroup.vertxOptions", log, new Handler<Message<String> >() {
			@Override
			public void handle(Message<String> idMessage) {

				// new instance of template
				final VertxCoreGroup.vertxOptionsST template = templateGroup.newvertxOptions();





				 // string property blockedThreadCheckInterval
				consume(vertx, deploymentID(), idMessage.body() + ".blockedThreadCheckInterval", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setBlockedThreadCheckInterval(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterHost
				consume(vertx, deploymentID(), idMessage.body() + ".clusterHost", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterHost(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterManager
				consume(vertx, deploymentID(), idMessage.body() + ".clusterManager", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterManager(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterPingInterval
				consume(vertx, deploymentID(), idMessage.body() + ".clusterPingInterval", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterPingInterval(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterPingReplyInterval
				consume(vertx, deploymentID(), idMessage.body() + ".clusterPingReplyInterval", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterPingReplyInterval(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterPort
				consume(vertx, deploymentID(), idMessage.body() + ".clusterPort", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterPort(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterPublicHost
				consume(vertx, deploymentID(), idMessage.body() + ".clusterPublicHost", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterPublicHost(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clusterPublicPort
				consume(vertx, deploymentID(), idMessage.body() + ".clusterPublicPort", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClusterPublicPort(message.body());
						message.reply(message.body());
					}
				});     




				 // string property clustered
				consume(vertx, deploymentID(), idMessage.body() + ".clustered", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClustered(message.body());
						message.reply(message.body());
					}
				});     




				 // string property eventLoopPoolSize
				consume(vertx, deploymentID(), idMessage.body() + ".eventLoopPoolSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setEventLoopPoolSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property haEnabled
				consume(vertx, deploymentID(), idMessage.body() + ".haEnabled", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setHaEnabled(message.body());
						message.reply(message.body());
					}
				});     




				 // string property haGroup
				consume(vertx, deploymentID(), idMessage.body() + ".haGroup", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setHaGroup(message.body());
						message.reply(message.body());
					}
				});     




				 // string property internalBlockingPoolSize
				consume(vertx, deploymentID(), idMessage.body() + ".internalBlockingPoolSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setInternalBlockingPoolSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property maxEventLoopExecuteTime
				consume(vertx, deploymentID(), idMessage.body() + ".maxEventLoopExecuteTime", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setMaxEventLoopExecuteTime(message.body());
						message.reply(message.body());
					}
				});     




				 // string property maxWorkerExecuteTime
				consume(vertx, deploymentID(), idMessage.body() + ".maxWorkerExecuteTime", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setMaxWorkerExecuteTime(message.body());
						message.reply(message.body());
					}
				});     




				 // string property metrics
				consume(vertx, deploymentID(), idMessage.body() + ".metrics", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setMetrics(message.body());
						message.reply(message.body());
					}
				});     




				 // string property quorumSize
				consume(vertx, deploymentID(), idMessage.body() + ".quorumSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setQuorumSize(message.body());
						message.reply(message.body());
					}
				});     




				 // string property warningExceptionTime
				consume(vertx, deploymentID(), idMessage.body() + ".warningExceptionTime", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setWarningExceptionTime(message.body());
						message.reply(message.body());
					}
				});     




				 // string property workerPoolSize
				consume(vertx, deploymentID(), idMessage.body() + ".workerPoolSize", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setWorkerPoolSize(message.body());
						message.reply(message.body());
					}
				});     

				// toString
				consume(vertx, deploymentID(), idMessage.body() + ".toString", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						message.reply(template.toString());
					}
				});

				// other convenience methods here

				idMessage.reply(idMessage.body());
			}
		});

		startFuture.complete();
	}

	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		super.stop(stopFuture);
	}
}   