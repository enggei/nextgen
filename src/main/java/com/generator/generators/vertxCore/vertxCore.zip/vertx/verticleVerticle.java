

 package com.generator.generators.vertxCore.vertx;

import com.generator.util.VertxUtil;
import com.generator.generators.vertxCore.VertxCoreGroup;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

import static com.generator.util.VertxUtil.*;

/**
 * goe on 5/20/16.
 */
public class verticleVerticle extends AbstractVerticle {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(verticleVerticle.class);

	public static void sendInstanceMessage(Vertx vertx, java.util.UUID instanceId, Handler<String> instanceHandler) {
		sendMessage(vertx, "new.VertxCoreGroup.verticle", instanceId.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendverticleMessage failed");
			}
		});
	}

	public static void sendToStringMessage(Vertx vertx, java.util.UUID id, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".toString", id.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendToStringMessage " + id + ".toString failed", t);
			}
	});
}      

	 public static void sendAddFields(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject();

		sendMessage(vertx, id + ".fields", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendFieldsMessage " + id + ".fields " + parameters.encode() + " failed", t);
			}
		});
	} 
	 public static void sendAddImports(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject();

		sendMessage(vertx, id + ".imports", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendImportsMessage " + id + ".imports " + parameters.encode() + " failed", t);
			}
		});
	} 

	 public static void sendNameMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".name", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendNameMessage " + id + ".name failed", t);
			}
		});
	}  

	 public static void sendPackageNameMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".packageName", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendPackageNameMessage " + id + ".packageName failed", t);
			}
		});
	}  
	 public static void sendAddStartStatements(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject();

		sendMessage(vertx, id + ".startStatements", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendStartStatementsMessage " + id + ".startStatements " + parameters.encode() + " failed", t);
			}
		});
	} 
	 public static void sendAddStopStatements(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject();

		sendMessage(vertx, id + ".stopStatements", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendStopStatementsMessage " + id + ".stopStatements " + parameters.encode() + " failed", t);
			}
		});
	} 
	 public static void sendAddVerticles(Vertx vertx, java.util.UUID id, Object content, String deploy, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject().put("deploy", deploy);

		sendMessage(vertx, id + ".verticles", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendVerticlesMessage " + id + ".verticles " + parameters.encode() + " failed", t);
			}
		});
	} 

	@Override
	public void start(Future<Void> startFuture) throws Exception {

		final VertxCoreGroup templateGroup = new VertxCoreGroup();

		consume(vertx, deploymentID(), "new.VertxCoreGroup.verticle", log, new Handler<Message<String> >() {
			@Override
			public void handle(Message<String> idMessage) {

				// new instance of template
				final VertxCoreGroup.verticleST template = templateGroup.newverticle();



				 // list property fields
				consume(vertx, deploymentID(), idMessage.body() + ".fields", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.addFieldsValue(message.body());
					}
				});   


				 // list property imports
				consume(vertx, deploymentID(), idMessage.body() + ".imports", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.addImportsValue(message.body());
					}
				});   




				 // string property name
				consume(vertx, deploymentID(), idMessage.body() + ".name", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setName(message.body());
						message.reply(message.body());
					}
				});     




				 // string property packageName
				consume(vertx, deploymentID(), idMessage.body() + ".packageName", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setPackageName(message.body());
						message.reply(message.body());
					}
				});     


				 // list property startStatements
				consume(vertx, deploymentID(), idMessage.body() + ".startStatements", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.addStartStatementsValue(message.body());
					}
				});   


				 // list property stopStatements
				consume(vertx, deploymentID(), idMessage.body() + ".stopStatements", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.addStopStatementsValue(message.body());
					}
				});   



				 // key-value list property verticles
				consume(vertx, deploymentID(), idMessage.body() + ".verticles", log, new Handler<Message<JsonObject> >() {
					@Override
					public void handle(Message<JsonObject> message) {
						template.addVerticlesValue(message.body().getString("deploy"));
					}
				});    

				// toString
				consume(vertx, deploymentID(), idMessage.body() + ".toString", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						message.reply(template.toString());
					}
				});

				// other convenience methods here

				idMessage.reply(idMessage.body());
			}
		});

		startFuture.complete();
	}

	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		super.stop(stopFuture);
	}
}   