

 package com.generator.generators.vertxCore.vertx;

import com.generator.util.VertxUtil;
import com.generator.generators.vertxCore.VertxCoreGroup;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

import static com.generator.util.VertxUtil.*;

/**
 * goe on 5/20/16.
 */
public class clientRequestVerticle extends AbstractVerticle {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(clientRequestVerticle.class);

	public static void sendInstanceMessage(Vertx vertx, java.util.UUID instanceId, Handler<String> instanceHandler) {
		sendMessage(vertx, "new.VertxCoreGroup.clientRequest", instanceId.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendclientRequestMessage failed");
			}
		});
	}

	public static void sendToStringMessage(Vertx vertx, java.util.UUID id, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".toString", id.toString(), log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendToStringMessage " + id + ".toString failed", t);
			}
	});
}      


	 public static void sendClientMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".client", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendClientMessage " + id + ".client failed", t);
			}
		});
	}  

	 public static void sendContentMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".content", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendContentMessage " + id + ".content failed", t);
			}
		});
	}  

	 public static void sendHandleBodyMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".handleBody", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHandleBodyMessage " + id + ".handleBody failed", t);
			}
		});
	}  

	 public static void sendHandleResponseMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".handleResponse", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHandleResponseMessage " + id + ".handleResponse failed", t);
			}
		});
	}  
	 public static void sendAddHeaders(Vertx vertx, java.util.UUID id, Object content, String name, String value, Handler<String> instanceHandler) {

		final JsonObject parameters = new JsonObject().put("name", name)
			.put("value", value);

		sendMessage(vertx, id + ".headers", parameters, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHeadersMessage " + id + ".headers " + parameters.encode() + " failed", t);
			}
		});
	} 

	 public static void sendHttpMethodMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".httpMethod", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendHttpMethodMessage " + id + ".httpMethod failed", t);
			}
		});
	}  

	 public static void sendUriMessage(Vertx vertx, java.util.UUID id, Object content, Handler<String> instanceHandler) {
		sendMessage(vertx, id + ".uri", content, log, new VertxUtil.SuccessHandler<Message<String> >() {
			@Override
			public void onSuccess(Message<String> result) {
				instanceHandler.handle(result.body());
			}

			@Override
			public void onFail(Throwable t) {
				log.error("sendUriMessage " + id + ".uri failed", t);
			}
		});
	}  

	@Override
	public void start(Future<Void> startFuture) throws Exception {

		final VertxCoreGroup templateGroup = new VertxCoreGroup();

		consume(vertx, deploymentID(), "new.VertxCoreGroup.clientRequest", log, new Handler<Message<String> >() {
			@Override
			public void handle(Message<String> idMessage) {

				// new instance of template
				final VertxCoreGroup.clientRequestST template = templateGroup.newclientRequest();





				 // string property client
				consume(vertx, deploymentID(), idMessage.body() + ".client", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setClient(message.body());
						message.reply(message.body());
					}
				});     




				 // string property content
				consume(vertx, deploymentID(), idMessage.body() + ".content", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setContent(message.body());
						message.reply(message.body());
					}
				});     




				 // string property handleBody
				consume(vertx, deploymentID(), idMessage.body() + ".handleBody", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setHandleBody(message.body());
						message.reply(message.body());
					}
				});     




				 // string property handleResponse
				consume(vertx, deploymentID(), idMessage.body() + ".handleResponse", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setHandleResponse(message.body());
						message.reply(message.body());
					}
				});     



				 // key-value list property headers
				consume(vertx, deploymentID(), idMessage.body() + ".headers", log, new Handler<Message<JsonObject> >() {
					@Override
					public void handle(Message<JsonObject> message) {
						template.addHeadersValue(message.body().getString("name"),message.body().getString("value"));
					}
				});    




				 // string property httpMethod
				consume(vertx, deploymentID(), idMessage.body() + ".httpMethod", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setHttpMethod(message.body());
						message.reply(message.body());
					}
				});     




				 // string property uri
				consume(vertx, deploymentID(), idMessage.body() + ".uri", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						template.setUri(message.body());
						message.reply(message.body());
					}
				});     

				// toString
				consume(vertx, deploymentID(), idMessage.body() + ".toString", log, new Handler<Message<String> >() {
					@Override
					public void handle(Message<String> message) {
						message.reply(template.toString());
					}
				});

				// other convenience methods here

				idMessage.reply(idMessage.body());
			}
		});

		startFuture.complete();
	}

	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		super.stop(stopFuture);
	}
}   