 package com.generator.generators.vertxCore;

 import org.stringtemplate.v4.ST;
 import org.stringtemplate.v4.STGroup;

 import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Wraps STGroup-methods based on 'VertxCoreGroup.stg' file<br/>
 */
public final class VertxCoreGroup {

   private final STGroup stGroup;
   private final char delimiter;

	public VertxCoreGroup() {
		this(new org.stringtemplate.v4.STGroupFile(System.getProperty("generator.path") + java.io.File.separator + "vertxCore" + java.io.File.separator + "vertxCore.stg"));
   }

   public VertxCoreGroup(STGroup stGroup) {
      this.stGroup = stGroup;
      this.stGroup.registerRenderer(String.class, new DefaultAttributeRenderer());
      this.delimiter = stGroup.delimiterStartChar;
   }

   public VertxCoreGroup(java.io.File templateFile) {
      this.stGroup = new org.stringtemplate.v4.STGroupFile(templateFile.getAbsolutePath());
      this.stGroup.registerRenderer(String.class, new DefaultAttributeRenderer());
      this.delimiter = stGroup.delimiterStartChar;
   }

   public STGroup getSTGroup() {
      return stGroup;
   }

   public char getDelimiter() {
      return delimiter;
   }


   public appendBufferST newappendBuffer() {
      return new appendBufferST(stGroup);
   } 


   public asynchFileST newasynchFile() {
      return new asynchFileST(stGroup);
   } 


   public asynchVerticleStopST newasynchVerticleStop() {
      return new asynchVerticleStopST(stGroup);
   } 


   public blockMulticastST newblockMulticast() {
      return new blockMulticastST(stGroup);
   } 


   public blockingCodeST newblockingCode() {
      return new blockingCodeST(stGroup);
   } 


   public bodyHandlerST newbodyHandler() {
      return new bodyHandlerST(stGroup);
   } 


   public bufCopyST newbufCopy() {
      return new bufCopyST(stGroup);
   } 


   public bufLengthST newbufLength() {
      return new bufLengthST(stGroup);
   } 


   public bufSliceST newbufSlice() {
      return new bufSliceST(stGroup);
   } 


   public bugfixST newbugfix() {
      return new bugfixST(stGroup);
   } 


   public cancelTimerST newcancelTimer() {
      return new cancelTimerST(stGroup);
   } 


   public checkExistenceAndDeleteST newcheckExistenceAndDelete() {
      return new checkExistenceAndDeleteST(stGroup);
   } 


   public chunkFileUploadHandlerST newchunkFileUploadHandler() {
      return new chunkFileUploadHandlerST(stGroup);
   } 


   public clientConnectST newclientConnect() {
      return new clientConnectST(stGroup);
   } 


   public clientRequestST newclientRequest() {
      return new clientRequestST(stGroup);
   } 


   public clientSSLST newclientSSL() {
      return new clientSSLST(stGroup);
   } 


   public clientSSLKeystoreAuthST newclientSSLKeystoreAuth() {
      return new clientSSLKeystoreAuthST(stGroup);
   } 


   public clientSSLKeystoreAuthBufferST newclientSSLKeystoreAuthBuffer() {
      return new clientSSLKeystoreAuthBufferST(stGroup);
   } 


   public clientSSLPEMST newclientSSLPEM() {
      return new clientSSLPEMST(stGroup);
   } 


   public clientSSLPEMAuthST newclientSSLPEMAuth() {
      return new clientSSLPEMAuthST(stGroup);
   } 


   public clientSSLPEMAuthBufferST newclientSSLPEMAuthBuffer() {
      return new clientSSLPEMAuthBufferST(stGroup);
   } 


   public clientSSLPEMBufferST newclientSSLPEMBuffer() {
      return new clientSSLPEMBufferST(stGroup);
   } 


   public clientSSLPKCSAuthST newclientSSLPKCSAuth() {
      return new clientSSLPKCSAuthST(stGroup);
   } 


   public clientSSLPKCSAuthBufferST newclientSSLPKCSAuthBuffer() {
      return new clientSSLPKCSAuthBufferST(stGroup);
   } 


   public clientSSLPKCS_12ST newclientSSLPKCS_12() {
      return new clientSSLPKCS_12ST(stGroup);
   } 


   public clientSSLPKCS_12BufferST newclientSSLPKCS_12Buffer() {
      return new clientSSLPKCS_12BufferST(stGroup);
   } 


   public clientSSLTruststoreST newclientSSLTruststore() {
      return new clientSSLTruststoreST(stGroup);
   } 


   public clientSSLTruststoreBufferST newclientSSLTruststoreBuffer() {
      return new clientSSLTruststoreBufferST(stGroup);
   } 


   public clientWebsocketST newclientWebsocket() {
      return new clientWebsocketST(stGroup);
   } 


   public closeServerST newcloseServer() {
      return new closeServerST(stGroup);
   } 


   public clusterCommandLineST newclusterCommandLine() {
      return new clusterCommandLineST(stGroup);
   } 


   public clusterCounterST newclusterCounter() {
      return new clusterCounterST(stGroup);
   } 


   public clusterProgrammaticallyST newclusterProgrammatically() {
      return new clusterProgrammaticallyST(stGroup);
   } 


   public clusterSharedMapST newclusterSharedMap() {
      return new clusterSharedMapST(stGroup);
   } 


   public clusterWideLockST newclusterWideLock() {
      return new clusterWideLockST(stGroup);
   } 


   public clusterWideLockTimeoutST newclusterWideLockTimeout() {
      return new clusterWideLockTimeoutST(stGroup);
   } 


   public cmdHighAvailabilityST newcmdHighAvailability() {
      return new cmdHighAvailabilityST(stGroup);
   } 


   public cmdRunVerticlesST newcmdRunVerticles() {
      return new cmdRunVerticlesST(stGroup);
   } 


   public configGetIntegerST newconfigGetInteger() {
      return new configGetIntegerST(stGroup);
   } 


   public configGetStringST newconfigGetString() {
      return new configGetStringST(stGroup);
   } 


   public configureCipherSuiteST newconfigureCipherSuite() {
      return new configureCipherSuiteST(stGroup);
   } 


   public consumerCompletionHandlerST newconsumerCompletionHandler() {
      return new consumerCompletionHandlerST(stGroup);
   } 


   public contextSharedDataST newcontextSharedData() {
      return new contextSharedDataST(stGroup);
   } 


   public contextTypeST newcontextType() {
      return new contextTypeST(stGroup);
   } 


   public copyFileAsynchST newcopyFileAsynch() {
      return new copyFileAsynchST(stGroup);
   } 


   public copyFileSynchST newcopyFileSynch() {
      return new copyFileSynchST(stGroup);
   } 


   public deployPolyVerticlesST newdeployPolyVerticles() {
      return new deployPolyVerticlesST(stGroup);
   } 


   public deployVerticleProgrammaticallyST newdeployVerticleProgrammatically() {
      return new deployVerticleProgrammaticallyST(stGroup);
   } 


   public deployVerticleStartST newdeployVerticleStart() {
      return new deployVerticleStartST(stGroup);
   } 


   public dnsClientST newdnsClient() {
      return new dnsClientST(stGroup);
   } 


   public dnsLookupST newdnsLookup() {
      return new dnsLookupST(stGroup);
   } 


   public dnsLookup4ST newdnsLookup4() {
      return new dnsLookup4ST(stGroup);
   } 


   public dnsLookup6ST newdnsLookup6() {
      return new dnsLookup6ST(stGroup);
   } 


   public dnsResolveAST newdnsResolveA() {
      return new dnsResolveAST(stGroup);
   } 


   public dnsResolveAAAAST newdnsResolveAAAA() {
      return new dnsResolveAAAAST(stGroup);
   } 


   public dnsResolveCNAMEST newdnsResolveCNAME() {
      return new dnsResolveCNAMEST(stGroup);
   } 


   public dnsResolveMXST newdnsResolveMX() {
      return new dnsResolveMXST(stGroup);
   } 


   public dnsResolveNSST newdnsResolveNS() {
      return new dnsResolveNSST(stGroup);
   } 


   public dnsResolvePTRST newdnsResolvePTR() {
      return new dnsResolvePTRST(stGroup);
   } 


   public dnsResolveSRVST newdnsResolveSRV() {
      return new dnsResolveSRVST(stGroup);
   } 


   public dnsResolveTXTST newdnsResolveTXT() {
      return new dnsResolveTXTST(stGroup);
   } 


   public dnsResponseCodeST newdnsResponseCode() {
      return new dnsResponseCodeST(stGroup);
   } 


   public dnsReverseLookupST newdnsReverseLookup() {
      return new dnsReverseLookupST(stGroup);
   } 


   public ebConsumeST newebConsume() {
      return new ebConsumeST(stGroup);
   } 


   public ebPublishST newebPublish() {
      return new ebPublishST(stGroup);
   } 


   public encodeArrayST newencodeArray() {
      return new encodeArrayST(stGroup);
   } 


   public fileStreamST newfileStream() {
      return new fileStreamST(stGroup);
   } 


   public formFileStreamUploadST newformFileStreamUpload() {
      return new formFileStreamUploadST(stGroup);
   } 


   public formFileUploadHandlerST newformFileUploadHandler() {
      return new formFileUploadHandlerST(stGroup);
   } 


   public formHandlerST newformHandler() {
      return new formHandlerST(stGroup);
   } 


   public getDataFromMapST newgetDataFromMap() {
      return new getDataFromMapST(stGroup);
   } 


   public getJsonST newgetJson() {
      return new getJsonST(stGroup);
   } 


   public getJsonArrayST newgetJsonArray() {
      return new getJsonArrayST(stGroup);
   } 


   public getRequestHeadersST newgetRequestHeaders() {
      return new getRequestHeadersST(stGroup);
   } 


   public httpClientST newhttpClient() {
      return new httpClientST(stGroup);
   } 


   public httpClientChunkedRequestST newhttpClientChunkedRequest() {
      return new httpClientChunkedRequestST(stGroup);
   } 


   public httpClientContinueHandlingST newhttpClientContinueHandling() {
      return new httpClientContinueHandlingST(stGroup);
   } 


   public httpClientEndRequestST newhttpClientEndRequest() {
      return new httpClientEndRequestST(stGroup);
   } 


   public httpClientEndRequestBufferST newhttpClientEndRequestBuffer() {
      return new httpClientEndRequestBufferST(stGroup);
   } 


   public httpClientHandleExceptionST newhttpClientHandleException() {
      return new httpClientHandleExceptionST(stGroup);
   } 


   public httpClientHandleExceptionResponseST newhttpClientHandleExceptionResponse() {
      return new httpClientHandleExceptionResponseST(stGroup);
   } 


   public httpClientOptionsST newhttpClientOptions() {
      return new httpClientOptionsST(stGroup);
   } 


   public httpClientPumpFileST newhttpClientPumpFile() {
      return new httpClientPumpFileST(stGroup);
   } 


   public httpClientPutRequestHeadersST newhttpClientPutRequestHeaders() {
      return new httpClientPutRequestHeadersST(stGroup);
   } 


   public httpClientRequestTimeoutST newhttpClientRequestTimeout() {
      return new httpClientRequestTimeoutST(stGroup);
   } 


   public httpClientResponseBodyChunkST newhttpClientResponseBodyChunk() {
      return new httpClientResponseBodyChunkST(stGroup);
   } 


   public httpClientResponseBodyHandlerST newhttpClientResponseBodyHandler() {
      return new httpClientResponseBodyHandlerST(stGroup);
   } 


   public httpClientResponseHandlerST newhttpClientResponseHandler() {
      return new httpClientResponseHandlerST(stGroup);
   } 


   public httpClientResponseHeadersST newhttpClientResponseHeaders() {
      return new httpClientResponseHeadersST(stGroup);
   } 


   public httpClientResponseInMemoryST newhttpClientResponseInMemory() {
      return new httpClientResponseInMemoryST(stGroup);
   } 


   public httpClientSetRequestHeadersST newhttpClientSetRequestHeaders() {
      return new httpClientSetRequestHeadersST(stGroup);
   } 


   public httpClientWriteToRequestST newhttpClientWriteToRequest() {
      return new httpClientWriteToRequestST(stGroup);
   } 


   public httpResponseEndST newhttpResponseEnd() {
      return new httpResponseEndST(stGroup);
   } 


   public httpResponsePutHeaderST newhttpResponsePutHeader() {
      return new httpResponsePutHeaderST(stGroup);
   } 


   public httpResponsePutTrailersST newhttpResponsePutTrailers() {
      return new httpResponsePutTrailersST(stGroup);
   } 


   public httpResponseSTartST newhttpResponseSTart() {
      return new httpResponseSTartST(stGroup);
   } 


   public httpResponseSetHeaderST newhttpResponseSetHeader() {
      return new httpResponseSetHeaderST(stGroup);
   } 


   public httpResponseSetTrailersST newhttpResponseSetTrailers() {
      return new httpResponseSetTrailersST(stGroup);
   } 


   public httpResponseWriteST newhttpResponseWrite() {
      return new httpResponseWriteST(stGroup);
   } 


   public httpServeFileST newhttpServeFile() {
      return new httpServeFileST(stGroup);
   } 


   public httpServerST newhttpServer() {
      return new httpServerST(stGroup);
   } 


   public httpServerIncomingST newhttpServerIncoming() {
      return new httpServerIncomingST(stGroup);
   } 


   public httpServerListenHandlerST newhttpServerListenHandler() {
      return new httpServerListenHandlerST(stGroup);
   } 


   public httpServerPartialFileST newhttpServerPartialFile() {
      return new httpServerPartialFileST(stGroup);
   } 


   public inMemoryBodyAggrST newinMemoryBodyAggr() {
      return new inMemoryBodyAggrST(stGroup);
   } 


   public inMemoryBodyAggrShortST newinMemoryBodyAggrShort() {
      return new inMemoryBodyAggrShortST(stGroup);
   } 


   public isolateVerticleDeploymentST newisolateVerticleDeployment() {
      return new isolateVerticleDeploymentST(stGroup);
   } 


   public jsonST newjson() {
      return new jsonST(stGroup);
   } 


   public jsonFromStringST newjsonFromString() {
      return new jsonFromStringST(stGroup);
   } 


   public jsonGetIntegerST newjsonGetInteger() {
      return new jsonGetIntegerST(stGroup);
   } 


   public jsonGetStringST newjsonGetString() {
      return new jsonGetStringST(stGroup);
   } 


   public leaveMulticastGroupST newleaveMulticastGroup() {
      return new leaveMulticastGroupST(stGroup);
   } 


   public localSharedMapST newlocalSharedMap() {
      return new localSharedMapST(stGroup);
   } 


   public messageCodecST newmessageCodec() {
      return new messageCodecST(stGroup);
   } 


   public messageHandlerST newmessageHandler() {
      return new messageHandlerST(stGroup);
   } 


   public messageHeadersST newmessageHeaders() {
      return new messageHeadersST(stGroup);
   } 


   public multipleServersCommandLineST newmultipleServersCommandLine() {
      return new multipleServersCommandLineST(stGroup);
   } 


   public multipleServersProgrammaticallyST newmultipleServersProgrammatically() {
      return new multipleServersProgrammaticallyST(stGroup);
   } 


   public multpileServersVerticleST newmultpileServersVerticle() {
      return new multpileServersVerticleST(stGroup);
   } 


   public mvnST newmvn() {
      return new mvnST(stGroup);
   } 


   public mvnAuthShiroST newmvnAuthShiro() {
      return new mvnAuthShiroST(stGroup);
   } 


   public mvnDropwizardMetricsST newmvnDropwizardMetrics() {
      return new mvnDropwizardMetricsST(stGroup);
   } 


   public mvnJunitST newmvnJunit() {
      return new mvnJunitST(stGroup);
   } 


   public newAsynchVerticleST newnewAsynchVerticle() {
      return new newAsynchVerticleST(stGroup);
   } 


   public newBufferST newnewBuffer() {
      return new newBufferST(stGroup);
   } 


   public newBufferByteST newnewBufferByte() {
      return new newBufferByteST(stGroup);
   } 


   public newBufferSizeST newnewBufferSize() {
      return new newBufferSizeST(stGroup);
   } 


   public newBufferStringST newnewBufferString() {
      return new newBufferStringST(stGroup);
   } 


   public newBufferStringEncodedST newnewBufferStringEncoded() {
      return new newBufferStringEncodedST(stGroup);
   } 


   public newDatagramSocketST newnewDatagramSocket() {
      return new newDatagramSocketST(stGroup);
   } 


   public newEventBusST newnewEventBus() {
      return new newEventBusST(stGroup);
   } 


   public newJsonArrayST newnewJsonArray() {
      return new newJsonArrayST(stGroup);
   } 


   public newTCPClientST newnewTCPClient() {
      return new newTCPClientST(stGroup);
   } 


   public newTcpServerST newnewTcpServer() {
      return new newTcpServerST(stGroup);
   } 


   public oneShotTimerST newoneShotTimer() {
      return new oneShotTimerST(stGroup);
   } 


   public periodicTimerST newperiodicTimer() {
      return new periodicTimerST(stGroup);
   } 


   public postWriteST newpostWrite() {
      return new postWriteST(stGroup);
   } 


   public publishMessageST newpublishMessage() {
      return new publishMessageST(stGroup);
   } 


   public pumpResponseST newpumpResponse() {
      return new pumpResponseST(stGroup);
   } 


   public pumpStreamsST newpumpStreams() {
      return new pumpStreamsST(stGroup);
   } 


   public putDataInMapST newputDataInMap() {
      return new putDataInMapST(stGroup);
   } 


   public putJsonST newputJson() {
      return new putJsonST(stGroup);
   } 


   public randomAccessBufferWriteST newrandomAccessBufferWrite() {
      return new randomAccessBufferWriteST(stGroup);
   } 


   public randomAccessReadST newrandomAccessRead() {
      return new randomAccessReadST(stGroup);
   } 


   public randomAccessWriteST newrandomAccessWrite() {
      return new randomAccessWriteST(stGroup);
   } 


   public readBufferST newreadBuffer() {
      return new readBufferST(stGroup);
   } 


   public readFileAsynchST newreadFileAsynch() {
      return new readFileAsynchST(stGroup);
   } 


   public readSocketDataST newreadSocketData() {
      return new readSocketDataST(stGroup);
   } 


   public readUnsignedNumberST newreadUnsignedNumber() {
      return new readUnsignedNumberST(stGroup);
   } 


   public receiveDatagramPacketST newreceiveDatagramPacket() {
      return new receiveDatagramPacketST(stGroup);
   } 


   public receiveMulticastST newreceiveMulticast() {
      return new receiveMulticastST(stGroup);
   } 


   public recordParserST newrecordParser() {
      return new recordParserST(stGroup);
   } 


   public recordParserFixedST newrecordParserFixed() {
      return new recordParserFixedST(stGroup);
   } 


   public registerHandlerST newregisterHandler() {
      return new registerHandlerST(stGroup);
   } 


   public replyMessageST newreplyMessage() {
      return new replyMessageST(stGroup);
   } 


   public replyReceivedMessageST newreplyReceivedMessage() {
      return new replyReceivedMessageST(stGroup);
   } 


   public requestHandlerST newrequestHandler() {
      return new requestHandlerST(stGroup);
   } 


   public retriveContextST newretriveContext() {
      return new retriveContextST(stGroup);
   } 


   public revokateAuthST newrevokateAuth() {
      return new revokateAuthST(stGroup);
   } 


   public revokateAuthBufferST newrevokateAuthBuffer() {
      return new revokateAuthBufferST(stGroup);
   } 


   public runInContextST newrunInContext() {
      return new runInContextST(stGroup);
   } 


   public sendFileST newsendFile() {
      return new sendFileST(stGroup);
   } 


   public sendMessageST newsendMessage() {
      return new sendMessageST(stGroup);
   } 


   public sendMulticastST newsendMulticast() {
      return new sendMulticastST(stGroup);
   } 


   public serverConnectionHandlerST newserverConnectionHandler() {
      return new serverConnectionHandlerST(stGroup);
   } 


   public serverListenHandlerST newserverListenHandler() {
      return new serverListenHandlerST(stGroup);
   } 


   public serverSSLBufferConfigurationST newserverSSLBufferConfiguration() {
      return new serverSSLBufferConfigurationST(stGroup);
   } 


   public serverSSLKeystoreST newserverSSLKeystore() {
      return new serverSSLKeystoreST(stGroup);
   } 


   public serverSSLKeystoreBuffST newserverSSLKeystoreBuff() {
      return new serverSSLKeystoreBuffST(stGroup);
   } 


   public serverSSLPEMST newserverSSLPEM() {
      return new serverSSLPEMST(stGroup);
   } 


   public serverSSLPEMAuthorityST newserverSSLPEMAuthority() {
      return new serverSSLPEMAuthorityST(stGroup);
   } 


   public serverSSLPEMAuthorityBufferST newserverSSLPEMAuthorityBuffer() {
      return new serverSSLPEMAuthorityBufferST(stGroup);
   } 


   public serverSSLPEMBufferST newserverSSLPEMBuffer() {
      return new serverSSLPEMBufferST(stGroup);
   } 


   public serverSSLPKCS_12ST newserverSSLPKCS_12() {
      return new serverSSLPKCS_12ST(stGroup);
   } 


   public serverSSLPKCS_12AuthorityST newserverSSLPKCS_12Authority() {
      return new serverSSLPKCS_12AuthorityST(stGroup);
   } 


   public serverSSLPKCS_12AuthorityBufferST newserverSSLPKCS_12AuthorityBuffer() {
      return new serverSSLPKCS_12AuthorityBufferST(stGroup);
   } 


   public serverSSLTrustAuthorityST newserverSSLTrustAuthority() {
      return new serverSSLTrustAuthorityST(stGroup);
   } 


   public serverSSLTrustAuthorityBufferST newserverSSLTrustAuthorityBuffer() {
      return new serverSSLTrustAuthorityBufferST(stGroup);
   } 


   public simpleWriteRequestST newsimpleWriteRequest() {
      return new simpleWriteRequestST(stGroup);
   } 


   public socketClosedHandlerST newsocketClosedHandler() {
      return new socketClosedHandlerST(stGroup);
   } 


   public undeployVerticlesST newundeployVerticles() {
      return new undeployVerticlesST(stGroup);
   } 


   public verticleST newverticle() {
      return new verticleST(stGroup);
   } 


   public verticleConfigurationST newverticleConfiguration() {
      return new verticleConfigurationST(stGroup);
   } 


   public verticleInstancesST newverticleInstances() {
      return new verticleInstancesST(stGroup);
   } 


   public vertxST newvertx() {
      return new vertxST(stGroup);
   } 


   public vertxOptionsST newvertxOptions() {
      return new vertxOptionsST(stGroup);
   } 


   public websocketFrameWriteST newwebsocketFrameWrite() {
      return new websocketFrameWriteST(stGroup);
   } 


   public websocketHandlerST newwebsocketHandler() {
      return new websocketHandlerST(stGroup);
   } 


   public websocketReadFrameST newwebsocketReadFrame() {
      return new websocketReadFrameST(stGroup);
   } 


   public websocketSingleFrameWriteST newwebsocketSingleFrameWrite() {
      return new websocketSingleFrameWriteST(stGroup);
   } 


   public websocketUpgradeST newwebsocketUpgrade() {
      return new websocketUpgradeST(stGroup);
   } 


   public websocketWriteST newwebsocketWrite() {
      return new websocketWriteST(stGroup);
   } 


   public workerVerticleST newworkerVerticle() {
      return new workerVerticleST(stGroup);
   } 


   public writeFileAsynchST newwriteFileAsynch() {
      return new writeFileAsynchST(stGroup);
   } 


   public writeSocketDataST newwriteSocketData() {
      return new writeSocketDataST(stGroup);
   } 

    public final class appendBufferST {

      private final ST template;

      private appendBufferST(STGroup group) {
   		template = group.getInstanceOf("appendBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class asynchFileST {

      private final ST template;

      private asynchFileST(STGroup group) {
   		template = group.getInstanceOf("asynchFile");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class asynchVerticleStopST {

      private final ST template;

      private asynchVerticleStopST(STGroup group) {
   		template = group.getInstanceOf("asynchVerticleStop");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class blockMulticastST {

      private final ST template;

      private blockMulticastST(STGroup group) {
   		template = group.getInstanceOf("blockMulticast");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class blockingCodeST {

      private final AtomicBoolean resultIsSet = new AtomicBoolean(false);
      private final AtomicBoolean resultHandlerIsSet = new AtomicBoolean(false);
      private final AtomicBoolean statementsIsSet = new AtomicBoolean(false);
      private final ST template;

      private blockingCodeST(STGroup group) {
   		template = group.getInstanceOf("blockingCode");
   	}

       public blockingCodeST setResult(Object value) {
      	tryToSetStringProperty(template, value, resultIsSet, "result");   
         return this;
      } 
       public blockingCodeST setResultHandler(Object value) {
      	tryToSetStringProperty(template, value, resultHandlerIsSet, "resultHandler");   
         return this;
      } 
      public blockingCodeST addStatementsValue(Object value) {
      	tryToSetListProperty(template, value, statementsIsSet, "statements");
         return this;
      }

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class bodyHandlerST {

      private final ST template;

      private bodyHandlerST(STGroup group) {
   		template = group.getInstanceOf("bodyHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class bufCopyST {

      private final ST template;

      private bufCopyST(STGroup group) {
   		template = group.getInstanceOf("bufCopy");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class bufLengthST {

      private final ST template;

      private bufLengthST(STGroup group) {
   		template = group.getInstanceOf("bufLength");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class bufSliceST {

      private final ST template;

      private bufSliceST(STGroup group) {
   		template = group.getInstanceOf("bufSlice");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class bugfixST {

      private final ST template;

      private bugfixST(STGroup group) {
   		template = group.getInstanceOf("bugfix");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class cancelTimerST {

      private final ST template;

      private cancelTimerST(STGroup group) {
   		template = group.getInstanceOf("cancelTimer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class checkExistenceAndDeleteST {

      private final ST template;

      private checkExistenceAndDeleteST(STGroup group) {
   		template = group.getInstanceOf("checkExistenceAndDelete");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class chunkFileUploadHandlerST {

      private final ST template;

      private chunkFileUploadHandlerST(STGroup group) {
   		template = group.getInstanceOf("chunkFileUploadHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientConnectST {

      private final ST template;

      private clientConnectST(STGroup group) {
   		template = group.getInstanceOf("clientConnect");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientRequestST {

      private final AtomicBoolean clientIsSet = new AtomicBoolean(false);
      private final AtomicBoolean contentIsSet = new AtomicBoolean(false);
      private final AtomicBoolean handleBodyIsSet = new AtomicBoolean(false);
      private final AtomicBoolean handleResponseIsSet = new AtomicBoolean(false);
      private final AtomicBoolean headersIsSet = new AtomicBoolean(false);
      private final AtomicBoolean httpMethodIsSet = new AtomicBoolean(false);
      private final AtomicBoolean uriIsSet = new AtomicBoolean(false);
      private final ST template;

      private clientRequestST(STGroup group) {
   		template = group.getInstanceOf("clientRequest");
   	}

       public clientRequestST setClient(Object value) {
      	tryToSetStringProperty(template, value, clientIsSet, "client");   
         return this;
      } 
       public clientRequestST setContent(Object value) {
      	tryToSetStringProperty(template, value, contentIsSet, "content");   
         return this;
      } 
       public clientRequestST setHandleBody(Object value) {
      	tryToSetStringProperty(template, value, handleBodyIsSet, "handleBody");   
         return this;
      } 
       public clientRequestST setHandleResponse(Object value) {
      	tryToSetStringProperty(template, value, handleResponseIsSet, "handleResponse");   
         return this;
      } 
      public clientRequestST addHeadersValue(Object name_, Object value_) {
         headersIsSet.set(true);
         template.addAggr("headers.{name, value}", ( (name_==null || name_.toString().length()==0) ? null : name_), ( (value_==null || value_.toString().length()==0) ? null : value_));
         return this;
      }
       public clientRequestST setHttpMethod(Object value) {
      	tryToSetStringProperty(template, value, httpMethodIsSet, "httpMethod");   
         return this;
      } 
       public clientRequestST setUri(Object value) {
      	tryToSetStringProperty(template, value, uriIsSet, "uri");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLST {

      private final ST template;

      private clientSSLST(STGroup group) {
   		template = group.getInstanceOf("clientSSL");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLKeystoreAuthST {

      private final ST template;

      private clientSSLKeystoreAuthST(STGroup group) {
   		template = group.getInstanceOf("clientSSLKeystoreAuth");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLKeystoreAuthBufferST {

      private final ST template;

      private clientSSLKeystoreAuthBufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLKeystoreAuthBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPEMST {

      private final ST template;

      private clientSSLPEMST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPEM");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPEMAuthST {

      private final ST template;

      private clientSSLPEMAuthST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPEMAuth");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPEMAuthBufferST {

      private final ST template;

      private clientSSLPEMAuthBufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPEMAuthBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPEMBufferST {

      private final ST template;

      private clientSSLPEMBufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPEMBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPKCSAuthST {

      private final ST template;

      private clientSSLPKCSAuthST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPKCSAuth");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPKCSAuthBufferST {

      private final ST template;

      private clientSSLPKCSAuthBufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPKCSAuthBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPKCS_12ST {

      private final ST template;

      private clientSSLPKCS_12ST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPKCS_12");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLPKCS_12BufferST {

      private final ST template;

      private clientSSLPKCS_12BufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLPKCS_12Buffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLTruststoreST {

      private final ST template;

      private clientSSLTruststoreST(STGroup group) {
   		template = group.getInstanceOf("clientSSLTruststore");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientSSLTruststoreBufferST {

      private final ST template;

      private clientSSLTruststoreBufferST(STGroup group) {
   		template = group.getInstanceOf("clientSSLTruststoreBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clientWebsocketST {

      private final ST template;

      private clientWebsocketST(STGroup group) {
   		template = group.getInstanceOf("clientWebsocket");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class closeServerST {

      private final ST template;

      private closeServerST(STGroup group) {
   		template = group.getInstanceOf("closeServer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterCommandLineST {

      private final ST template;

      private clusterCommandLineST(STGroup group) {
   		template = group.getInstanceOf("clusterCommandLine");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterCounterST {

      private final ST template;

      private clusterCounterST(STGroup group) {
   		template = group.getInstanceOf("clusterCounter");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterProgrammaticallyST {

      private final ST template;

      private clusterProgrammaticallyST(STGroup group) {
   		template = group.getInstanceOf("clusterProgrammatically");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterSharedMapST {

      private final ST template;

      private clusterSharedMapST(STGroup group) {
   		template = group.getInstanceOf("clusterSharedMap");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterWideLockST {

      private final ST template;

      private clusterWideLockST(STGroup group) {
   		template = group.getInstanceOf("clusterWideLock");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class clusterWideLockTimeoutST {

      private final ST template;

      private clusterWideLockTimeoutST(STGroup group) {
   		template = group.getInstanceOf("clusterWideLockTimeout");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class cmdHighAvailabilityST {

      private final ST template;

      private cmdHighAvailabilityST(STGroup group) {
   		template = group.getInstanceOf("cmdHighAvailability");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class cmdRunVerticlesST {

      private final ST template;

      private cmdRunVerticlesST(STGroup group) {
   		template = group.getInstanceOf("cmdRunVerticles");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class configGetIntegerST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final ST template;

      private configGetIntegerST(STGroup group) {
   		template = group.getInstanceOf("configGetInteger");
   	}

       public configGetIntegerST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class configGetStringST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final ST template;

      private configGetStringST(STGroup group) {
   		template = group.getInstanceOf("configGetString");
   	}

       public configGetStringST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class configureCipherSuiteST {

      private final ST template;

      private configureCipherSuiteST(STGroup group) {
   		template = group.getInstanceOf("configureCipherSuite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class consumerCompletionHandlerST {

      private final ST template;

      private consumerCompletionHandlerST(STGroup group) {
   		template = group.getInstanceOf("consumerCompletionHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class contextSharedDataST {

      private final ST template;

      private contextSharedDataST(STGroup group) {
   		template = group.getInstanceOf("contextSharedData");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class contextTypeST {

      private final ST template;

      private contextTypeST(STGroup group) {
   		template = group.getInstanceOf("contextType");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class copyFileAsynchST {

      private final ST template;

      private copyFileAsynchST(STGroup group) {
   		template = group.getInstanceOf("copyFileAsynch");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class copyFileSynchST {

      private final ST template;

      private copyFileSynchST(STGroup group) {
   		template = group.getInstanceOf("copyFileSynch");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class deployPolyVerticlesST {

      private final ST template;

      private deployPolyVerticlesST(STGroup group) {
   		template = group.getInstanceOf("deployPolyVerticles");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class deployVerticleProgrammaticallyST {

      private final AtomicBoolean onFailIsSet = new AtomicBoolean(false);
      private final AtomicBoolean onSuccessIsSet = new AtomicBoolean(false);
      private final AtomicBoolean optionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean typeIsSet = new AtomicBoolean(false);
      private final ST template;

      private deployVerticleProgrammaticallyST(STGroup group) {
   		template = group.getInstanceOf("deployVerticleProgrammatically");
   	}

       public deployVerticleProgrammaticallyST setOnFail(Object value) {
      	tryToSetStringProperty(template, value, onFailIsSet, "onFail");   
         return this;
      } 
       public deployVerticleProgrammaticallyST setOnSuccess(Object value) {
      	tryToSetStringProperty(template, value, onSuccessIsSet, "onSuccess");   
         return this;
      } 
       public deployVerticleProgrammaticallyST setOptions(Object value) {
      	tryToSetStringProperty(template, value, optionsIsSet, "options");   
         return this;
      } 
       public deployVerticleProgrammaticallyST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
       public deployVerticleProgrammaticallyST setType(Object value) {
      	tryToSetStringProperty(template, value, typeIsSet, "type");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class deployVerticleStartST {

      private final AtomicBoolean configIsSet = new AtomicBoolean(false);
      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean onSuccessIsSet = new AtomicBoolean(false);
      private final ST template;

      private deployVerticleStartST(STGroup group) {
   		template = group.getInstanceOf("deployVerticleStart");
   	}

       public deployVerticleStartST setConfig(Object value) {
      	tryToSetStringProperty(template, value, configIsSet, "config");   
         return this;
      } 
       public deployVerticleStartST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public deployVerticleStartST setOnSuccess(Object value) {
      	tryToSetStringProperty(template, value, onSuccessIsSet, "onSuccess");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsClientST {

      private final ST template;

      private dnsClientST(STGroup group) {
   		template = group.getInstanceOf("dnsClient");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsLookupST {

      private final ST template;

      private dnsLookupST(STGroup group) {
   		template = group.getInstanceOf("dnsLookup");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsLookup4ST {

      private final ST template;

      private dnsLookup4ST(STGroup group) {
   		template = group.getInstanceOf("dnsLookup4");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsLookup6ST {

      private final ST template;

      private dnsLookup6ST(STGroup group) {
   		template = group.getInstanceOf("dnsLookup6");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveAST {

      private final ST template;

      private dnsResolveAST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveA");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveAAAAST {

      private final ST template;

      private dnsResolveAAAAST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveAAAA");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveCNAMEST {

      private final ST template;

      private dnsResolveCNAMEST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveCNAME");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveMXST {

      private final ST template;

      private dnsResolveMXST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveMX");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveNSST {

      private final ST template;

      private dnsResolveNSST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveNS");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolvePTRST {

      private final ST template;

      private dnsResolvePTRST(STGroup group) {
   		template = group.getInstanceOf("dnsResolvePTR");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveSRVST {

      private final ST template;

      private dnsResolveSRVST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveSRV");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResolveTXTST {

      private final ST template;

      private dnsResolveTXTST(STGroup group) {
   		template = group.getInstanceOf("dnsResolveTXT");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsResponseCodeST {

      private final ST template;

      private dnsResponseCodeST(STGroup group) {
   		template = group.getInstanceOf("dnsResponseCode");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class dnsReverseLookupST {

      private final ST template;

      private dnsReverseLookupST(STGroup group) {
   		template = group.getInstanceOf("dnsReverseLookup");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class ebConsumeST {

      private final AtomicBoolean addressIsSet = new AtomicBoolean(false);
      private final AtomicBoolean onMessageIsSet = new AtomicBoolean(false);
      private final ST template;

      private ebConsumeST(STGroup group) {
   		template = group.getInstanceOf("ebConsume");
   	}

       public ebConsumeST setAddress(Object value) {
      	tryToSetStringProperty(template, value, addressIsSet, "address");   
         return this;
      } 
       public ebConsumeST setOnMessage(Object value) {
      	tryToSetStringProperty(template, value, onMessageIsSet, "onMessage");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class ebPublishST {

      private final AtomicBoolean addressIsSet = new AtomicBoolean(false);
      private final AtomicBoolean valueIsSet = new AtomicBoolean(false);
      private final ST template;

      private ebPublishST(STGroup group) {
   		template = group.getInstanceOf("ebPublish");
   	}

       public ebPublishST setAddress(Object value) {
      	tryToSetStringProperty(template, value, addressIsSet, "address");   
         return this;
      } 
       public ebPublishST setValue(Object value) {
      	tryToSetStringProperty(template, value, valueIsSet, "value");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class encodeArrayST {

      private final ST template;

      private encodeArrayST(STGroup group) {
   		template = group.getInstanceOf("encodeArray");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class fileStreamST {

      private final ST template;

      private fileStreamST(STGroup group) {
   		template = group.getInstanceOf("fileStream");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class formFileStreamUploadST {

      private final ST template;

      private formFileStreamUploadST(STGroup group) {
   		template = group.getInstanceOf("formFileStreamUpload");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class formFileUploadHandlerST {

      private final ST template;

      private formFileUploadHandlerST(STGroup group) {
   		template = group.getInstanceOf("formFileUploadHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class formHandlerST {

      private final ST template;

      private formHandlerST(STGroup group) {
   		template = group.getInstanceOf("formHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class getDataFromMapST {

      private final ST template;

      private getDataFromMapST(STGroup group) {
   		template = group.getInstanceOf("getDataFromMap");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class getJsonST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean typeIsSet = new AtomicBoolean(false);
      private final ST template;

      private getJsonST(STGroup group) {
   		template = group.getInstanceOf("getJson");
   	}

       public getJsonST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public getJsonST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
       public getJsonST setType(Object value) {
      	tryToSetStringProperty(template, value, typeIsSet, "type");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class getJsonArrayST {

      private final ST template;

      private getJsonArrayST(STGroup group) {
   		template = group.getInstanceOf("getJsonArray");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class getRequestHeadersST {

      private final ST template;

      private getRequestHeadersST(STGroup group) {
   		template = group.getInstanceOf("getRequestHeaders");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientST {

      private final AtomicBoolean clientOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final ST template;

      private httpClientST(STGroup group) {
   		template = group.getInstanceOf("httpClient");
   	}

       public httpClientST setClientOptions(Object value) {
      	tryToSetStringProperty(template, value, clientOptionsIsSet, "clientOptions");   
         return this;
      } 
       public httpClientST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientChunkedRequestST {

      private final ST template;

      private httpClientChunkedRequestST(STGroup group) {
   		template = group.getInstanceOf("httpClientChunkedRequest");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientContinueHandlingST {

      private final ST template;

      private httpClientContinueHandlingST(STGroup group) {
   		template = group.getInstanceOf("httpClientContinueHandling");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientEndRequestST {

      private final ST template;

      private httpClientEndRequestST(STGroup group) {
   		template = group.getInstanceOf("httpClientEndRequest");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientEndRequestBufferST {

      private final ST template;

      private httpClientEndRequestBufferST(STGroup group) {
   		template = group.getInstanceOf("httpClientEndRequestBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientHandleExceptionST {

      private final ST template;

      private httpClientHandleExceptionST(STGroup group) {
   		template = group.getInstanceOf("httpClientHandleException");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientHandleExceptionResponseST {

      private final ST template;

      private httpClientHandleExceptionResponseST(STGroup group) {
   		template = group.getInstanceOf("httpClientHandleExceptionResponse");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientOptionsST {

      private final AtomicBoolean connectTimeoutIsSet = new AtomicBoolean(false);
      private final AtomicBoolean defaultHostIsSet = new AtomicBoolean(false);
      private final AtomicBoolean defaultPortIsSet = new AtomicBoolean(false);
      private final AtomicBoolean idleTimeoutIsSet = new AtomicBoolean(false);
      private final AtomicBoolean keepAliveIsSet = new AtomicBoolean(false);
      private final AtomicBoolean keyStoreOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean maxPoolSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean maxWebsocketFrameSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean pemKeyCertOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean pemTrustOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean pfxKeycertOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean pfxTrustOptionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean pipeliningIsSet = new AtomicBoolean(false);
      private final AtomicBoolean protocolVersionIsSet = new AtomicBoolean(false);
      private final AtomicBoolean receiveBufferSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean reuseAddressIsSet = new AtomicBoolean(false);
      private final AtomicBoolean sendBufferSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean soLingerIsSet = new AtomicBoolean(false);
      private final AtomicBoolean sslIsSet = new AtomicBoolean(false);
      private final AtomicBoolean tcpKeepAliveIsSet = new AtomicBoolean(false);
      private final AtomicBoolean tcpNoDelayIsSet = new AtomicBoolean(false);
      private final AtomicBoolean trafficClassIsSet = new AtomicBoolean(false);
      private final AtomicBoolean trustAllIsSet = new AtomicBoolean(false);
      private final AtomicBoolean trustStoreIsSet = new AtomicBoolean(false);
      private final AtomicBoolean tryUseCompressionIsSet = new AtomicBoolean(false);
      private final AtomicBoolean usePooledBuffersIsSet = new AtomicBoolean(false);
      private final AtomicBoolean verifyHostIsSet = new AtomicBoolean(false);
      private final ST template;

      private httpClientOptionsST(STGroup group) {
   		template = group.getInstanceOf("httpClientOptions");
   	}

       public httpClientOptionsST setConnectTimeout(Object value) {
      	tryToSetStringProperty(template, value, connectTimeoutIsSet, "connectTimeout");   
         return this;
      } 
       public httpClientOptionsST setDefaultHost(Object value) {
      	tryToSetStringProperty(template, value, defaultHostIsSet, "defaultHost");   
         return this;
      } 
       public httpClientOptionsST setDefaultPort(Object value) {
      	tryToSetStringProperty(template, value, defaultPortIsSet, "defaultPort");   
         return this;
      } 
       public httpClientOptionsST setIdleTimeout(Object value) {
      	tryToSetStringProperty(template, value, idleTimeoutIsSet, "idleTimeout");   
         return this;
      } 
       public httpClientOptionsST setKeepAlive(Object value) {
      	tryToSetStringProperty(template, value, keepAliveIsSet, "keepAlive");   
         return this;
      } 
       public httpClientOptionsST setKeyStoreOptions(Object value) {
      	tryToSetStringProperty(template, value, keyStoreOptionsIsSet, "keyStoreOptions");   
         return this;
      } 
       public httpClientOptionsST setMaxPoolSize(Object value) {
      	tryToSetStringProperty(template, value, maxPoolSizeIsSet, "maxPoolSize");   
         return this;
      } 
       public httpClientOptionsST setMaxWebsocketFrameSize(Object value) {
      	tryToSetStringProperty(template, value, maxWebsocketFrameSizeIsSet, "maxWebsocketFrameSize");   
         return this;
      } 
       public httpClientOptionsST setPemKeyCertOptions(Object value) {
      	tryToSetStringProperty(template, value, pemKeyCertOptionsIsSet, "pemKeyCertOptions");   
         return this;
      } 
       public httpClientOptionsST setPemTrustOptions(Object value) {
      	tryToSetStringProperty(template, value, pemTrustOptionsIsSet, "pemTrustOptions");   
         return this;
      } 
       public httpClientOptionsST setPfxKeycertOptions(Object value) {
      	tryToSetStringProperty(template, value, pfxKeycertOptionsIsSet, "pfxKeycertOptions");   
         return this;
      } 
       public httpClientOptionsST setPfxTrustOptions(Object value) {
      	tryToSetStringProperty(template, value, pfxTrustOptionsIsSet, "pfxTrustOptions");   
         return this;
      } 
       public httpClientOptionsST setPipelining(Object value) {
      	tryToSetStringProperty(template, value, pipeliningIsSet, "pipelining");   
         return this;
      } 
       public httpClientOptionsST setProtocolVersion(Object value) {
      	tryToSetStringProperty(template, value, protocolVersionIsSet, "protocolVersion");   
         return this;
      } 
       public httpClientOptionsST setReceiveBufferSize(Object value) {
      	tryToSetStringProperty(template, value, receiveBufferSizeIsSet, "receiveBufferSize");   
         return this;
      } 
       public httpClientOptionsST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
       public httpClientOptionsST setReuseAddress(Object value) {
      	tryToSetStringProperty(template, value, reuseAddressIsSet, "reuseAddress");   
         return this;
      } 
       public httpClientOptionsST setSendBufferSize(Object value) {
      	tryToSetStringProperty(template, value, sendBufferSizeIsSet, "sendBufferSize");   
         return this;
      } 
       public httpClientOptionsST setSoLinger(Object value) {
      	tryToSetStringProperty(template, value, soLingerIsSet, "soLinger");   
         return this;
      } 
       public httpClientOptionsST setSsl(Object value) {
      	tryToSetStringProperty(template, value, sslIsSet, "ssl");   
         return this;
      } 
       public httpClientOptionsST setTcpKeepAlive(Object value) {
      	tryToSetStringProperty(template, value, tcpKeepAliveIsSet, "tcpKeepAlive");   
         return this;
      } 
       public httpClientOptionsST setTcpNoDelay(Object value) {
      	tryToSetStringProperty(template, value, tcpNoDelayIsSet, "tcpNoDelay");   
         return this;
      } 
       public httpClientOptionsST setTrafficClass(Object value) {
      	tryToSetStringProperty(template, value, trafficClassIsSet, "trafficClass");   
         return this;
      } 
       public httpClientOptionsST setTrustAll(Object value) {
      	tryToSetStringProperty(template, value, trustAllIsSet, "trustAll");   
         return this;
      } 
       public httpClientOptionsST setTrustStore(Object value) {
      	tryToSetStringProperty(template, value, trustStoreIsSet, "trustStore");   
         return this;
      } 
       public httpClientOptionsST setTryUseCompression(Object value) {
      	tryToSetStringProperty(template, value, tryUseCompressionIsSet, "tryUseCompression");   
         return this;
      } 
       public httpClientOptionsST setUsePooledBuffers(Object value) {
      	tryToSetStringProperty(template, value, usePooledBuffersIsSet, "usePooledBuffers");   
         return this;
      } 
       public httpClientOptionsST setVerifyHost(Object value) {
      	tryToSetStringProperty(template, value, verifyHostIsSet, "verifyHost");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientPumpFileST {

      private final ST template;

      private httpClientPumpFileST(STGroup group) {
   		template = group.getInstanceOf("httpClientPumpFile");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientPutRequestHeadersST {

      private final ST template;

      private httpClientPutRequestHeadersST(STGroup group) {
   		template = group.getInstanceOf("httpClientPutRequestHeaders");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientRequestTimeoutST {

      private final ST template;

      private httpClientRequestTimeoutST(STGroup group) {
   		template = group.getInstanceOf("httpClientRequestTimeout");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientResponseBodyChunkST {

      private final ST template;

      private httpClientResponseBodyChunkST(STGroup group) {
   		template = group.getInstanceOf("httpClientResponseBodyChunk");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientResponseBodyHandlerST {

      private final ST template;

      private httpClientResponseBodyHandlerST(STGroup group) {
   		template = group.getInstanceOf("httpClientResponseBodyHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientResponseHandlerST {

      private final ST template;

      private httpClientResponseHandlerST(STGroup group) {
   		template = group.getInstanceOf("httpClientResponseHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientResponseHeadersST {

      private final ST template;

      private httpClientResponseHeadersST(STGroup group) {
   		template = group.getInstanceOf("httpClientResponseHeaders");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientResponseInMemoryST {

      private final ST template;

      private httpClientResponseInMemoryST(STGroup group) {
   		template = group.getInstanceOf("httpClientResponseInMemory");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientSetRequestHeadersST {

      private final ST template;

      private httpClientSetRequestHeadersST(STGroup group) {
   		template = group.getInstanceOf("httpClientSetRequestHeaders");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpClientWriteToRequestST {

      private final ST template;

      private httpClientWriteToRequestST(STGroup group) {
   		template = group.getInstanceOf("httpClientWriteToRequest");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponseEndST {

      private final ST template;

      private httpResponseEndST(STGroup group) {
   		template = group.getInstanceOf("httpResponseEnd");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponsePutHeaderST {

      private final ST template;

      private httpResponsePutHeaderST(STGroup group) {
   		template = group.getInstanceOf("httpResponsePutHeader");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponsePutTrailersST {

      private final ST template;

      private httpResponsePutTrailersST(STGroup group) {
   		template = group.getInstanceOf("httpResponsePutTrailers");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponseSTartST {

      private final ST template;

      private httpResponseSTartST(STGroup group) {
   		template = group.getInstanceOf("httpResponseSTart");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponseSetHeaderST {

      private final ST template;

      private httpResponseSetHeaderST(STGroup group) {
   		template = group.getInstanceOf("httpResponseSetHeader");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponseSetTrailersST {

      private final ST template;

      private httpResponseSetTrailersST(STGroup group) {
   		template = group.getInstanceOf("httpResponseSetTrailers");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpResponseWriteST {

      private final ST template;

      private httpResponseWriteST(STGroup group) {
   		template = group.getInstanceOf("httpResponseWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpServeFileST {

      private final ST template;

      private httpServeFileST(STGroup group) {
   		template = group.getInstanceOf("httpServeFile");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpServerST {

      private final ST template;

      private httpServerST(STGroup group) {
   		template = group.getInstanceOf("httpServer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpServerIncomingST {

      private final ST template;

      private httpServerIncomingST(STGroup group) {
   		template = group.getInstanceOf("httpServerIncoming");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpServerListenHandlerST {

      private final ST template;

      private httpServerListenHandlerST(STGroup group) {
   		template = group.getInstanceOf("httpServerListenHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class httpServerPartialFileST {

      private final ST template;

      private httpServerPartialFileST(STGroup group) {
   		template = group.getInstanceOf("httpServerPartialFile");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class inMemoryBodyAggrST {

      private final ST template;

      private inMemoryBodyAggrST(STGroup group) {
   		template = group.getInstanceOf("inMemoryBodyAggr");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class inMemoryBodyAggrShortST {

      private final ST template;

      private inMemoryBodyAggrShortST(STGroup group) {
   		template = group.getInstanceOf("inMemoryBodyAggrShort");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class isolateVerticleDeploymentST {

      private final ST template;

      private isolateVerticleDeploymentST(STGroup group) {
   		template = group.getInstanceOf("isolateVerticleDeployment");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class jsonST {

      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean valuesIsSet = new AtomicBoolean(false);
      private final ST template;

      private jsonST(STGroup group) {
   		template = group.getInstanceOf("json");
   	}

       public jsonST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
      public jsonST addValuesValue(Object key_, Object value_) {
         valuesIsSet.set(true);
         template.addAggr("values.{key, value}", ( (key_==null || key_.toString().length()==0) ? null : key_), ( (value_==null || value_.toString().length()==0) ? null : value_));
         return this;
      }

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class jsonFromStringST {

      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean stringIsSet = new AtomicBoolean(false);
      private final ST template;

      private jsonFromStringST(STGroup group) {
   		template = group.getInstanceOf("jsonFromString");
   	}

       public jsonFromStringST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
       public jsonFromStringST setString(Object value) {
      	tryToSetStringProperty(template, value, stringIsSet, "string");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class jsonGetIntegerST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final ST template;

      private jsonGetIntegerST(STGroup group) {
   		template = group.getInstanceOf("jsonGetInteger");
   	}

       public jsonGetIntegerST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public jsonGetIntegerST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class jsonGetStringST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final ST template;

      private jsonGetStringST(STGroup group) {
   		template = group.getInstanceOf("jsonGetString");
   	}

       public jsonGetStringST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public jsonGetStringST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class leaveMulticastGroupST {

      private final ST template;

      private leaveMulticastGroupST(STGroup group) {
   		template = group.getInstanceOf("leaveMulticastGroup");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class localSharedMapST {

      private final ST template;

      private localSharedMapST(STGroup group) {
   		template = group.getInstanceOf("localSharedMap");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class messageCodecST {

      private final ST template;

      private messageCodecST(STGroup group) {
   		template = group.getInstanceOf("messageCodec");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class messageHandlerST {

      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean packageNameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean statementIsSet = new AtomicBoolean(false);
      private final ST template;

      private messageHandlerST(STGroup group) {
   		template = group.getInstanceOf("messageHandler");
   	}

       public messageHandlerST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public messageHandlerST setPackageName(Object value) {
      	tryToSetStringProperty(template, value, packageNameIsSet, "packageName");   
         return this;
      } 
       public messageHandlerST setStatement(Object value) {
      	tryToSetStringProperty(template, value, statementIsSet, "statement");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class messageHeadersST {

      private final ST template;

      private messageHeadersST(STGroup group) {
   		template = group.getInstanceOf("messageHeaders");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class multipleServersCommandLineST {

      private final ST template;

      private multipleServersCommandLineST(STGroup group) {
   		template = group.getInstanceOf("multipleServersCommandLine");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class multipleServersProgrammaticallyST {

      private final ST template;

      private multipleServersProgrammaticallyST(STGroup group) {
   		template = group.getInstanceOf("multipleServersProgrammatically");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class multpileServersVerticleST {

      private final ST template;

      private multpileServersVerticleST(STGroup group) {
   		template = group.getInstanceOf("multpileServersVerticle");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class mvnST {

      private final ST template;

      private mvnST(STGroup group) {
   		template = group.getInstanceOf("mvn");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class mvnAuthShiroST {

      private final ST template;

      private mvnAuthShiroST(STGroup group) {
   		template = group.getInstanceOf("mvnAuthShiro");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class mvnDropwizardMetricsST {

      private final ST template;

      private mvnDropwizardMetricsST(STGroup group) {
   		template = group.getInstanceOf("mvnDropwizardMetrics");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class mvnJunitST {

      private final ST template;

      private mvnJunitST(STGroup group) {
   		template = group.getInstanceOf("mvnJunit");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newAsynchVerticleST {

      private final ST template;

      private newAsynchVerticleST(STGroup group) {
   		template = group.getInstanceOf("newAsynchVerticle");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newBufferST {

      private final ST template;

      private newBufferST(STGroup group) {
   		template = group.getInstanceOf("newBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newBufferByteST {

      private final ST template;

      private newBufferByteST(STGroup group) {
   		template = group.getInstanceOf("newBufferByte");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newBufferSizeST {

      private final ST template;

      private newBufferSizeST(STGroup group) {
   		template = group.getInstanceOf("newBufferSize");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newBufferStringST {

      private final ST template;

      private newBufferStringST(STGroup group) {
   		template = group.getInstanceOf("newBufferString");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newBufferStringEncodedST {

      private final ST template;

      private newBufferStringEncodedST(STGroup group) {
   		template = group.getInstanceOf("newBufferStringEncoded");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newDatagramSocketST {

      private final ST template;

      private newDatagramSocketST(STGroup group) {
   		template = group.getInstanceOf("newDatagramSocket");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newEventBusST {

      private final ST template;

      private newEventBusST(STGroup group) {
   		template = group.getInstanceOf("newEventBus");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newJsonArrayST {

      private final ST template;

      private newJsonArrayST(STGroup group) {
   		template = group.getInstanceOf("newJsonArray");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newTCPClientST {

      private final ST template;

      private newTCPClientST(STGroup group) {
   		template = group.getInstanceOf("newTCPClient");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class newTcpServerST {

      private final ST template;

      private newTcpServerST(STGroup group) {
   		template = group.getInstanceOf("newTcpServer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class oneShotTimerST {

      private final ST template;

      private oneShotTimerST(STGroup group) {
   		template = group.getInstanceOf("oneShotTimer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class periodicTimerST {

      private final AtomicBoolean msIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final AtomicBoolean statementsIsSet = new AtomicBoolean(false);
      private final ST template;

      private periodicTimerST(STGroup group) {
   		template = group.getInstanceOf("periodicTimer");
   	}

       public periodicTimerST setMs(Object value) {
      	tryToSetStringProperty(template, value, msIsSet, "ms");   
         return this;
      } 
       public periodicTimerST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 
      public periodicTimerST addStatementsValue(Object value) {
      	tryToSetListProperty(template, value, statementsIsSet, "statements");
         return this;
      }

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class postWriteST {

      private final ST template;

      private postWriteST(STGroup group) {
   		template = group.getInstanceOf("postWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class publishMessageST {

      private final ST template;

      private publishMessageST(STGroup group) {
   		template = group.getInstanceOf("publishMessage");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class pumpResponseST {

      private final ST template;

      private pumpResponseST(STGroup group) {
   		template = group.getInstanceOf("pumpResponse");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class pumpStreamsST {

      private final ST template;

      private pumpStreamsST(STGroup group) {
   		template = group.getInstanceOf("pumpStreams");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class putDataInMapST {

      private final ST template;

      private putDataInMapST(STGroup group) {
   		template = group.getInstanceOf("putDataInMap");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class putJsonST {

      private final ST template;

      private putJsonST(STGroup group) {
   		template = group.getInstanceOf("putJson");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class randomAccessBufferWriteST {

      private final ST template;

      private randomAccessBufferWriteST(STGroup group) {
   		template = group.getInstanceOf("randomAccessBufferWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class randomAccessReadST {

      private final ST template;

      private randomAccessReadST(STGroup group) {
   		template = group.getInstanceOf("randomAccessRead");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class randomAccessWriteST {

      private final ST template;

      private randomAccessWriteST(STGroup group) {
   		template = group.getInstanceOf("randomAccessWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class readBufferST {

      private final ST template;

      private readBufferST(STGroup group) {
   		template = group.getInstanceOf("readBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class readFileAsynchST {

      private final ST template;

      private readFileAsynchST(STGroup group) {
   		template = group.getInstanceOf("readFileAsynch");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class readSocketDataST {

      private final ST template;

      private readSocketDataST(STGroup group) {
   		template = group.getInstanceOf("readSocketData");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class readUnsignedNumberST {

      private final ST template;

      private readUnsignedNumberST(STGroup group) {
   		template = group.getInstanceOf("readUnsignedNumber");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class receiveDatagramPacketST {

      private final ST template;

      private receiveDatagramPacketST(STGroup group) {
   		template = group.getInstanceOf("receiveDatagramPacket");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class receiveMulticastST {

      private final ST template;

      private receiveMulticastST(STGroup group) {
   		template = group.getInstanceOf("receiveMulticast");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class recordParserST {

      private final ST template;

      private recordParserST(STGroup group) {
   		template = group.getInstanceOf("recordParser");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class recordParserFixedST {

      private final ST template;

      private recordParserFixedST(STGroup group) {
   		template = group.getInstanceOf("recordParserFixed");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class registerHandlerST {

      private final ST template;

      private registerHandlerST(STGroup group) {
   		template = group.getInstanceOf("registerHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class replyMessageST {

      private final ST template;

      private replyMessageST(STGroup group) {
   		template = group.getInstanceOf("replyMessage");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class replyReceivedMessageST {

      private final ST template;

      private replyReceivedMessageST(STGroup group) {
   		template = group.getInstanceOf("replyReceivedMessage");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class requestHandlerST {

      private final ST template;

      private requestHandlerST(STGroup group) {
   		template = group.getInstanceOf("requestHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class retriveContextST {

      private final ST template;

      private retriveContextST(STGroup group) {
   		template = group.getInstanceOf("retriveContext");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class revokateAuthST {

      private final ST template;

      private revokateAuthST(STGroup group) {
   		template = group.getInstanceOf("revokateAuth");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class revokateAuthBufferST {

      private final ST template;

      private revokateAuthBufferST(STGroup group) {
   		template = group.getInstanceOf("revokateAuthBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class runInContextST {

      private final AtomicBoolean statementsIsSet = new AtomicBoolean(false);
      private final ST template;

      private runInContextST(STGroup group) {
   		template = group.getInstanceOf("runInContext");
   	}

      public runInContextST addStatementsValue(Object value) {
      	tryToSetListProperty(template, value, statementsIsSet, "statements");
         return this;
      }

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class sendFileST {

      private final ST template;

      private sendFileST(STGroup group) {
   		template = group.getInstanceOf("sendFile");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class sendMessageST {

      private final ST template;

      private sendMessageST(STGroup group) {
   		template = group.getInstanceOf("sendMessage");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class sendMulticastST {

      private final ST template;

      private sendMulticastST(STGroup group) {
   		template = group.getInstanceOf("sendMulticast");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverConnectionHandlerST {

      private final ST template;

      private serverConnectionHandlerST(STGroup group) {
   		template = group.getInstanceOf("serverConnectionHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverListenHandlerST {

      private final ST template;

      private serverListenHandlerST(STGroup group) {
   		template = group.getInstanceOf("serverListenHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLBufferConfigurationST {

      private final ST template;

      private serverSSLBufferConfigurationST(STGroup group) {
   		template = group.getInstanceOf("serverSSLBufferConfiguration");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLKeystoreST {

      private final ST template;

      private serverSSLKeystoreST(STGroup group) {
   		template = group.getInstanceOf("serverSSLKeystore");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLKeystoreBuffST {

      private final ST template;

      private serverSSLKeystoreBuffST(STGroup group) {
   		template = group.getInstanceOf("serverSSLKeystoreBuff");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPEMST {

      private final ST template;

      private serverSSLPEMST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPEM");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPEMAuthorityST {

      private final ST template;

      private serverSSLPEMAuthorityST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPEMAuthority");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPEMAuthorityBufferST {

      private final ST template;

      private serverSSLPEMAuthorityBufferST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPEMAuthorityBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPEMBufferST {

      private final ST template;

      private serverSSLPEMBufferST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPEMBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPKCS_12ST {

      private final ST template;

      private serverSSLPKCS_12ST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPKCS_12");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPKCS_12AuthorityST {

      private final ST template;

      private serverSSLPKCS_12AuthorityST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPKCS_12Authority");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLPKCS_12AuthorityBufferST {

      private final ST template;

      private serverSSLPKCS_12AuthorityBufferST(STGroup group) {
   		template = group.getInstanceOf("serverSSLPKCS_12AuthorityBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLTrustAuthorityST {

      private final ST template;

      private serverSSLTrustAuthorityST(STGroup group) {
   		template = group.getInstanceOf("serverSSLTrustAuthority");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class serverSSLTrustAuthorityBufferST {

      private final ST template;

      private serverSSLTrustAuthorityBufferST(STGroup group) {
   		template = group.getInstanceOf("serverSSLTrustAuthorityBuffer");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class simpleWriteRequestST {

      private final ST template;

      private simpleWriteRequestST(STGroup group) {
   		template = group.getInstanceOf("simpleWriteRequest");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class socketClosedHandlerST {

      private final ST template;

      private socketClosedHandlerST(STGroup group) {
   		template = group.getInstanceOf("socketClosedHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class undeployVerticlesST {

      private final ST template;

      private undeployVerticlesST(STGroup group) {
   		template = group.getInstanceOf("undeployVerticles");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class verticleST {

      private final AtomicBoolean fieldsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean importsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean nameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean packageNameIsSet = new AtomicBoolean(false);
      private final AtomicBoolean startStatementsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean stopStatementsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean verticlesIsSet = new AtomicBoolean(false);
      private final ST template;

      private verticleST(STGroup group) {
   		template = group.getInstanceOf("verticle");
   	}

      public verticleST addFieldsValue(Object value) {
      	tryToSetListProperty(template, value, fieldsIsSet, "fields");
         return this;
      }
      public verticleST addImportsValue(Object value) {
      	tryToSetListProperty(template, value, importsIsSet, "imports");
         return this;
      }
       public verticleST setName(Object value) {
      	tryToSetStringProperty(template, value, nameIsSet, "name");   
         return this;
      } 
       public verticleST setPackageName(Object value) {
      	tryToSetStringProperty(template, value, packageNameIsSet, "packageName");   
         return this;
      } 
      public verticleST addStartStatementsValue(Object value) {
      	tryToSetListProperty(template, value, startStatementsIsSet, "startStatements");
         return this;
      }
      public verticleST addStopStatementsValue(Object value) {
      	tryToSetListProperty(template, value, stopStatementsIsSet, "stopStatements");
         return this;
      }
      public verticleST addVerticlesValue(Object deploy_) {
         verticlesIsSet.set(true);
         template.addAggr("verticles.{deploy}", ( (deploy_==null || deploy_.toString().length()==0) ? null : deploy_));
         return this;
      }

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class verticleConfigurationST {

      private final ST template;

      private verticleConfigurationST(STGroup group) {
   		template = group.getInstanceOf("verticleConfiguration");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class verticleInstancesST {

      private final ST template;

      private verticleInstancesST(STGroup group) {
   		template = group.getInstanceOf("verticleInstances");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class vertxST {

      private final AtomicBoolean optionsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean referenceIsSet = new AtomicBoolean(false);
      private final ST template;

      private vertxST(STGroup group) {
   		template = group.getInstanceOf("vertx");
   	}

       public vertxST setOptions(Object value) {
      	tryToSetStringProperty(template, value, optionsIsSet, "options");   
         return this;
      } 
       public vertxST setReference(Object value) {
      	tryToSetStringProperty(template, value, referenceIsSet, "reference");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class vertxOptionsST {

      private final AtomicBoolean blockedThreadCheckIntervalIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterHostIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterManagerIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterPingIntervalIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterPingReplyIntervalIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterPortIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterPublicHostIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusterPublicPortIsSet = new AtomicBoolean(false);
      private final AtomicBoolean clusteredIsSet = new AtomicBoolean(false);
      private final AtomicBoolean eventLoopPoolSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean haEnabledIsSet = new AtomicBoolean(false);
      private final AtomicBoolean haGroupIsSet = new AtomicBoolean(false);
      private final AtomicBoolean internalBlockingPoolSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean maxEventLoopExecuteTimeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean maxWorkerExecuteTimeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean metricsIsSet = new AtomicBoolean(false);
      private final AtomicBoolean quorumSizeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean warningExceptionTimeIsSet = new AtomicBoolean(false);
      private final AtomicBoolean workerPoolSizeIsSet = new AtomicBoolean(false);
      private final ST template;

      private vertxOptionsST(STGroup group) {
   		template = group.getInstanceOf("vertxOptions");
   	}

       public vertxOptionsST setBlockedThreadCheckInterval(Object value) {
      	tryToSetStringProperty(template, value, blockedThreadCheckIntervalIsSet, "blockedThreadCheckInterval");   
         return this;
      } 
       public vertxOptionsST setClusterHost(Object value) {
      	tryToSetStringProperty(template, value, clusterHostIsSet, "clusterHost");   
         return this;
      } 
       public vertxOptionsST setClusterManager(Object value) {
      	tryToSetStringProperty(template, value, clusterManagerIsSet, "clusterManager");   
         return this;
      } 
       public vertxOptionsST setClusterPingInterval(Object value) {
      	tryToSetStringProperty(template, value, clusterPingIntervalIsSet, "clusterPingInterval");   
         return this;
      } 
       public vertxOptionsST setClusterPingReplyInterval(Object value) {
      	tryToSetStringProperty(template, value, clusterPingReplyIntervalIsSet, "clusterPingReplyInterval");   
         return this;
      } 
       public vertxOptionsST setClusterPort(Object value) {
      	tryToSetStringProperty(template, value, clusterPortIsSet, "clusterPort");   
         return this;
      } 
       public vertxOptionsST setClusterPublicHost(Object value) {
      	tryToSetStringProperty(template, value, clusterPublicHostIsSet, "clusterPublicHost");   
         return this;
      } 
       public vertxOptionsST setClusterPublicPort(Object value) {
      	tryToSetStringProperty(template, value, clusterPublicPortIsSet, "clusterPublicPort");   
         return this;
      } 
       public vertxOptionsST setClustered(Object value) {
      	tryToSetStringProperty(template, value, clusteredIsSet, "clustered");   
         return this;
      } 
       public vertxOptionsST setEventLoopPoolSize(Object value) {
      	tryToSetStringProperty(template, value, eventLoopPoolSizeIsSet, "eventLoopPoolSize");   
         return this;
      } 
       public vertxOptionsST setHaEnabled(Object value) {
      	tryToSetStringProperty(template, value, haEnabledIsSet, "haEnabled");   
         return this;
      } 
       public vertxOptionsST setHaGroup(Object value) {
      	tryToSetStringProperty(template, value, haGroupIsSet, "haGroup");   
         return this;
      } 
       public vertxOptionsST setInternalBlockingPoolSize(Object value) {
      	tryToSetStringProperty(template, value, internalBlockingPoolSizeIsSet, "internalBlockingPoolSize");   
         return this;
      } 
       public vertxOptionsST setMaxEventLoopExecuteTime(Object value) {
      	tryToSetStringProperty(template, value, maxEventLoopExecuteTimeIsSet, "maxEventLoopExecuteTime");   
         return this;
      } 
       public vertxOptionsST setMaxWorkerExecuteTime(Object value) {
      	tryToSetStringProperty(template, value, maxWorkerExecuteTimeIsSet, "maxWorkerExecuteTime");   
         return this;
      } 
       public vertxOptionsST setMetrics(Object value) {
      	tryToSetStringProperty(template, value, metricsIsSet, "metrics");   
         return this;
      } 
       public vertxOptionsST setQuorumSize(Object value) {
      	tryToSetStringProperty(template, value, quorumSizeIsSet, "quorumSize");   
         return this;
      } 
       public vertxOptionsST setWarningExceptionTime(Object value) {
      	tryToSetStringProperty(template, value, warningExceptionTimeIsSet, "warningExceptionTime");   
         return this;
      } 
       public vertxOptionsST setWorkerPoolSize(Object value) {
      	tryToSetStringProperty(template, value, workerPoolSizeIsSet, "workerPoolSize");   
         return this;
      } 

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketFrameWriteST {

      private final ST template;

      private websocketFrameWriteST(STGroup group) {
   		template = group.getInstanceOf("websocketFrameWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketHandlerST {

      private final ST template;

      private websocketHandlerST(STGroup group) {
   		template = group.getInstanceOf("websocketHandler");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketReadFrameST {

      private final ST template;

      private websocketReadFrameST(STGroup group) {
   		template = group.getInstanceOf("websocketReadFrame");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketSingleFrameWriteST {

      private final ST template;

      private websocketSingleFrameWriteST(STGroup group) {
   		template = group.getInstanceOf("websocketSingleFrameWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketUpgradeST {

      private final ST template;

      private websocketUpgradeST(STGroup group) {
   		template = group.getInstanceOf("websocketUpgrade");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class websocketWriteST {

      private final ST template;

      private websocketWriteST(STGroup group) {
   		template = group.getInstanceOf("websocketWrite");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class workerVerticleST {

      private final ST template;

      private workerVerticleST(STGroup group) {
   		template = group.getInstanceOf("workerVerticle");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class writeFileAsynchST {

      private final ST template;

      private writeFileAsynchST(STGroup group) {
   		template = group.getInstanceOf("writeFileAsynch");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

    public final class writeSocketDataST {

      private final ST template;

      private writeSocketDataST(STGroup group) {
   		template = group.getInstanceOf("writeSocketData");
   	}

      @Override
   	public String toString() {
   		return template.render();
   	}
   } 

	static void tryToSetStringProperty(ST template, Object value, AtomicBoolean alreadySet, String name) {
		if (alreadySet.get()) return;
		if (value == null || value.toString().length() == 0) return;
		alreadySet.set(true);
		template.add(name, value);
	}

	static boolean tryToSetListProperty(ST template, Object value, AtomicBoolean alreadySet, String name) {
		if (value == null || value.toString().length() == 0) return true;
		alreadySet.set(true);
		template.add(name, value);
		return false;
	}

 private enum FormatCode {
      capitalize, toUpper, lowFirst, toLower, humpToCap, camelHump, splitCamelHump, singlify, packageToPath
   }

   private final class DefaultAttributeRenderer implements org.stringtemplate.v4.AttributeRenderer {

      @Override
      public String toString(Object o, String formatString, java.util.Locale locale) {

         final String text = o.toString();

         if (formatString == null) return text;

         switch (FormatCode.valueOf(formatString)) {
            case capitalize:
               return capitalize(text);
            case toUpper:
               return toUpper(text);
            case lowFirst:
               return lowFirst(text);
            case toLower:
               return text.toLowerCase();
            case humpToCap:
               return humpToCap(text);
            case camelHump:
               return camelHump(text);
            case splitCamelHump:
               return splitCamelHump(text);
            case singlify:
               String s = toUpper(text).substring(0, 1) + text.substring(1);
               if (s.toLowerCase().endsWith("ies")) return s.substring(0, s.length() - 3) + "y";
               else if (s.toLowerCase().endsWith("es") || s.toLowerCase().endsWith("nts")) return s.substring(0, s.length() - 1);
               else if (s.toLowerCase().endsWith("ions") || s.toLowerCase().endsWith("mns"))
                  return s.substring(0, s.length() - 1);
               return s;
            case packageToPath:
               return packageToPath((text));
            default:
               return o.toString();
         }
      }

      private String capitalize(String string) {
         if (string == null || string.length() == 0) return "";
         return Character.toUpperCase(string.charAt(0)) + (string.length() > 1 ? string.substring(1) : "");
      }

      private String lowFirst(String string) {
         if (string == null || string.length() == 0) return "";
         return Character.toLowerCase(string.charAt(0)) + (string.length() > 1 ? string.substring(1) : "");
      }

      private String toUpper(String text) {
         return text.toUpperCase();
      }

      private String humpToCap(String text) {
         final char[] chars = text.toCharArray();
         final StringBuilder out = new StringBuilder();
         boolean first = true;
         for (int i = 0; i < chars.length; i++) {
            char aChar = chars[i];
            if (!first && Character.isUpperCase(aChar) && (i < chars.length - 2 && Character.isLowerCase(chars[i + 1]))) {
               out.append("_");
            }
            first = false;
            out.append(Character.toUpperCase(aChar));
         }
         return out.toString();
      }

      private String camelHump(String text) {
         final char[] chars = text.toCharArray();
         final StringBuilder out = new StringBuilder();
         boolean capitalize = true;
         for (char aChar : chars) {
            if (Character.isWhitespace(aChar)) {
               capitalize = true;
               continue;
            }
            out.append(capitalize ? Character.toUpperCase(aChar) : aChar);
            capitalize = false;
         }
         return out.toString();
      }

      private String splitCamelHump(String text) {
         final char[] chars = text.toCharArray();
         final StringBuilder out = new StringBuilder();
         boolean first = true;
         for (char aChar : chars) {
            if (Character.isUpperCase(aChar)) out.append(" ");
            out.append(first ? Character.toUpperCase(aChar) : Character.toLowerCase(aChar));
            first = false;
         }
         return out.toString();
      }

      private String packageToPath(String packageName) {
          return (packageName == null ? "" : (packageName.replaceAll("[.]", "/") + java.io.File.separator));
      }
   } } 