package nextgen.templates;

import nextgen.templates.javaeasyflows.*;

public class JavaEasyFlowsPatterns extends JavaEasyFlowsST {

}