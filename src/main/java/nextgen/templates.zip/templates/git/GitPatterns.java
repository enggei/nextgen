package nextgen.templates.git;

import nextgen.templates.git.git.*;

public class GitPatterns extends GitST {

}