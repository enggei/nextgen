package nextgen.templates;

import nextgen.templates.javaneo4jembedded.*;

public class JavaNeo4JEmbeddedPatterns extends JavaNeo4JEmbeddedST {

}