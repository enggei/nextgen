package nextgen.templates;

import nextgen.templates.log4j.*;

public class Log4JPatterns extends Log4JST {

}