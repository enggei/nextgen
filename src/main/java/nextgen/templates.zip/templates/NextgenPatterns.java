package nextgen.templates;

import nextgen.st.STGenerator;
import nextgen.templates.java.PackageDeclaration;
import nextgen.templates.nextgen.NextgenST;

import java.io.File;

public class NextgenPatterns extends NextgenST {

}