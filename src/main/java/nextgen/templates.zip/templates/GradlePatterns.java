package nextgen.templates;

import nextgen.templates.gradle.*;

public class GradlePatterns extends GradleST {

}