package nextgen.templates;

import nextgen.templates.pettyreal.*;

class PettyRealPatterns extends PettyRealST {

}