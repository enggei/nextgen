package nextgen.templates;

import nextgen.templates.cypher.*;

public class CypherPatterns extends CypherST {

}