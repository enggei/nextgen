package nextgen.templates;

import nextgen.templates.test.*;

public class TestPatterns extends TestST {

}