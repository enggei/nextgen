package nextgen.templates;

import nextgen.templates.jsx.*;

public class JSXPatterns extends JSXST {

}