package nextgen.templates;

import nextgen.templates.html5.*;

class Html5Patterns extends Html5ST {

}