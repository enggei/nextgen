package nextgen.templates.gradle;

import nextgen.templates.gradle.*;

public class GradlePatterns extends GradleST {

}