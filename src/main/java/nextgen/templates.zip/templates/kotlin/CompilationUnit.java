package nextgen.templates.kotlin;

public interface CompilationUnit {

} 