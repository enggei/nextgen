package nextgen.templates;

import nextgen.templates.materialdesignlight.*;

public class MaterialDesignLightPatterns extends MaterialDesignLightST {

}