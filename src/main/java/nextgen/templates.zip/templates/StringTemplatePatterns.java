package nextgen.templates;

import nextgen.templates.stringtemplate.*;

class StringTemplatePatterns extends StringTemplateST {

}